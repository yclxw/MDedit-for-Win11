using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace MDEditor.Services
{
    public sealed class AppSettings
    {
        public bool IsDarkTheme { get; set; }
        public bool AutoSaveEnabled { get; set; }
        public int AutoSaveIntervalMinutes { get; set; } = 5;
        public List<string> RecentFiles { get; set; } = new List<string>();
        public string? LastOpenedFolder { get; set; }
    }

    public static class SettingsService
    {
        private static readonly string AppFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MDEditor");
        private static readonly string SettingsFile = Path.Combine(AppFolder, "settings.json");

        public static AppSettings Load()
        {
            try
            {
                if (!Directory.Exists(AppFolder))
                {
                    Directory.CreateDirectory(AppFolder);
                }

                if (!File.Exists(SettingsFile))
                {
                    return new AppSettings();
                }

                var text = File.ReadAllText(SettingsFile);
                return JsonSerializer.Deserialize<AppSettings>(text) ?? new AppSettings();
            }
            catch
            {
                return new AppSettings();
            }
        }

        public static void Save(AppSettings settings)
        {
            try
            {
                if (!Directory.Exists(AppFolder))
                {
                    Directory.CreateDirectory(AppFolder);
                }

                var text = JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(SettingsFile, text);
            }
            catch
            {
                // Ignore settings save failures
            }
        }
    }
}

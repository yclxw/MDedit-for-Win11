using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using Clipboard = System.Windows.Clipboard;
using DataFormats = System.Windows.DataFormats;
using MessageBox = System.Windows.MessageBox;
using TextDataFormat = System.Windows.TextDataFormat;
using Forms = System.Windows.Forms;
// Removed WebView2 dependency - using built-in WebBrowser as fallback
using MDEditor.Models;
using MDEditor.Services;
using MDEditor.Editor;
using System.Windows.Media;

namespace MDEditor
{
    public partial class MainWindow : Window
    {
        private AppSettings _settings = new AppSettings();
        private bool _webViewReady = true;
        private bool _showLineNumbers = false;
        private string? _currentFolderPath;
        private DispatcherTimer? _autoSaveTimer;
        private DispatcherTimer? _previewDebounceTimer;
        public MainWindow()
        {
            InitializeComponent();
            _settings = SettingsService.Load();
            ApplyTheme();
            InitializeAutoSave();
            _previewDebounceTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(150) };
            _previewDebounceTimer.Tick += (_, _) =>
            {
                _previewDebounceTimer.Stop();
                UpdatePreview();
            };
            RegisterShortcuts();
            Dispatcher.BeginInvoke(new Action(() => PopulateRecentFiles()),
                System.Windows.Threading.DispatcherPriority.Background);
            if (!string.IsNullOrEmpty(_settings.LastOpenedFolder) && Directory.Exists(_settings.LastOpenedFolder))
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    _currentFolderPath = _settings.LastOpenedFolder;
                    LoadFileTree(_currentFolderPath!);
                }), System.Windows.Threading.DispatcherPriority.Background);
            }
        }

        private void RegisterShortcuts()
        {
            void Bind(Key key, ModifierKeys mod, ExecutedRoutedEventHandler handler)
            {
                var cmd = new RoutedUICommand();
                CommandBindings.Add(new CommandBinding(cmd, handler));
                InputBindings.Add(new KeyBinding(cmd, key, mod));
            }

            // === 文件 ===
            Bind(Key.N, ModifierKeys.Control, (_, _) => NewFile_Click(null!, null!));
            Bind(Key.O, ModifierKeys.Control, (_, _) => OpenFile_Click(null!, null!));
            Bind(Key.S, ModifierKeys.Control, (_, _) => SaveFile_Click(null!, null!));
            Bind(Key.S, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => SaveAsMd_Click(null!, null!));
            Bind(Key.P, ModifierKeys.Control, (_, _) => Print_Click(null!, null!));
            Bind(Key.W, ModifierKeys.Control, (_, _) => CloseTab_Click(null!, null!));

            // === 编辑 (non-native; Ctrl+Z/Y/X/C/V/A handled natively by TextBox) ===
            Bind(Key.C, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => CopyAsPlainText_Click(null!, null!));
            Bind(Key.V, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => PastePlainText_Click(null!, null!));
            Bind(Key.F, ModifierKeys.Control, (_, _) => FindReplace_Click(null!, null!));
            Bind(Key.G, ModifierKeys.Control, (_, _) => GoToLine_Click(null!, null!));

            // === 视图 ===
            Bind(Key.D1, ModifierKeys.Control, (_, _) => SourceMode_Click(null!, null!));
            Bind(Key.D2, ModifierKeys.Control, (_, _) => PreviewMode_Click(null!, null!));
            Bind(Key.D3, ModifierKeys.Control, (_, _) => SplitVertical_Click(null!, null!));
            Bind(Key.D4, ModifierKeys.Control, (_, _) => SplitHorizontal_Click(null!, null!));
            Bind(Key.F11, ModifierKeys.None, (_, _) => FullScreen_Click(null!, null!));
            Bind(Key.B, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => ToggleSidebar_Click(null!, null!));
            Bind(Key.O, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => ToggleOutline_Click(null!, null!));
            Bind(Key.E, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => ToggleFileTree_Click(null!, null!));
            Bind(Key.G, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => ToggleLineNumbers_Click(null!, null!));
            Bind(Key.OemPlus, ModifierKeys.Control, (_, _) => ZoomIn_Click(null!, null!));
            Bind(Key.OemMinus, ModifierKeys.Control, (_, _) => ZoomOut_Click(null!, null!));
            Bind(Key.D0, ModifierKeys.Control, (_, _) => ResetZoom_Click(null!, null!));
            Bind(Key.D, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => ToggleTheme_Click(null!, null!));

            // === 格式 ===
            Bind(Key.B, ModifierKeys.Control, (_, _) => Bold_Click(null!, null!));
            Bind(Key.I, ModifierKeys.Control, (_, _) => Italic_Click(null!, null!));
            Bind(Key.X, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => Strikethrough_Click(null!, null!));
            Bind(Key.Oem3, ModifierKeys.Control, (_, _) => InlineCode_Click(null!, null!));
            Bind(Key.Oem3, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => CodeBlock_Click(null!, null!));
            Bind(Key.Q, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => BlockQuote_Click(null!, null!));
            Bind(Key.U, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => UnorderedList_Click(null!, null!));
            Bind(Key.N, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => OrderedList_Click(null!, null!));
            Bind(Key.T, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => TaskList_Click(null!, null!));
            Bind(Key.K, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => Link_Click(null!, null!));
            Bind(Key.I, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => Image_Click(null!, null!));

            // 标题 Ctrl+Shift+1~6 with CommandParameter
            var headingCmd = new RoutedUICommand();
            CommandBindings.Add(new CommandBinding(headingCmd, (_, e) =>
            {
                if (e.Parameter is int level) InsertHeading(level);
            }));
            for (var i = 1; i <= 6; i++)
            {
                InputBindings.Add(new KeyBinding(headingCmd, Key.D0 + i, ModifierKeys.Control | ModifierKeys.Shift)
                {
                    CommandParameter = i
                });
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // Handle file opened via command line / double-click association
            var args = Environment.GetCommandLineArgs();
            if (args.Length > 1)
            {
                var path = args[1];
                if (File.Exists(path))
                {
                    OpenDocument(path);
                    // WebBrowser ActiveX may not be ready yet; defer a refresh
                    Dispatcher.BeginInvoke(new Action(() => UpdatePreview()),
                        System.Windows.Threading.DispatcherPriority.Loaded);
                }
            }
        }

        private void InitializeAutoSave()
        {
            _autoSaveTimer = new DispatcherTimer();
            _autoSaveTimer.Interval = TimeSpan.FromMinutes(_settings.AutoSaveIntervalMinutes);
            _autoSaveTimer.Tick += AutoSaveTimer_Tick;
            _autoSaveTimer.IsEnabled = _settings.AutoSaveEnabled;
        }

        private void AutoSaveTimer_Tick(object? sender, EventArgs e)
        {
            var document = GetCurrentDocument();
            if (document != null && document.IsDirty)
            {
                SaveCurrentDocument(false);
            }
        }

        private Document? GetCurrentDocument()
        {
            if (EditorTabs.SelectedItem is TabItem tab && tab.Tag is Document document)
            {
                return document;
            }
            return null;
        }

        private MarkdownEditor? GetCurrentEditor()
        {
            if (EditorTabs.SelectedItem is TabItem tab && tab.Content is MarkdownEditor editor)
            {
                return editor;
            }
            return null;
        }

        private void NewDocument()
        {
            var document = new Document();
            AddEditorTab(document);
        }

        private void AddEditorTab(Document document)
        {
            var editor = new MarkdownEditor();
            editor.TextChanged += Editor_TextChanged;
            editor.Text = document.Content;
            editor.ShowLineNumbers = _showLineNumbers;

            var tab = new TabItem
            {
                Header = CreateTabHeader(document.Title + (document.IsDirty ? " *" : string.Empty)),
                Content = editor,
                Tag = document,
                ContextMenu = CreateTabContextMenu()
            };
            tab.PreviewMouseRightButtonDown += Tab_PreviewMouseRightButtonDown;

            EditorTabs.Items.Add(tab);
            EditorTabs.SelectedItem = tab;
            UpdatePreview();
        }

        private void Editor_TextChanged(object sender, TextChangedEventArgs e)
        {
            var document = GetCurrentDocument();
            var editor = GetCurrentEditor();
            if (document == null || editor == null)
            {
                return;
            }

            document.Content = editor.Text;
            document.IsDirty = true;
            UpdateTabHeader();

            // Debounce preview to avoid lag on rapid edits (format ops, typing)
            _previewDebounceTimer?.Stop();
            _previewDebounceTimer?.Start();
        }

        private void UpdateTabHeader()
        {
            if (EditorTabs.SelectedItem is TabItem selected && selected.Tag is Document document)
            {
                if (selected.Header is StackPanel panel && panel.Children.OfType<TextBlock>().FirstOrDefault() is TextBlock textBlock)
                {
                    textBlock.Text = document.Title + (document.IsDirty ? " *" : string.Empty);
                }
                else
                {
                    selected.Header = CreateTabHeader(document.Title + (document.IsDirty ? " *" : string.Empty));
                }
            }
        }

        private StackPanel CreateTabHeader(string title)
        {
            var titleText = new TextBlock
            {
                Text = title,
                VerticalAlignment = VerticalAlignment.Center
            };

            var closeButton = new System.Windows.Controls.Button
            {
                Content = "✕",
                Width = 18,
                Height = 18,
                Margin = new Thickness(6, 0, 0, 0),
                Padding = new Thickness(0),
                VerticalAlignment = VerticalAlignment.Center,
                ToolTip = "关闭",
                Focusable = false
            };
            closeButton.Click += CloseTabButton_Click;

            var panel = new StackPanel
            {
                Orientation = System.Windows.Controls.Orientation.Horizontal,
                Margin = new Thickness(4, 2, 4, 2)
            };
            panel.Children.Add(titleText);
            panel.Children.Add(closeButton);
            return panel;
        }

        private ContextMenu CreateTabContextMenu()
        {
            var menu = new ContextMenu();
            var closeCurrent = new MenuItem { Header = "关闭当前页签" };
            var closeOthers = new MenuItem { Header = "关闭其他页签" };
            var closeAll = new MenuItem { Header = "关闭全部页签" };
            closeCurrent.Click += Context_CloseCurrent_Click;
            closeOthers.Click += Context_CloseOthers_Click;
            closeAll.Click += Context_CloseAll_Click;
            menu.Items.Add(closeCurrent);
            menu.Items.Add(closeOthers);
            menu.Items.Add(closeAll);
            return menu;
        }

        private void Tab_PreviewMouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (sender is TabItem tab)
            {
                tab.IsSelected = true;
            }
        }

        private void UpdatePreview()
        {
            var editor = GetCurrentEditor();
            if (editor == null || !_webViewReady)
            {
                return;
            }

            var html = MarkdownConverter.ToHtml(editor.Text, _settings.IsDarkTheme);
            PreviewWebView.NavigateToString(html);
            UpdateOutline();
        }

        private void RefreshEditorState()
        {
            var editor = GetCurrentEditor();
            if (editor == null)
            {
                OutlineView?.Items.Clear();
                if (_webViewReady)
                {
                    PreviewWebView.NavigateToString("<html><body></body></html>");
                }
                return;
            }

            UpdatePreview();
        }

        private void ToggleLineNumbers_Click(object sender, RoutedEventArgs e)
        {
            _showLineNumbers = !_showLineNumbers;
            SetLineNumbersForAllEditors(_showLineNumbers);
            StatusText.Text = _showLineNumbers ? "行号：已显示" : "行号：已隐藏";
        }

        private void SetLineNumbersForAllEditors(bool show)
        {
            foreach (var tab in EditorTabs.Items.OfType<TabItem>())
            {
                if (tab.Content is MarkdownEditor editor)
                {
                    editor.ShowLineNumbers = show;
                }
            }
        }

        private void ApplyTheme()
        {
            Resources["WindowBackgroundBrush"] = _settings.IsDarkTheme ? System.Windows.Media.Brushes.Black : System.Windows.Media.Brushes.White;
            Resources["PanelBackgroundBrush"] = _settings.IsDarkTheme ? new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(30, 30, 30)) : new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(248, 248, 248));
            Resources["ControlBackgroundBrush"] = _settings.IsDarkTheme ? new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(24, 24, 24)) : System.Windows.Media.Brushes.White;
            Resources["ControlForegroundBrush"] = _settings.IsDarkTheme ? System.Windows.Media.Brushes.White : System.Windows.Media.Brushes.Black;
            Resources["BorderBrush"] = _settings.IsDarkTheme ? new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(64, 64, 64)) : new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(204, 204, 204));
            StatusText.Text = _settings.IsDarkTheme ? "深色主题" : "浅色主题";
        }

        private void PopulateRecentFiles()
        {
            RecentFilesMenu.Items.Clear();
            foreach (var path in _settings.RecentFiles.Take(20))
            {
                if (File.Exists(path))
                {
                    var item = new MenuItem { Header = path, Tag = path };
                    item.Click += RecentFile_Click;
                    RecentFilesMenu.Items.Add(item);
                }
            }

            if (RecentFilesMenu.Items.Count == 0)
            {
                RecentFilesMenu.Items.Add(new MenuItem { Header = "无最近文件", IsEnabled = false });
            }
        }

        private void AddRecentFile(string path)
        {
            _settings.RecentFiles.Remove(path);
            _settings.RecentFiles.Insert(0, path);
            if (_settings.RecentFiles.Count > 20)
            {
                _settings.RecentFiles.RemoveRange(20, _settings.RecentFiles.Count - 20);
            }
            SettingsService.Save(_settings);
            PopulateRecentFiles();
        }

        private void RecentFile_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem item && item.Tag is string path)
            {
                OpenDocument(path);
            }
        }

        private void OpenDocument(string path)
        {
            try
            {
                var document = FileService.Open(path);
                AddEditorTab(document);
                AddRecentFile(path);
            }
            catch (Exception ex)
            {
                MessageBox.Show("无法打开文档：" + ex.Message, "打开失败", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void OpenFolder_Click(object sender, RoutedEventArgs e)
        {
            using var dialog = new Forms.FolderBrowserDialog
            {
                Description = "选择 Markdown 工作区文件夹",
                ShowNewFolderButton = false
            };

            if (dialog.ShowDialog() == Forms.DialogResult.OK)
            {
                _currentFolderPath = dialog.SelectedPath;
                _settings.LastOpenedFolder = _currentFolderPath;
                SettingsService.Save(_settings);
                LoadFileTree(_currentFolderPath);
                StatusText.Text = $"工作区已打开：{_currentFolderPath}";
            }
        }

        private void LoadFileTree(string folderPath)
        {
            FileTreeView.Items.Clear();
            var rootItem = CreateFolderTreeItem(folderPath);
            FileTreeView.Items.Add(rootItem);
            rootItem.IsExpanded = true;
        }

        private TreeViewItem CreateFolderTreeItem(string path)
        {
            var item = new TreeViewItem
            {
                Header = Path.GetFileName(path) == string.Empty ? path : Path.GetFileName(path),
                Tag = path,
                IsExpanded = false
            };

            try
            {
                foreach (var dir in Directory.GetDirectories(path))
                {
                    item.Items.Add(CreateFolderTreeItem(dir));
                }

                foreach (var file in Directory.GetFiles(path).Where(file => file.EndsWith(".md", StringComparison.OrdinalIgnoreCase) || file.EndsWith(".txt", StringComparison.OrdinalIgnoreCase)))
                {
                    var fileItem = new TreeViewItem
                    {
                        Header = Path.GetFileName(file),
                        Tag = file
                    };
                    item.Items.Add(fileItem);
                }
            }
            catch
            {
                // Ignore permission exceptions or inaccessible folders
            }

            return item;
        }

        private void FileTreeView_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            if (e.NewValue is TreeViewItem item && item.Tag is string path && File.Exists(path))
            {
                OpenDocument(path);
            }
        }

        private void UpdateOutline()
        {
            if (OutlineView == null)
            {
                return;
            }

            OutlineView.Items.Clear();
            var editor = GetCurrentEditor();
            if (editor == null)
            {
                return;
            }

            var text = editor.Text;
            var lines = text.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
            var parents = new TreeViewItem?[7];
            var charPos = 0;

            foreach (var line in lines)
            {
                var trimmed = line.TrimStart();
                var isHeading = trimmed.StartsWith("#");

                if (isHeading)
                {
                    var level = trimmed.TakeWhile(c => c == '#').Count();
                    if (level >= 1 && level <= 6 && trimmed.Length > level && trimmed[level] == ' ')
                    {
                        var title = trimmed[(level + 1)..].Trim();
                        if (!string.IsNullOrWhiteSpace(title))
                        {
                            var lineIndex = editor.GetLineIndexFromCharacterIndex(charPos);
                            var outlineItem = new TreeViewItem
                            {
                                Header = title,
                                Tag = lineIndex,
                                IsExpanded = true
                            };
                            // Only handle via SelectedItemChanged — no separate Selected handler needed
                            parents[level] = outlineItem;
                            for (var clear = level + 1; clear < parents.Length; clear++)
                                parents[clear] = null;

                            if (level == 1)
                                OutlineView.Items.Add(outlineItem);
                            else if (parents[level - 1] != null)
                                parents[level - 1]!.Items.Add(outlineItem);
                            else
                                OutlineView.Items.Add(outlineItem);
                        }
                    }
                }

                charPos += line.Length;
                // Account for newline characters between lines
                if (charPos < text.Length)
                {
                    var c = text[charPos];
                    if (c == '\r')
                    {
                        charPos++;
                        if (charPos < text.Length && text[charPos] == '\n') charPos++;
                    }
                    else if (c == '\n')
                    {
                        charPos++;
                    }
                }
            }
        }

        private void OutlineView_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            if (e.NewValue is TreeViewItem item && item.Tag is int lineIndex)
            {
                var editor = GetCurrentEditor();
                editor?.GoToLine(lineIndex);
            }
        }

        private void OutlineView_PreviewMouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (sender is not System.Windows.Controls.TreeView treeView) return;

            // Don't intercept clicks on the expand/collapse toggle button
            var hit = treeView.InputHitTest(e.GetPosition(treeView));
            if (hit is System.Windows.Controls.Primitives.ToggleButton) return;

            var item = FindParentTreeViewItem(hit as DependencyObject);
            if (item?.Tag is int lineIndex)
            {
                var editor = GetCurrentEditor();
                editor?.GoToLine(lineIndex);
            }
        }

        private static TreeViewItem? FindParentTreeViewItem(DependencyObject? child)
        {
            while (child != null)
            {
                if (child is TreeViewItem tvi) return tvi;
                child = VisualTreeHelper.GetParent(child);
            }
            return null;
        }

        private bool SaveCurrentDocument(bool forceSaveAsMd)
        {
            var document = GetCurrentDocument();
            if (document == null)
            {
                return false;
            }

            if (string.IsNullOrEmpty(document.Path))
            {
                return SaveDocumentAs(document, forceSaveAsMd ? "Markdown 文件 (*.md)|*.md" : "Markdown 文件 (*.md)|*.md|文本文件 (*.txt)|*.txt", forceSaveAsMd ? ".md" : ".md");
            }

            try
            {
                FileService.Save(document.Path, document.Content);
                document.IsDirty = false;
                UpdateTabHeader();
                AddRecentFile(document.Path);
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("保存失败：" + ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
        }

        private bool SaveDocumentAs(Document document, string filter, string defaultExtension)
        {
            var dialog = new Microsoft.Win32.SaveFileDialog
            {
                Filter = filter,
                DefaultExt = defaultExtension,
                FileName = document.Title == "Untitled" ? "Untitled" : System.IO.Path.GetFileNameWithoutExtension(document.Path),
                AddExtension = true
            };

            if (dialog.ShowDialog(this) == true)
            {
                FileService.Save(dialog.FileName, document.Content);
                document.Path = dialog.FileName;
                document.IsDirty = false;
                UpdateTabHeader();
                AddRecentFile(dialog.FileName);
                return true;
            }

            return false;
        }

        private void NewFile_Click(object sender, RoutedEventArgs e) => NewDocument();

        private void OpenFile_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.OpenFileDialog
            {
                Filter = "Markdown 文件 (*.md)|*.md|文本文件 (*.txt)|*.txt|所有文件 (*.*)|*.*"
            };

            if (dialog.ShowDialog(this) == true)
            {
                OpenDocument(dialog.FileName);
            }
        }

        private void SaveFile_Click(object sender, RoutedEventArgs e) => SaveCurrentDocument(false);

        private void SaveAsMd_Click(object sender, RoutedEventArgs e)
        {
            var document = GetCurrentDocument();
            if (document == null)
            {
                return;
            }

            SaveDocumentAs(document, "Markdown 文件 (*.md)|*.md", ".md");
        }

        private void SaveAsTxt_Click(object sender, RoutedEventArgs e)
        {
            var document = GetCurrentDocument();
            if (document == null) return;

            var dialog = new Microsoft.Win32.SaveFileDialog
            {
                Filter = "文本文件 (*.txt)|*.txt",
                DefaultExt = ".txt",
                FileName = document.Title == "Untitled" ? "Untitled" : System.IO.Path.GetFileNameWithoutExtension(document.Path)
            };

            if (dialog.ShowDialog(this) == true)
            {
                FileService.SaveAsText(document.Content, dialog.FileName);
                AddRecentFile(dialog.FileName);
            }
        }

        private void ExportHtml_Click(object sender, RoutedEventArgs e)
        {
            var document = GetCurrentDocument();
            if (document == null) return;

            var dialog = new Microsoft.Win32.SaveFileDialog
            {
                Filter = "HTML 文件 (*.html)|*.html",
                DefaultExt = ".html",
                FileName = document.Title == "Untitled" ? "Untitled" : System.IO.Path.GetFileNameWithoutExtension(document.Path)
            };

            if (dialog.ShowDialog(this) == true)
            {
                FileService.SaveAsHtml(MarkdownConverter.ToHtml(document.Content, _settings.IsDarkTheme), dialog.FileName);
                AddRecentFile(dialog.FileName);
            }
        }

        private void Print_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var field = typeof(System.Windows.Controls.WebBrowser).GetField(
                    "_axIWebBrowser2",
                    System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                var axBrowser = field?.GetValue(PreviewWebView);
                axBrowser?.GetType().InvokeMember("ExecWB",
                    System.Reflection.BindingFlags.InvokeMethod, null, axBrowser,
                    new object[] { 6, 1 }); // OLECMDID_PRINT=6, OLECMDEXECOPT_PROMPTUSER=1
            }
            catch
            {
                MessageBox.Show("打印功能不可用。", "提示", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void CloseTab_Click(object sender, RoutedEventArgs e)
        {
            if (EditorTabs.SelectedItem is TabItem tab)
            {
                EditorTabs.Items.Remove(tab);
            }
            RefreshEditorState();
        }

        private static T? FindAncestor<T>(DependencyObject? child) where T : DependencyObject
        {
            while (child != null)
            {
                if (child is T t) return t;
                child = VisualTreeHelper.GetParent(child);
            }
            return null;
        }

        private void CloseTabButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is DependencyObject dobj && FindAncestor<TabItem>(dobj) is TabItem tab)
            {
                EditorTabs.Items.Remove(tab);
            }
            RefreshEditorState();
        }

        private void Context_CloseCurrent_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem menuItem)
            {
                var menu = FindAncestor<ContextMenu>(menuItem);
                if (menu?.PlacementTarget is TabItem tab)
                {
                    EditorTabs.Items.Remove(tab);
                }
            }
            RefreshEditorState();
        }

        private void Context_CloseOthers_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem menuItem)
            {
                var menu = FindAncestor<ContextMenu>(menuItem);
                if (menu?.PlacementTarget is TabItem current)
                {
                    var toClose = EditorTabs.Items.OfType<TabItem>().Where(t => t != current).ToList();
                    foreach (var t in toClose) EditorTabs.Items.Remove(t);
                    EditorTabs.SelectedItem = current;
                }
            }
        }

        private void Context_CloseAll_Click(object sender, RoutedEventArgs e)
        {
            EditorTabs.Items.Clear();
            RefreshEditorState();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Undo_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor?.CanUndo == true)
            {
                editor.Undo();
            }
        }

        private void Redo_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor?.CanRedo == true)
            {
                editor.Redo();
            }
        }

        private void Cut_Click(object sender, RoutedEventArgs e)
        {
            GetCurrentEditor()?.Cut();
        }

        private void Copy_Click(object sender, RoutedEventArgs e)
        {
            GetCurrentEditor()?.Copy();
        }

        private void CopyAsPlainText_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor != null)
            {
                ClipboardService.CopyPlainText(editor.SelectedText.Length > 0 ? editor.SelectedText : editor.Text);
            }
        }

        private void CopyAsMarkdown_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor != null)
            {
                ClipboardService.CopyMarkdown(editor.SelectedText.Length > 0 ? editor.SelectedText : editor.Text);
            }
        }

        private void CopyAsHtml_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor != null)
            {
                ClipboardService.CopyHtml(editor.SelectedText.Length > 0 ? editor.SelectedText : editor.Text);
            }
        }

        private void Paste_Click(object sender, RoutedEventArgs e)
        {
            GetCurrentEditor()?.Paste();
        }

        private void PastePlainText_Click(object sender, RoutedEventArgs e)
        {
            if (GetCurrentEditor() is { } editor)
            {
                editor.ReplaceSelectedText(Clipboard.GetText(TextDataFormat.Text));
            }
        }

        private void SelectAll_Click(object sender, RoutedEventArgs e)
        {
            GetCurrentEditor()?.SelectAll();
        }

        private void FindReplace_Click(object sender, RoutedEventArgs e)
        {
            ShowFindReplaceDialog();
        }

        private void ShowFindReplaceDialog()
        {
            var editor = GetCurrentEditor();
            if (editor == null)
            {
                return;
            }

            var window = new FindReplaceWindow(editor)
            {
                Owner = this
            };
            window.Show();
        }

        private void GoToLine_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor == null) return;

            var dialog = new GoToLineDialog(editor.LineCount)
            {
                Owner = this
            };
            if (dialog.ShowDialog() == true)
            {
                editor.GoToLine(dialog.LineNumber - 1);
            }
        }

        private void SourceMode_Click(object sender, RoutedEventArgs e)
        {
            // Editor spans all rows and columns
            SetGridPosition(EditorTabs, 0, 0, 3, 3);
            EditorTabs.Visibility = Visibility.Visible;
            PreviewBorder.Visibility = Visibility.Collapsed;
            PreviewSplitter.Visibility = Visibility.Collapsed;
        }

        private void PreviewMode_Click(object sender, RoutedEventArgs e)
        {
            // Preview spans all rows and columns
            SetGridPosition(PreviewBorder, 0, 0, 3, 3);
            EditorTabs.Visibility = Visibility.Collapsed;
            PreviewBorder.Visibility = Visibility.Visible;
            PreviewSplitter.Visibility = Visibility.Collapsed;
        }

        private void SplitVertical_Click(object sender, RoutedEventArgs e)
        {
            // Left-right: rows collapsed to single, columns split
            MainGrid.RowDefinitions[1].Height = new GridLength(0);
            MainGrid.ColumnDefinitions[1].Width = new GridLength(5);
            PreviewSplitter.ResizeDirection = GridResizeDirection.Columns;

            SetGridPosition(EditorTabs, 0, 0, 3, 1);
            SetGridPosition(PreviewSplitter, 0, 1, 3, 1);
            SetGridPosition(PreviewBorder, 0, 2, 3, 1);

            EditorTabs.Visibility = Visibility.Visible;
            PreviewBorder.Visibility = Visibility.Visible;
            PreviewSplitter.Visibility = Visibility.Visible;
        }

        private void SplitHorizontal_Click(object sender, RoutedEventArgs e)
        {
            // Top-bottom: columns collapsed to single, rows split
            MainGrid.ColumnDefinitions[1].Width = new GridLength(0);
            MainGrid.RowDefinitions[1].Height = new GridLength(5);
            PreviewSplitter.ResizeDirection = GridResizeDirection.Rows;

            SetGridPosition(EditorTabs, 0, 0, 1, 3);
            SetGridPosition(PreviewSplitter, 1, 0, 1, 3);
            SetGridPosition(PreviewBorder, 2, 0, 1, 3);

            EditorTabs.Visibility = Visibility.Visible;
            PreviewBorder.Visibility = Visibility.Visible;
            PreviewSplitter.Visibility = Visibility.Visible;
        }

        private static void SetGridPosition(UIElement element, int row, int col, int rowSpan, int colSpan)
        {
            Grid.SetRow(element, row);
            Grid.SetColumn(element, col);
            Grid.SetRowSpan(element, rowSpan);
            Grid.SetColumnSpan(element, colSpan);
        }

        private void FullScreen_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
        }

        private void FocusMode_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("聚焦模式将在后续版本中完善。", "提示", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ToggleOutline_Click(object sender, RoutedEventArgs e)
        {
            if (OutlineView != null)
            {
                OutlineView.Visibility = OutlineView.Visibility == Visibility.Visible ? Visibility.Collapsed : Visibility.Visible;
                StatusText.Text = OutlineView.Visibility == Visibility.Visible ? "大纲：已显示" : "大纲：已隐藏";
            }
        }

        private void ToggleFileTree_Click(object sender, RoutedEventArgs e)
        {
            if (Sidebar != null && SidebarColumn != null)
            {
                var isVisible = Sidebar.Visibility == Visibility.Visible;
                Sidebar.Visibility = isVisible ? Visibility.Collapsed : Visibility.Visible;
                SidebarColumn.Width = isVisible ? new GridLength(0) : new GridLength(250);
                StatusText.Text = Sidebar.Visibility == Visibility.Visible ? "文件树：已显示" : "文件树：已隐藏";
            }
        }

        private void ToggleSidebar_Click(object sender, RoutedEventArgs e)
        {
            if (Sidebar != null && SidebarColumn != null)
            {
                var isVisible = Sidebar.Visibility == Visibility.Visible;
                Sidebar.Visibility = isVisible ? Visibility.Collapsed : Visibility.Visible;
                SidebarColumn.Width = isVisible ? new GridLength(0) : new GridLength(250);
                StatusText.Text = Sidebar.Visibility == Visibility.Visible ? "侧边栏：已显示" : "侧边栏：已隐藏";
            }
        }

        private void ZoomIn_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor != null)
            {
                editor.ZoomIn();
            }
        }

        private void ZoomOut_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor != null)
            {
                editor.ZoomOut();
            }
        }

        private void ResetZoom_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            editor?.ResetZoom();
        }

        private void ToggleTheme_Click(object sender, RoutedEventArgs e)
        {
            _settings.IsDarkTheme = !_settings.IsDarkTheme;
            SettingsService.Save(_settings);
            ApplyTheme();
            UpdatePreview();
        }

        private void Heading_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem item && int.TryParse(item.Tag?.ToString(), out var level))
            {
                InsertHeading(level);
            }
        }

        private void InsertHeading(int level)
        {
            var prefix = new string('#', Math.Max(1, Math.Min(level, 6))) + " ";
            WrapSelection(prefix, string.Empty);
        }

        private void Bold_Click(object sender, RoutedEventArgs e) => WrapSelection("**", "**");
        private void Italic_Click(object sender, RoutedEventArgs e) => WrapSelection("*", "*");
        private void Strikethrough_Click(object sender, RoutedEventArgs e) => WrapSelection("~~", "~~");
        private void InlineCode_Click(object sender, RoutedEventArgs e) => WrapSelection("`", "`");
        private void CodeBlock_Click(object sender, RoutedEventArgs e) => WrapSelection("```\r\n", "\r\n```");
        private void BlockQuote_Click(object sender, RoutedEventArgs e) => WrapSelection("> ", string.Empty);
        private void UnorderedList_Click(object sender, RoutedEventArgs e) => WrapSelection("- ", string.Empty);
        private void OrderedList_Click(object sender, RoutedEventArgs e) => WrapSelection("1. ", string.Empty);
        private void TaskList_Click(object sender, RoutedEventArgs e) => WrapSelection("- [ ] ", string.Empty);
        private void Link_Click(object sender, RoutedEventArgs e) => WrapSelection("[", "]()" );
        private void Image_Click(object sender, RoutedEventArgs e) => WrapSelection("![", "]()" );
        private void Table_Click(object sender, RoutedEventArgs e) => WrapSelection("| 列1 | 列2 |\r\n| --- | --- |\r\n", string.Empty);
        private void HorizontalRule_Click(object sender, RoutedEventArgs e) => WrapSelection("---\r\n", string.Empty);

        private void WordCount_Click(object sender, RoutedEventArgs e)
        {
            var document = GetCurrentDocument();
            if (document != null)
            {
                var content = document.Content ?? string.Empty;
                var words = content.Split(new[] { ' ', '\r', '\n', '\t' }, StringSplitOptions.RemoveEmptyEntries).Length;
                MessageBox.Show($"当前文档字数：{words}", "字数统计", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void SpellCheck_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("拼写检查功能将在后续版本中集成。", "拼写检查", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void TableEditor_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("表格编辑器功能将在后续版本中完成。", "表格编辑器", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void InsertMath_Click(object sender, RoutedEventArgs e)
        {
            WrapSelection("$$\r\n", "\r\n$$");
        }

        private void InsertMermaid_Click(object sender, RoutedEventArgs e)
        {
            WrapSelection("```mermaid\r\n", "\r\n```\r\n");
        }

        private void InsertToc_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor == null) return;

            var lines = editor.Text.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
            var toc = new StringBuilder();
            toc.AppendLine("<!-- TOC -->");

            foreach (var line in lines)
            {
                var trimmed = line.TrimStart();
                if (!trimmed.StartsWith("#")) continue;

                var level = trimmed.TakeWhile(c => c == '#').Count();
                if (level < 1 || level > 6) continue;

                // Must have a space after # markers to be a proper heading
                if (trimmed.Length <= level || trimmed[level] != ' ') continue;

                var title = trimmed[(level + 1)..].Trim();
                if (string.IsNullOrWhiteSpace(title)) continue;

                var anchor = GenerateAnchor(title);
                var indent = new string(' ', (level - 1) * 2);
                toc.AppendLine($"{indent}- [{title}](#{anchor})");
            }

            toc.AppendLine();
            editor.InsertTextAtCaret(toc.ToString());
        }

        private static string GenerateAnchor(string heading)
        {
            var sb = new StringBuilder();
            var lastWasDash = false;
            foreach (var c in heading.ToLowerInvariant())
            {
                if (char.IsLetterOrDigit(c))
                {
                    sb.Append(c);
                    lastWasDash = false;
                }
                else if (!lastWasDash && (c == ' ' || c == '-' || c == '_'))
                {
                    sb.Append('-');
                    lastWasDash = true;
                }
                else if (c > 127)
                {
                    // Preserve CJK and other non-ASCII characters
                    sb.Append(c);
                    lastWasDash = false;
                }
            }
            // Trim trailing dashes
            while (sb.Length > 0 && sb[^1] == '-')
                sb.Length--;
            return sb.ToString();
        }

        private void Settings_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("设置窗口将在后续版本中添加。", "设置", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void HelpDoc_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("请参阅项目文档以获取更多帮助。", "帮助文档", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ShortcutReference_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("快捷键参考功能将在后续版本中完善。", "快捷键参考", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void About_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("MD文本编辑器 for Win11\n版本：2026.0518\n作者：帅气的锅巴", "关于", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void WrapSelection(string prefix, string suffix)
        {
            var editor = GetCurrentEditor();
            if (editor == null)
            {
                return;
            }

            var selection = editor.SelectedText;
            if (string.IsNullOrEmpty(selection))
            {
                editor.InsertTextAtCaret(prefix + suffix);
            }
            else
            {
                editor.ReplaceSelectedText(prefix + selection + suffix);
            }
        }

        private void EditorTabs_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdatePreview();
        }
    }

    public class GoToLineDialog : Window
    {
        public int LineNumber { get; private set; }

        public GoToLineDialog(int maxLines)
        {
            Title = "跳转到行";
            Width = 260;
            Height = 140;
            ResizeMode = ResizeMode.NoResize;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
            ShowInTaskbar = false;

            var grid = new System.Windows.Controls.Grid { Margin = new Thickness(12) };
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            var label = new System.Windows.Controls.Label
            {
                Content = $"行号 (1 - {maxLines}):",
                VerticalAlignment = VerticalAlignment.Center
            };
            System.Windows.Controls.Grid.SetRow(label, 0);
            System.Windows.Controls.Grid.SetColumn(label, 0);

            var textBox = new System.Windows.Controls.TextBox
            {
                Margin = new Thickness(8, 4, 0, 4),
                VerticalAlignment = VerticalAlignment.Center
            };
            System.Windows.Controls.Grid.SetRow(textBox, 0);
            System.Windows.Controls.Grid.SetColumn(textBox, 1);

            var panel = new System.Windows.Controls.StackPanel
            {
                Orientation = System.Windows.Controls.Orientation.Horizontal,
                HorizontalAlignment = System.Windows.HorizontalAlignment.Right,
                Margin = new Thickness(0, 12, 0, 0)
            };
            System.Windows.Controls.Grid.SetRow(panel, 1);
            System.Windows.Controls.Grid.SetColumn(panel, 0);
            System.Windows.Controls.Grid.SetColumnSpan(panel, 2);

            var okButton = new System.Windows.Controls.Button { Content = "确定", Width = 75, Margin = new Thickness(4, 0, 0, 0), IsDefault = true };
            var cancelButton = new System.Windows.Controls.Button { Content = "取消", Width = 75, Margin = new Thickness(4, 0, 0, 0), IsCancel = true };

            okButton.Click += (_, _) =>
            {
                if (int.TryParse(textBox.Text, out var line) && line >= 1 && line <= maxLines)
                {
                    LineNumber = line;
                    DialogResult = true;
                    Close();
                }
                else
                {
                    System.Windows.MessageBox.Show($"请输入 1 到 {maxLines} 之间的行号。", "无效输入",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            };
            cancelButton.Click += (_, _) => Close();

            panel.Children.Add(okButton);
            panel.Children.Add(cancelButton);

            grid.Children.Add(label);
            grid.Children.Add(textBox);
            grid.Children.Add(panel);
            Content = grid;

            textBox.Focus();
        }
    }
}

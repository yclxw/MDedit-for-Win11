using System.Windows;

namespace MDEditor
{
    public partial class App : System.Windows.Application
    {
    }
}

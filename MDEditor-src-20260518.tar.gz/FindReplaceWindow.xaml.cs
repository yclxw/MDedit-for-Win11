using System;
using System.Windows;
using MessageBox = System.Windows.MessageBox;
using MDEditor.Editor;

namespace MDEditor
{
    public partial class FindReplaceWindow : Window
    {
        private readonly MarkdownEditor _editor;

        public FindReplaceWindow(MarkdownEditor editor)
        {
            InitializeComponent();
            _editor = editor;
            FindTextBox.Focus();
        }

        private void FindNextButton_Click(object sender, RoutedEventArgs e)
        {
            if (!TryFindNext())
            {
                MessageBox.Show("未找到匹配项。", "查找", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void ReplaceButton_Click(object sender, RoutedEventArgs e)
        {
            if (!TryFindNext())
            {
                MessageBox.Show("未找到匹配项。", "替换", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            _editor.ReplaceSelectedText(ReplaceTextBox.Text);
        }

        private void ReplaceAllButton_Click(object sender, RoutedEventArgs e)
        {
            var count = _editor.ReplaceAll(FindTextBox.Text, ReplaceTextBox.Text, MatchCaseCheckBox.IsChecked == true, RegexCheckBox.IsChecked == true);
            MessageBox.Show($"已替换 {count} 处内容。", "全部替换", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private bool TryFindNext()
        {
            return _editor.FindNext(FindTextBox.Text, MatchCaseCheckBox.IsChecked == true, RegexCheckBox.IsChecked == true);
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}

# Build MDEditor and place compiled outputs into C:\Vs\MDE\ExE
$ErrorActionPreference = "Stop"
cd "$PSScriptRoot"

$exeName = "MDEditor"
$exePath = Join-Path $PSScriptRoot "ExE\$exeName.exe"

# Kill any running instance so the output files are not locked
$proc = Get-Process -Name $exeName -ErrorAction SilentlyContinue
if ($proc) {
    Write-Host "Stopping running $exeName.exe (PID $($proc.Id))..." -ForegroundColor Yellow
    $proc.Kill()
    $proc.WaitForExit(5000)
    Start-Sleep -Milliseconds 500
}

dotnet build .\MDEditor.csproj -c Release
if ($LASTEXITCODE -ne 0) {
    Write-Host "Build failed with exit code $LASTEXITCODE" -ForegroundColor Red
    exit $LASTEXITCODE
}

if (Test-Path $exePath) {
    Write-Host "Build OK: $exePath" -ForegroundColor Green
}

using System.IO;
using System.Text;
using MDEditor.Models;

namespace MDEditor.Services
{
    public static class FileService
    {
        public static Document Open(string path)
        {
            var content = File.ReadAllText(path, Encoding.UTF8);
            return new Document
            {
                Path = path,
                Content = content,
                IsDirty = false
            };
        }

        public static void Save(string path, string content)
        {
            File.WriteAllText(path, content, Encoding.UTF8);
        }

        public static void SaveAsText(string markdown, string path)
        {
            var text = MarkdownConverter.ToPlainText(markdown);
            File.WriteAllText(path, text, Encoding.UTF8);
        }

        public static void SaveAsHtml(string html, string path)
        {
            File.WriteAllText(path, html, Encoding.UTF8);
        }
    }
}

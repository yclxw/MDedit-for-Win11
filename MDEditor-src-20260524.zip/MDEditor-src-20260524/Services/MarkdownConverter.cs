using System;
using System.Linq;
using System.Text;
using HtmlAgilityPack;
using HtmlDocument = HtmlAgilityPack.HtmlDocument;
using Markdig;

namespace MDEditor.Services
{
    public static class MarkdownConverter
    {
        private static readonly MarkdownPipeline Pipeline = new MarkdownPipelineBuilder()
            .UseAdvancedExtensions()
            .UsePipeTables()
            .UseTaskLists()
            .UseAutoLinks()
            .UseMathematics()
            .Build();

        private static readonly string LightCss = @"body { font-family: 'Segoe UI', Arial, sans-serif; margin: 24px; color: #111111; background: #ffffff; line-height: 1.8; }
h1,h2,h3,h4,h5,h6 { font-weight: 700; }
pre, code { font-family: 'Consolas', monospace; background: #f5f5f5; padding: 8px; border-radius: 6px; }
blockquote { border-left: 4px solid #d0d0d0; margin-left: 0; padding-left: 12px; color: #555555; }
table { border-collapse: collapse; width: 100%; }
td, th { border: 1px solid #d0d0d0; padding: 10px; }
img { max-width: 100%; }
";

        private static readonly string DarkCss = @"body { font-family: 'Segoe UI', Arial, sans-serif; margin: 24px; color: #e9e9e9; background: #111111; line-height: 1.8; }
h1,h2,h3,h4,h5,h6 { font-weight: 700; }
pre, code { font-family: 'Consolas', monospace; background: #1f1f1f; color: #f1f1f1; padding: 8px; border-radius: 6px; }
blockquote { border-left: 4px solid #4b4b4b; margin-left: 0; padding-left: 12px; color: #bbbbbb; }
table { border-collapse: collapse; width: 100%; }
td, th { border: 1px solid #555555; padding: 10px; }
img { max-width: 100%; }
";

        public static string ToHtml(string markdown, bool isDarkTheme)
        {
            var body = Markdown.ToHtml(markdown ?? string.Empty, Pipeline);
            return WrapHtml(body, isDarkTheme);
        }

        public static string ToPlainText(string markdown)
        {
            var html = Markdown.ToHtml(markdown ?? string.Empty, Pipeline);
            return HtmlToPlainText(html);
        }

        private static string WrapHtml(string body, bool isDarkTheme)
        {
            var css = isDarkTheme ? DarkCss : LightCss;
            return $"<!DOCTYPE html><html><head><meta charset=\"utf-8\"><style>{css}</style></head><body>{body}</body></html>";
        }

        private static string HtmlToPlainText(string html)
        {
            var document = new HtmlDocument();
            document.LoadHtml(html);
            var builder = new StringBuilder();
            ExtractText(document.DocumentNode, builder);
            return NormalizeWhitespace(builder.ToString());
        }

        private static void ExtractText(HtmlNode node, StringBuilder builder)
        {
            if (node.NodeType == HtmlNodeType.Text)
            {
                var text = HtmlEntity.DeEntitize(node.InnerText);
                if (!string.IsNullOrWhiteSpace(text))
                {
                    builder.Append(text);
                }
            }
            else if (node.Name == "li")
            {
                builder.AppendLine("- " + HtmlEntity.DeEntitize(node.InnerText.Trim()));
            }
            else if (node.Name == "br" || node.Name == "p" || node.Name == "div" || node.Name.StartsWith("h"))
            {
                foreach (var child in node.ChildNodes)
                {
                    ExtractText(child, builder);
                }
                builder.AppendLine();
            }
            else
            {
                foreach (var child in node.ChildNodes)
                {
                    ExtractText(child, builder);
                }
            }
        }

        private static string NormalizeWhitespace(string text)
        {
            var lines = text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(line => line.Trim())
                .Where(line => !string.IsNullOrWhiteSpace(line));
            return string.Join(Environment.NewLine, lines);
        }
    }
}

using System.IO;
using System.Text;
using MDEditor.Models;

namespace MDEditor.Services
{
    public static class FileManager
    {
        private const long LargeFileThreshold = 500_000; // 500KB

        // ══════════════════════════════════════════
        //  File I/O
        // ══════════════════════════════════════════

        public static Document Open(string path)
        {
            var content = File.ReadAllText(path, Encoding.UTF8);
            return new Document { Path = path, Content = content, IsDirty = false };
        }

        public static async Task<Document> OpenAsync(string path)
        {
            var content = await Task.Run(() => File.ReadAllText(path, Encoding.UTF8));
            return new Document { Path = path, Content = content, IsDirty = false };
        }

        public static Document CreatePlaceholder(string path)
        {
            return new Document
            {
                Path = path,
                Content = "加载中...",
                IsDirty = false
            };
        }

        public static bool IsLargeFile(string path)
        {
            try
            {
                return new FileInfo(path).Length >= LargeFileThreshold;
            }
            catch
            {
                return false;
            }
        }

        public static void Save(string path, string content)
        {
            var dir = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                Directory.CreateDirectory(dir);

            File.WriteAllText(path, content, Encoding.UTF8);
        }

        // ══════════════════════════════════════════
        //  Session
        // ══════════════════════════════════════════

        public static List<SessionDocument> LoadSession()
        {
            return SettingsService.LoadSession();
        }

        public static void SaveSession(List<SessionDocument> tabs)
        {
            SettingsService.SaveSession(tabs);
        }

        // ══════════════════════════════════════════
        //  Recent files
        // ══════════════════════════════════════════

        public static List<string> GetRecentFiles()
        {
            var settings = SettingsService.Load();
            return settings.RecentFiles.Where(File.Exists).Take(20).ToList();
        }

        public static void AddRecentFile(string path)
        {
            var settings = SettingsService.Load();
            settings.RecentFiles.Remove(path);
            settings.RecentFiles.Insert(0, path);
            if (settings.RecentFiles.Count > 20)
                settings.RecentFiles = settings.RecentFiles.Take(20).ToList();
            SettingsService.Save(settings);
        }
    }
}

using Clipboard = System.Windows.Clipboard;
using DataFormats = System.Windows.DataFormats;
using DataObject = System.Windows.DataObject;
using System.Windows;
using TextDataFormat = System.Windows.TextDataFormat;

namespace MDEditor.Services
{
    public static class ClipboardService
    {
        public static void CopyMarkdown(string markdown)
        {
            if (string.IsNullOrEmpty(markdown))
            {
                return;
            }

            Clipboard.SetText(markdown, TextDataFormat.Text);
        }

        public static void CopyPlainText(string markdown)
        {
            if (string.IsNullOrEmpty(markdown))
            {
                return;
            }

            var plain = MarkdownConverter.ToPlainText(markdown);
            Clipboard.SetText(plain, TextDataFormat.Text);
        }

        public static void CopyHtml(string markdown)
        {
            if (string.IsNullOrEmpty(markdown))
            {
                return;
            }

            var html = MarkdownConverter.ToHtml(markdown, false);
            var data = new DataObject();
            data.SetData(DataFormats.Html, html);
            Clipboard.SetDataObject(data, true);
        }
    }
}

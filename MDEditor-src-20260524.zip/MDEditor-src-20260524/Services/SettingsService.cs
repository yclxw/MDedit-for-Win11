using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using MDEditor.Models;

namespace MDEditor.Services
{
    public enum ViewMode
    {
        SourceOnly,
        PreviewOnly,
        SplitVertical,
        SplitHorizontal,
        FullView,
        StandardView,
        CustomView
    }

    public sealed class AppSettings
    {
        public bool IsDarkTheme { get; set; }
        public bool AutoSaveEnabled { get; set; }
        public int AutoSaveIntervalMinutes { get; set; } = 5;
        public List<string> RecentFiles { get; set; } = new List<string>();
        public string? LastOpenedFolder { get; set; }
        public ViewMode DefaultView { get; set; } = ViewMode.FullView;
        public int CustomSidebarRatio { get; set; } = 20;
        public int CustomEditorRatio { get; set; } = 40;
        public int CustomPreviewRatio { get; set; } = 40;
        public string EditorFontFamily { get; set; } = "Consolas";
        public double EditorFontSize { get; set; } = 14;
    }

    public static class SettingsService
    {
        private static readonly string AppFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MDEditor");
        private static readonly string SettingsFile = Path.Combine(AppFolder, "settings.json");
        private static readonly string SessionFile = Path.Combine(AppFolder, "session.json");

        public static AppSettings Load()
        {
            try
            {
                if (!Directory.Exists(AppFolder))
                {
                    Directory.CreateDirectory(AppFolder);
                }

                if (!File.Exists(SettingsFile))
                {
                    return new AppSettings();
                }

                var text = File.ReadAllText(SettingsFile);
                return JsonSerializer.Deserialize<AppSettings>(text) ?? new AppSettings();
            }
            catch
            {
                return new AppSettings();
            }
        }

        public static void Save(AppSettings settings)
        {
            try
            {
                if (!Directory.Exists(AppFolder))
                {
                    Directory.CreateDirectory(AppFolder);
                }

                var text = JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(SettingsFile, text);
            }
            catch
            {
                // Ignore settings save failures
            }
        }

        public static List<SessionDocument> LoadSession()
        {
            try
            {
                if (!File.Exists(SessionFile))
                    return new List<SessionDocument>();

                var text = File.ReadAllText(SessionFile);
                return JsonSerializer.Deserialize<List<SessionDocument>>(text) ?? new List<SessionDocument>();
            }
            catch
            {
                return new List<SessionDocument>();
            }
        }

        public static void SaveSession(List<SessionDocument> tabs)
        {
            try
            {
                if (!Directory.Exists(AppFolder))
                    Directory.CreateDirectory(AppFolder);

                if (tabs.Count == 0)
                {
                    if (File.Exists(SessionFile))
                        File.Delete(SessionFile);
                    return;
                }

                var text = JsonSerializer.Serialize(tabs, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(SessionFile, text);
            }
            catch
            {
                // Ignore session save failures
            }
        }
    }
}

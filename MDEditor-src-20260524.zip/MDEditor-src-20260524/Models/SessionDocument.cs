namespace MDEditor.Models
{
    public class SessionDocument
    {
        public string Path { get; set; } = string.Empty;
        public string Content { get; set; } = string.Empty;
        public bool IsDirty { get; set; }
        public int CursorPosition { get; set; }
    }
}

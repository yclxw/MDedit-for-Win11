namespace MDEditor.Models
{
    public class Document
    {
        public string Path { get; set; } = string.Empty;
        public string Content { get; set; } = string.Empty;
        public bool IsDirty { get; set; }

        public string DefaultTitle { get; set; } = "Untitled";
        public string Title => string.IsNullOrEmpty(Path) ? DefaultTitle : System.IO.Path.GetFileName(Path);
    }
}

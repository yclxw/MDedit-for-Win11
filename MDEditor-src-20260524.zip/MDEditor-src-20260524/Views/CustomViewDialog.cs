using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Brushes = System.Windows.Media.Brushes;
using Button = System.Windows.Controls.Button;
using Label = System.Windows.Controls.Label;
using TextBox = System.Windows.Controls.TextBox;
using Orientation = System.Windows.Controls.Orientation;
using HorizontalAlignment = System.Windows.HorizontalAlignment;

namespace MDEditor
{
    public class CustomViewDialog : Window
    {
        public int SidebarRatio { get; private set; }
        public int EditorRatio { get; private set; }
        public int PreviewRatio { get; private set; }

        private readonly TextBox _sidebarBox;
        private readonly TextBox _editorBox;
        private readonly TextBox _previewBox;
        private readonly TextBlock _hintText;

        public CustomViewDialog(int sidebar, int editor, int preview)
        {
            Title = "设置个性视图比例";
            Width = 350;
            Height = 220;
            ResizeMode = ResizeMode.NoResize;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
            ShowInTaskbar = false;

            var grid = new Grid { Margin = new Thickness(12) };
            for (var i = 0; i < 5; i++)
                grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            void AddRow(int row, string label, string initial, out TextBox box)
            {
                var lbl = new Label
                {
                    Content = label,
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin = new Thickness(0, 4, 8, 4)
                };
                Grid.SetRow(lbl, row);
                Grid.SetColumn(lbl, 0);

                box = new TextBox
                {
                    Text = initial,
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin = new Thickness(0, 4, 8, 4),
                    Width = 60,
                    HorizontalAlignment = HorizontalAlignment.Left
                };
                box.TextChanged += (_, _) => UpdateHint();
                Grid.SetRow(box, row);
                Grid.SetColumn(box, 1);

                var pct = new TextBlock
                {
                    Text = "%",
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin = new Thickness(0, 4, 0, 4)
                };
                Grid.SetRow(pct, row);
                Grid.SetColumn(pct, 2);

                grid.Children.Add(lbl);
                grid.Children.Add(box);
                grid.Children.Add(pct);
            }

            AddRow(0, "侧边栏占比：", sidebar.ToString(), out _sidebarBox);
            AddRow(1, "编辑栏占比：", editor.ToString(), out _editorBox);
            AddRow(2, "预览栏占比：", preview.ToString(), out _previewBox);

            _hintText = new TextBlock
            {
                Foreground = Brushes.Gray,
                Margin = new Thickness(0, 8, 0, 0)
            };
            Grid.SetRow(_hintText, 3);
            Grid.SetColumn(_hintText, 0);
            Grid.SetColumnSpan(_hintText, 3);
            grid.Children.Add(_hintText);

            var panel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(0, 12, 0, 0)
            };
            Grid.SetRow(panel, 4);
            Grid.SetColumn(panel, 0);
            Grid.SetColumnSpan(panel, 3);

            var okButton = new Button { Content = "确定", Width = 75, Margin = new Thickness(4, 0, 0, 0), IsDefault = true };
            var cancelButton = new Button { Content = "取消", Width = 75, Margin = new Thickness(4, 0, 0, 0), IsCancel = true };

            okButton.Click += (_, _) =>
            {
                if (int.TryParse(_sidebarBox.Text, out var s) &&
                    int.TryParse(_editorBox.Text, out var e) &&
                    int.TryParse(_previewBox.Text, out var p))
                {
                    if (s < 0 || e < 0 || p < 0)
                    {
                        System.Windows.MessageBox.Show("占比不能为负数。", "输入错误", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }
                    if (s + e + p != 100)
                    {
                        System.Windows.MessageBox.Show("三个占比之和必须等于 100%。", "输入错误", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }
                    SidebarRatio = s;
                    EditorRatio = e;
                    PreviewRatio = p;
                    DialogResult = true;
                    Close();
                }
                else
                {
                    System.Windows.MessageBox.Show("请输入有效的整数。", "输入错误", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            };
            cancelButton.Click += (_, _) => Close();

            panel.Children.Add(okButton);
            panel.Children.Add(cancelButton);
            grid.Children.Add(panel);

            Content = grid;
            UpdateHint();
            _sidebarBox.Focus();
        }

        private void UpdateHint()
        {
            int.TryParse(_sidebarBox.Text, out var s);
            int.TryParse(_editorBox.Text, out var e);
            int.TryParse(_previewBox.Text, out var p);
            var sum = s + e + p;
            _hintText.Text = sum == 100
                ? "总和 100% ✓"
                : $"当前总和 {sum}%，需正好 100%";
        }
    }
}

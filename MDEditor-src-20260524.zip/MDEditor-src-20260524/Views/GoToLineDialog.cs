using System.Windows;
using System.Windows.Controls;
using Button = System.Windows.Controls.Button;
using Label = System.Windows.Controls.Label;
using TextBox = System.Windows.Controls.TextBox;
using Orientation = System.Windows.Controls.Orientation;
using HorizontalAlignment = System.Windows.HorizontalAlignment;

namespace MDEditor
{
    public class GoToLineDialog : Window
    {
        public int LineNumber { get; private set; }

        public GoToLineDialog(int maxLines)
        {
            Title = "跳转到行";
            Width = 260;
            Height = 140;
            ResizeMode = ResizeMode.NoResize;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
            ShowInTaskbar = false;

            var grid = new Grid { Margin = new Thickness(12) };
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            var label = new Label
            {
                Content = $"行号 (1 - {maxLines}):",
                VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetRow(label, 0);
            Grid.SetColumn(label, 0);

            var textBox = new TextBox
            {
                Margin = new Thickness(8, 4, 0, 4),
                VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetRow(textBox, 0);
            Grid.SetColumn(textBox, 1);

            var panel = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(0, 12, 0, 0)
            };
            Grid.SetRow(panel, 1);
            Grid.SetColumn(panel, 0);
            Grid.SetColumnSpan(panel, 2);

            var okButton = new Button { Content = "确定", Width = 75, Margin = new Thickness(4, 0, 0, 0), IsDefault = true };
            var cancelButton = new Button { Content = "取消", Width = 75, Margin = new Thickness(4, 0, 0, 0), IsCancel = true };

            okButton.Click += (_, _) =>
            {
                if (int.TryParse(textBox.Text, out var line) && line >= 1 && line <= maxLines)
                {
                    LineNumber = line;
                    DialogResult = true;
                    Close();
                }
                else
                {
                    System.Windows.MessageBox.Show($"请输入 1 到 {maxLines} 之间的行号。", "无效输入",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            };
            cancelButton.Click += (_, _) => Close();

            panel.Children.Add(okButton);
            panel.Children.Add(cancelButton);

            grid.Children.Add(label);
            grid.Children.Add(textBox);
            grid.Children.Add(panel);
            Content = grid;

            textBox.Focus();
        }
    }
}

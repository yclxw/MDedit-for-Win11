using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using Clipboard = System.Windows.Clipboard;
using DataFormats = System.Windows.DataFormats;
using MessageBox = System.Windows.MessageBox;
using TextDataFormat = System.Windows.TextDataFormat;
using Forms = System.Windows.Forms;
using ContextMenu = System.Windows.Controls.ContextMenu;
using MenuItem = System.Windows.Controls.MenuItem;
// Removed WebView2 dependency - using built-in WebBrowser as fallback
using MDEditor.Models;
using MDEditor.Services;
using MDEditor.Editor;
using System.Windows.Media;
using Microsoft.Win32;

namespace MDEditor
{
    public partial class MainWindow : Window
    {
        private AppSettings _settings = new AppSettings();
        private bool _webViewReady = true;
        private bool _showLineNumbers = false;
        private string? _lastPreviewContent;
        private bool _lastPreviewTheme;
        private Document? _lastPreviewDocument;
        private string? _lastSearchText;
        private bool _lastSearchMatchCase;
        private bool _lastSearchUseRegex;
        private string? _currentFolderPath;
        private DispatcherTimer? _autoSaveTimer;
        private DispatcherTimer? _previewDebounceTimer;
        private ViewLayout _currentViewLayout = ViewLayout.FullView;
        public MainWindow()
        {
            InitializeComponent();
            _settings = SettingsService.Load();
            _editorFontFamily = _settings.EditorFontFamily;
            _editorFontSize = _settings.EditorFontSize;
            ApplyTheme();
            InitializeAutoSave();
            _previewDebounceTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(150) };
            _previewDebounceTimer.Tick += (_, _) =>
            {
                _previewDebounceTimer.Stop();
                UpdatePreview();
            };
            RegisterShortcuts();
            Dispatcher.BeginInvoke(new Action(() => PopulateRecentFiles()),
                System.Windows.Threading.DispatcherPriority.Background);
            if (!string.IsNullOrEmpty(_settings.LastOpenedFolder) && Directory.Exists(_settings.LastOpenedFolder))
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    _currentFolderPath = _settings.LastOpenedFolder;
                    LoadFileTree(_currentFolderPath!);
                }), System.Windows.Threading.DispatcherPriority.Background);
            }
        }

        private void RegisterShortcuts()
        {
            void Bind(Key key, ModifierKeys mod, ExecutedRoutedEventHandler handler)
            {
                var cmd = new RoutedUICommand();
                CommandBindings.Add(new CommandBinding(cmd, handler));
                InputBindings.Add(new KeyBinding(cmd, key, mod));
            }

            // === 文件 ===
            Bind(Key.N, ModifierKeys.Control, (_, _) => NewFile_Click(null!, null!));
            Bind(Key.O, ModifierKeys.Control, (_, _) => OpenFile_Click(null!, null!));
            Bind(Key.S, ModifierKeys.Control, (_, _) => SaveFile_Click(null!, null!));
            Bind(Key.S, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => SaveAsMd_Click(null!, null!));
            Bind(Key.P, ModifierKeys.Control, (_, _) => Print_Click(null!, null!));
            Bind(Key.W, ModifierKeys.Control, (_, _) => CloseTab_Click(null!, null!));

            // === 编辑 (non-native; Ctrl+Z/Y/X/C/V/A handled natively by TextBox) ===
            Bind(Key.C, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => CopyAsPlainText_Click(null!, null!));
            Bind(Key.V, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => PastePlainText_Click(null!, null!));
            Bind(Key.F, ModifierKeys.Control, (_, _) => FindReplace_Click(null!, null!));
            Bind(Key.F3, ModifierKeys.None, (_, _) => FindNextShortcut());
            Bind(Key.G, ModifierKeys.Control, (_, _) => GoToLine_Click(null!, null!));

            // === 视图 ===
            Bind(Key.D1, ModifierKeys.Control, (_, _) => FullView_Click(null!, null!));
            Bind(Key.D2, ModifierKeys.Control, (_, _) => PreviewMode_Click(null!, null!));
            Bind(Key.D3, ModifierKeys.Control, (_, _) => SourceMode_Click(null!, null!));
            Bind(Key.D4, ModifierKeys.Control, (_, _) => SplitVertical_Click(null!, null!));
            Bind(Key.D5, ModifierKeys.Control, (_, _) => SplitHorizontal_Click(null!, null!));
            Bind(Key.D6, ModifierKeys.Control, (_, _) => StandardView_Click(null!, null!));
            Bind(Key.D7, ModifierKeys.Control, (_, _) => CustomView_Click(null!, null!));
            Bind(Key.F11, ModifierKeys.None, (_, _) => FullScreen_Click(null!, null!));
            Bind(Key.B, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => ToggleSidebar_Click(null!, null!));
            Bind(Key.G, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => ToggleLineNumbers_Click(null!, null!));
            Bind(Key.OemPlus, ModifierKeys.Control, (_, _) => ZoomIn_Click(null!, null!));
            Bind(Key.OemMinus, ModifierKeys.Control, (_, _) => ZoomOut_Click(null!, null!));
            Bind(Key.D0, ModifierKeys.Control, (_, _) => ResetZoom_Click(null!, null!));
            Bind(Key.D, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => ToggleTheme_Click(null!, null!));

            // === 格式 ===
            Bind(Key.B, ModifierKeys.Control, (_, _) => Bold_Click(null!, null!));
            Bind(Key.I, ModifierKeys.Control, (_, _) => Italic_Click(null!, null!));
            Bind(Key.X, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => Strikethrough_Click(null!, null!));
            Bind(Key.Oem3, ModifierKeys.Control, (_, _) => InlineCode_Click(null!, null!));
            Bind(Key.Oem3, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => CodeBlock_Click(null!, null!));
            Bind(Key.Q, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => BlockQuote_Click(null!, null!));
            Bind(Key.U, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => UnorderedList_Click(null!, null!));
            Bind(Key.N, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => OrderedList_Click(null!, null!));
            Bind(Key.T, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => TaskList_Click(null!, null!));
            Bind(Key.K, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => Link_Click(null!, null!));
            Bind(Key.I, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => Image_Click(null!, null!));

            // 标题 Ctrl+Shift+1~6 with CommandParameter
            var headingCmd = new RoutedUICommand();
            CommandBindings.Add(new CommandBinding(headingCmd, (_, e) =>
            {
                if (e.Parameter is int level) InsertHeading(level);
            }));
            for (var i = 1; i <= 6; i++)
            {
                InputBindings.Add(new KeyBinding(headingCmd, Key.D0 + i, ModifierKeys.Control | ModifierKeys.Shift)
                {
                    CommandParameter = i
                });
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Resources["TabItemWidth"] = System.Windows.SystemParameters.PrimaryScreenWidth / 10.0;

            PopulateFontMenu();

            UpdateDefaultViewCheckMarks();
            ApplyViewMode(_settings.DefaultView);

            // Warm up WebBrowser ActiveX so first NavigateToString works
            PreviewWebView.NavigateToString("<html><body></body></html>");

            // Handle file opened via command line / double-click association
            var args = Environment.GetCommandLineArgs();
            var openedFile = false;
            if (args.Length > 1)
            {
                var path = args[1];
                if (File.Exists(path))
                {
                    OpenDocument(path);
                    openedFile = true;
                }
            }

            // Always restore previous session tabs alongside any opened file
            Dispatcher.BeginInvoke(new Action(() => RestoreSession()),
                System.Windows.Threading.DispatcherPriority.Loaded);

            if (openedFile)
            {
                Dispatcher.BeginInvoke(new Action(() => UpdatePreview()),
                    System.Windows.Threading.DispatcherPriority.Loaded);
            }
        }

        private void Window_Closing(object? sender, System.ComponentModel.CancelEventArgs e)
        {
            SaveSession();
        }

        private void SaveSession()
        {
            var tabs = new List<SessionDocument>();
            foreach (var item in EditorTabs.Items.OfType<TabItem>())
            {
                if (item.Tag is Document doc && item.Content is MarkdownEditor editor)
                {
                    tabs.Add(new SessionDocument
                    {
                        Path = doc.Path,
                        Content = editor.Text,
                        IsDirty = doc.IsDirty,
                        CursorPosition = editor.GetCaretIndex()
                    });
                }
            }
            FileManager.SaveSession(tabs);
        }

        private void RestoreSession()
        {
            var tabs = FileManager.LoadSession();
            foreach (var sessionDoc in tabs)
            {
                var document = new Document
                {
                    Path = sessionDoc.Path,
                    Content = sessionDoc.Content,
                    IsDirty = sessionDoc.IsDirty
                };
                var editor = new MarkdownEditor();
                editor.TextChanged += Editor_TextChanged;
                editor.Text = sessionDoc.Content;
                editor.ShowLineNumbers = _showLineNumbers;
                editor.SetFontFamily(_editorFontFamily);
                editor.SetFontSize(_editorFontSize);

                var tab = new TabItem
                {
                    Header = CreateTabHeader(document.Title + (document.IsDirty ? " *" : string.Empty)),
                    Content = editor,
                    Tag = document,
                    ContextMenu = CreateTabContextMenu()
                };
                tab.PreviewMouseRightButtonDown += Tab_PreviewMouseRightButtonDown;

                EditorTabs.Items.Add(tab);
            }

            if (EditorTabs.Items.Count > 0)
            {
                EditorTabs.SelectedIndex = 0;
                // Restore cursor position for the first tab
                if (EditorTabs.SelectedItem is TabItem firstTab &&
                    firstTab.Tag is Document firstDoc &&
                    firstTab.Content is MarkdownEditor firstEditor)
                {
                    var sessionTab = tabs[0];
                    firstEditor.SetCaretIndex(Math.Min(sessionTab.CursorPosition, firstEditor.Text.Length));
                    firstEditor.Focus();
                }
            }
            RefreshEditorState();
        }

        private void InitializeAutoSave()
        {
            _autoSaveTimer = new DispatcherTimer();
            _autoSaveTimer.Interval = TimeSpan.FromMinutes(_settings.AutoSaveIntervalMinutes);
            _autoSaveTimer.Tick += AutoSaveTimer_Tick;
            _autoSaveTimer.IsEnabled = _settings.AutoSaveEnabled;
        }

        private void AutoSaveTimer_Tick(object? sender, EventArgs e)
        {
            var document = GetCurrentDocument();
            if (document != null && document.IsDirty)
            {
                SaveCurrentDocument(false);
            }
        }

        private Document? GetCurrentDocument()
        {
            if (EditorTabs.SelectedItem is TabItem tab && tab.Tag is Document document)
            {
                return document;
            }
            return null;
        }

        private MarkdownEditor? GetCurrentEditor()
        {
            if (EditorTabs.SelectedItem is TabItem tab && tab.Content is MarkdownEditor editor)
            {
                return editor;
            }
            return null;
        }

        private int _newDocCounter;

        private void NewDocument()
        {
            _newDocCounter++;
            var document = new Document { DefaultTitle = $"新文本{_newDocCounter}" };
            AddEditorTab(document);
        }

        private void AddEditorTab(Document document)
        {
            var editor = new MarkdownEditor();
            editor.TextChanged += Editor_TextChanged;
            editor.Text = document.Content;
            editor.ShowLineNumbers = _showLineNumbers;
            editor.SetFontFamily(_editorFontFamily);
            editor.SetFontSize(_editorFontSize);

            var tab = new TabItem
            {
                Header = CreateTabHeader(document.Title + (document.IsDirty ? " *" : string.Empty)),
                Content = editor,
                Tag = document,
                ContextMenu = CreateTabContextMenu()
            };
            tab.PreviewMouseRightButtonDown += Tab_PreviewMouseRightButtonDown;

            EditorTabs.Items.Add(tab);
            EditorTabs.SelectedItem = tab;
            Dispatcher.BeginInvoke(new Action(() => UpdatePreview()),
                System.Windows.Threading.DispatcherPriority.Loaded);
        }

        private void Editor_TextChanged(object sender, TextChangedEventArgs e)
        {
            var document = GetCurrentDocument();
            var editor = GetCurrentEditor();
            if (document == null || editor == null)
            {
                return;
            }

            document.Content = editor.Text;
            document.IsDirty = true;
            UpdateTabHeader();

            // Debounce preview to avoid lag on rapid edits (format ops, typing)
            _previewDebounceTimer?.Stop();
            _previewDebounceTimer?.Start();
        }

        private void UpdateTabHeader()
        {
            if (EditorTabs.SelectedItem is TabItem selected && selected.Tag is Document document)
            {
                if (selected.Header is DockPanel panel && panel.Children.OfType<TextBlock>().FirstOrDefault() is TextBlock textBlock)
                {
                    textBlock.Text = document.Title + (document.IsDirty ? " *" : string.Empty);
                }
                else
                {
                    selected.Header = CreateTabHeader(document.Title + (document.IsDirty ? " *" : string.Empty));
                }
            }
        }

        private DockPanel CreateTabHeader(string title)
        {
            var titleText = new TextBlock
            {
                Text = title,
                VerticalAlignment = VerticalAlignment.Center,
                TextTrimming = TextTrimming.CharacterEllipsis,
                MaxWidth = double.PositiveInfinity
            };
            DockPanel.SetDock(titleText, Dock.Left);

            var closeBtn = new System.Windows.Controls.Button
            {
                Content = "×",
                Width = 20,
                Height = 20,
                VerticalAlignment = VerticalAlignment.Center,
                ToolTip = "关闭",
                Focusable = false,
                FontSize = 14,
                FontWeight = FontWeights.Bold,
                Foreground = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0x88, 0x88, 0x88)),
                Background = System.Windows.Media.Brushes.Transparent,
                BorderThickness = new Thickness(0),
                Padding = new Thickness(0),
                Cursor = System.Windows.Input.Cursors.Hand,
                HorizontalAlignment = System.Windows.HorizontalAlignment.Right,
                Margin = new Thickness(0)
            };
            closeBtn.MouseEnter += (_, _) =>
            {
                closeBtn.Background = new SolidColorBrush(System.Windows.Media.Color.FromArgb(0xE6, 0xFF, 0x00, 0x00));
                closeBtn.Foreground = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0xFF, 0xFF, 0xFF));
            };
            closeBtn.MouseLeave += (_, _) =>
            {
                closeBtn.Background = System.Windows.Media.Brushes.Transparent;
                closeBtn.Foreground = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0x88, 0x88, 0x88));
            };
            closeBtn.Click += CloseTabButton_Click;
            DockPanel.SetDock(closeBtn, Dock.Right);

            var panel = new DockPanel
            {
                LastChildFill = true,
                Margin = new Thickness(5, 1, 0, 1),
                ToolTip = title
            };
            panel.Children.Add(closeBtn);
            panel.Children.Add(titleText);
            return panel;
        }

        private ContextMenu CreateTabContextMenu()
        {
            var menu = new ContextMenu();
            var closeCurrent = new MenuItem { Header = "关闭当前页签" };
            var closeOthers = new MenuItem { Header = "关闭其他页签" };
            var closeAll = new MenuItem { Header = "关闭全部页签" };
            closeCurrent.Click += Context_CloseCurrent_Click;
            closeOthers.Click += Context_CloseOthers_Click;
            closeAll.Click += Context_CloseAll_Click;
            menu.Items.Add(closeCurrent);
            menu.Items.Add(closeOthers);
            menu.Items.Add(closeAll);
            return menu;
        }

        private void Tab_PreviewMouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (sender is TabItem tab)
            {
                tab.IsSelected = true;
            }
        }

        private void UpdatePreview()
        {
            var editor = GetCurrentEditor();
            if (editor == null || !_webViewReady)
                return;

            var document = GetCurrentDocument();

            // Skip re-render if content and theme unchanged (fast tab switch)
            if (document == _lastPreviewDocument
                && editor.Text == _lastPreviewContent
                && _settings.IsDarkTheme == _lastPreviewTheme)
            {
                return;
            }

            _lastPreviewDocument = document;
            _lastPreviewContent = editor.Text;
            _lastPreviewTheme = _settings.IsDarkTheme;

            var html = MarkdownConverter.ToHtml(editor.Text, _settings.IsDarkTheme);
            PreviewWebView.NavigateToString(html);
            UpdateOutline();
        }

        private void RefreshEditorState()
        {
            var editor = GetCurrentEditor();
            if (editor == null)
            {
                OutlineView?.Items.Clear();
                if (_webViewReady)
                {
                    PreviewWebView.NavigateToString("<html><body></body></html>");
                }
                return;
            }

            UpdatePreview();
        }

        private void ToggleLineNumbers_Click(object sender, RoutedEventArgs e)
        {
            _showLineNumbers = !_showLineNumbers;
            SetLineNumbersForAllEditors(_showLineNumbers);
            StatusText.Text = _showLineNumbers ? "行号：已显示" : "行号：已隐藏";
        }

        private void SetLineNumbersForAllEditors(bool show)
        {
            foreach (var tab in EditorTabs.Items.OfType<TabItem>())
            {
                if (tab.Content is MarkdownEditor editor)
                {
                    editor.ShowLineNumbers = show;
                }
            }
        }

        private void ApplyTheme()
        {
            Resources["WindowBackgroundBrush"] = _settings.IsDarkTheme ? System.Windows.Media.Brushes.Black : System.Windows.Media.Brushes.White;
            Resources["PanelBackgroundBrush"] = _settings.IsDarkTheme ? new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(30, 30, 30)) : new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(248, 248, 248));
            Resources["ControlBackgroundBrush"] = _settings.IsDarkTheme ? new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(24, 24, 24)) : System.Windows.Media.Brushes.White;
            Resources["ControlForegroundBrush"] = _settings.IsDarkTheme ? System.Windows.Media.Brushes.White : System.Windows.Media.Brushes.Black;
            Resources["BorderBrush"] = _settings.IsDarkTheme ? new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(64, 64, 64)) : new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(204, 204, 204));
            StatusText.Text = _settings.IsDarkTheme ? "深色主题" : "浅色主题";
        }

        private void PopulateRecentFiles()
        {
            RecentFilesMenu.Items.Clear();
            foreach (var path in FileManager.GetRecentFiles())
            {
                var item = new MenuItem { Header = path, Tag = path };
                item.Click += RecentFile_Click;
                RecentFilesMenu.Items.Add(item);
            }

            if (RecentFilesMenu.Items.Count == 0)
            {
                RecentFilesMenu.Items.Add(new MenuItem { Header = "无最近文件", IsEnabled = false });
            }
        }

        private void AddRecentFile(string path)
        {
            FileManager.AddRecentFile(path);
            PopulateRecentFiles();
        }

        private void RecentFile_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem item && item.Tag is string path)
            {
                OpenDocument(path);
            }
        }

        private void OpenDocument(string path)
        {
            try
            {
                Document document;
                if (FileManager.IsLargeFile(path))
                {
                    document = FileManager.CreatePlaceholder(path);
                    AddEditorTab(document);
                    AddRecentFile(path);
                    _ = LoadLargeFileAsync(path, document);
                }
                else
                {
                    document = FileManager.Open(path);
                    AddEditorTab(document);
                    AddRecentFile(path);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("无法打开文档：" + ex.Message, "打开失败", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async Task LoadLargeFileAsync(string path, Document document)
        {
            try
            {
                var loaded = await FileManager.OpenAsync(path);
                document.Content = loaded.Content;
                document.IsDirty = false;

                await Dispatcher.InvokeAsync(() =>
                {
                    foreach (var item in EditorTabs.Items.OfType<TabItem>())
                    {
                        if (item.Tag == document && item.Content is MarkdownEditor editor)
                        {
                            editor.Text = loaded.Content;
                            UpdateTabHeader();
                            UpdatePreview();
                            break;
                        }
                    }
                    StatusText.Text = $"已加载: {System.IO.Path.GetFileName(path)}";
                });
            }
            catch (Exception ex)
            {
                await Dispatcher.InvokeAsync(() =>
                {
                    MessageBox.Show("无法打开文档：" + ex.Message, "打开失败", MessageBoxButton.OK, MessageBoxImage.Error);
                    var tab = EditorTabs.Items.OfType<TabItem>().FirstOrDefault(t => t.Tag == document);
                    if (tab != null)
                    {
                        EditorTabs.Items.Remove(tab);
                        RefreshEditorState();
                    }
                });
            }
        }

        public void OpenDocumentFromExternal(string path)
        {
            OpenDocument(path);
            Activate();
            if (WindowState == WindowState.Minimized)
                WindowState = WindowState.Normal;
        }

        private void OpenFolder_Click(object sender, RoutedEventArgs e)
        {
            using var dialog = new Forms.FolderBrowserDialog
            {
                Description = "选择 Markdown 工作区文件夹",
                ShowNewFolderButton = false
            };

            if (dialog.ShowDialog() == Forms.DialogResult.OK)
            {
                _currentFolderPath = dialog.SelectedPath;
                _settings.LastOpenedFolder = _currentFolderPath;
                SettingsService.Save(_settings);
                LoadFileTree(_currentFolderPath);
                StatusText.Text = $"工作区已打开：{_currentFolderPath}";
            }
        }

        private void LoadFileTree(string folderPath)
        {
            FileTreeView.Items.Clear();
            var rootItem = CreateFolderTreeItem(folderPath);
            FileTreeView.Items.Add(rootItem);
            rootItem.IsExpanded = true;
        }

        private TreeViewItem CreateFolderTreeItem(string path)
        {
            var item = new TreeViewItem
            {
                Header = Path.GetFileName(path) == string.Empty ? path : Path.GetFileName(path),
                Tag = path,
                IsExpanded = false
            };

            try
            {
                foreach (var dir in Directory.GetDirectories(path))
                {
                    item.Items.Add(CreateFolderTreeItem(dir));
                }

                foreach (var file in Directory.GetFiles(path).Where(file => file.EndsWith(".md", StringComparison.OrdinalIgnoreCase) || file.EndsWith(".txt", StringComparison.OrdinalIgnoreCase)))
                {
                    var fileItem = new TreeViewItem
                    {
                        Header = Path.GetFileName(file),
                        Tag = file
                    };
                    item.Items.Add(fileItem);
                }
            }
            catch
            {
                // Ignore permission exceptions or inaccessible folders
            }

            return item;
        }

        private void FileTreeView_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            if (e.NewValue is TreeViewItem item && item.Tag is string path && File.Exists(path))
            {
                OpenDocument(path);
            }
        }

        private void UpdateOutline()
        {
            if (OutlineView == null)
            {
                return;
            }

            OutlineView.Items.Clear();
            var editor = GetCurrentEditor();
            if (editor == null)
            {
                return;
            }

            var text = editor.Text;
            var lines = text.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
            var parents = new TreeViewItem?[7];
            var charPos = 0;

            foreach (var line in lines)
            {
                var trimmed = line.TrimStart();
                var isHeading = trimmed.StartsWith("#");

                if (isHeading)
                {
                    var level = trimmed.TakeWhile(c => c == '#').Count();
                    if (level >= 1 && level <= 6 && trimmed.Length > level && trimmed[level] == ' ')
                    {
                        var title = trimmed[(level + 1)..].Trim();
                        if (!string.IsNullOrWhiteSpace(title))
                        {
                            var lineIndex = editor.GetLineIndexFromCharacterIndex(charPos);
                            var outlineItem = new TreeViewItem
                            {
                                Header = title,
                                Tag = lineIndex,
                                IsExpanded = true
                            };
                            // Only handle via SelectedItemChanged — no separate Selected handler needed
                            parents[level] = outlineItem;
                            for (var clear = level + 1; clear < parents.Length; clear++)
                                parents[clear] = null;

                            if (level == 1)
                                OutlineView.Items.Add(outlineItem);
                            else if (parents[level - 1] != null)
                                parents[level - 1]!.Items.Add(outlineItem);
                            else
                                OutlineView.Items.Add(outlineItem);
                        }
                    }
                }

                charPos += line.Length;
                // Account for newline characters between lines
                if (charPos < text.Length)
                {
                    var c = text[charPos];
                    if (c == '\r')
                    {
                        charPos++;
                        if (charPos < text.Length && text[charPos] == '\n') charPos++;
                    }
                    else if (c == '\n')
                    {
                        charPos++;
                    }
                }
            }
        }

        private void OutlineView_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            if (e.NewValue is TreeViewItem item && item.Tag is int lineIndex)
            {
                var editor = GetCurrentEditor();
                editor?.GoToLine(lineIndex);
            }
        }

        private void OutlineView_PreviewMouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (sender is not System.Windows.Controls.TreeView treeView) return;

            // Don't intercept clicks on the expand/collapse toggle button
            var hit = treeView.InputHitTest(e.GetPosition(treeView));
            if (hit is System.Windows.Controls.Primitives.ToggleButton) return;

            var item = FindParentTreeViewItem(hit as DependencyObject);
            if (item?.Tag is int lineIndex)
            {
                var editor = GetCurrentEditor();
                editor?.GoToLine(lineIndex);
            }
        }

        private static TreeViewItem? FindParentTreeViewItem(DependencyObject? child)
        {
            while (child != null)
            {
                if (child is TreeViewItem tvi) return tvi;
                child = VisualTreeHelper.GetParent(child);
            }
            return null;
        }

        private bool SaveCurrentDocument(bool forceSaveAsMd)
        {
            var document = GetCurrentDocument();
            if (document == null)
            {
                return false;
            }

            if (string.IsNullOrEmpty(document.Path))
            {
                return SaveDocumentAs(document, forceSaveAsMd ? "Markdown 文件 (*.md)|*.md" : "Markdown 文件 (*.md)|*.md|文本文件 (*.txt)|*.txt", forceSaveAsMd ? ".md" : ".md");
            }

            try
            {
                FileManager.Save(document.Path, document.Content);
                document.IsDirty = false;
                UpdateTabHeader();
                AddRecentFile(document.Path);
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("保存失败：" + ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
        }

        private bool SaveDocumentAs(Document document, string filter, string defaultExtension)
        {
            var dialog = new Microsoft.Win32.SaveFileDialog
            {
                Filter = filter,
                DefaultExt = defaultExtension,
                FileName = string.IsNullOrEmpty(document.Path) ? document.Title : System.IO.Path.GetFileNameWithoutExtension(document.Path),
                AddExtension = true
            };

            if (dialog.ShowDialog(this) == true)
            {
                FileManager.Save(dialog.FileName, document.Content);
                document.Path = dialog.FileName;
                document.IsDirty = false;
                UpdateTabHeader();
                AddRecentFile(dialog.FileName);
                return true;
            }

            return false;
        }

        private void NewFile_Click(object sender, RoutedEventArgs e) => NewDocument();

        private void OpenFile_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.OpenFileDialog
            {
                Filter = "所有文件 (*.*)|*.*|Markdown 文件 (*.md)|*.md|文本文件 (*.txt)|*.txt",
                Multiselect = true
            };

            if (dialog.ShowDialog(this) == true)
            {
                foreach (var file in dialog.FileNames)
                {
                    OpenDocument(file);
                }
            }
        }

        private void SaveFile_Click(object sender, RoutedEventArgs e) => SaveCurrentDocument(false);

        private void SaveAsMd_Click(object sender, RoutedEventArgs e)
        {
            var document = GetCurrentDocument();
            if (document == null)
            {
                return;
            }

            SaveDocumentAs(document, "Markdown 文件 (*.md)|*.md", ".md");
        }

        private void SaveAsTxt_Click(object sender, RoutedEventArgs e)
        {
            var document = GetCurrentDocument();
            if (document == null) return;

            var dialog = new Microsoft.Win32.SaveFileDialog
            {
                Filter = "文本文件 (*.txt)|*.txt",
                DefaultExt = ".txt",
                FileName = string.IsNullOrEmpty(document.Path) ? document.Title : System.IO.Path.GetFileNameWithoutExtension(document.Path)
            };

            if (dialog.ShowDialog(this) == true)
            {
                FileService.SaveAsText(document.Content, dialog.FileName);
                AddRecentFile(dialog.FileName);
            }
        }

        private void ExportHtml_Click(object sender, RoutedEventArgs e)
        {
            var document = GetCurrentDocument();
            if (document == null) return;

            var dialog = new Microsoft.Win32.SaveFileDialog
            {
                Filter = "HTML 文件 (*.html)|*.html",
                DefaultExt = ".html",
                FileName = string.IsNullOrEmpty(document.Path) ? document.Title : System.IO.Path.GetFileNameWithoutExtension(document.Path)
            };

            if (dialog.ShowDialog(this) == true)
            {
                FileService.SaveAsHtml(MarkdownConverter.ToHtml(document.Content, _settings.IsDarkTheme), dialog.FileName);
                AddRecentFile(dialog.FileName);
            }
        }

        private void ExportAll_Click(object sender, RoutedEventArgs e)
        {
            using var dialog = new Forms.FolderBrowserDialog
            {
                Description = "选择输出目录——所有已打开页面将保存到此文件夹",
                ShowNewFolderButton = true
            };

            if (dialog.ShowDialog() != Forms.DialogResult.OK) return;

            var folder = dialog.SelectedPath;
            var dateTag = DateTime.Now.ToString("yyyyMMddHHmm");
            var count = 0;

            foreach (var item in EditorTabs.Items.OfType<TabItem>())
            {
                if (item.Tag is not Document doc || item.Content is not MarkdownEditor editor)
                    continue;

                if (string.IsNullOrWhiteSpace(editor.Text))
                    continue;

                // Generate filename: tab title without *, append date if duplicate
                var title = doc.Title.Replace(" *", "").Replace("*", "");
                if (string.IsNullOrEmpty(title))
                    title = doc.DefaultTitle;

                var name = Path.GetFileNameWithoutExtension(title);
                if (string.IsNullOrEmpty(name))
                    name = title;

                // Clean invalid filename chars
                foreach (var c in Path.GetInvalidFileNameChars())
                    name = name.Replace(c.ToString(), "");

                var fileName = $"{name}_{dateTag}_{count + 1}.md";
                var fullPath = Path.Combine(folder, fileName);

                try
                {
                    File.WriteAllText(fullPath, editor.Text, Encoding.UTF8);
                    count++;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"无法保存 {fileName}：{ex.Message}", "导出失败",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }

            StatusText.Text = $"已导出 {count} 个文件 → {folder}";
            MessageBox.Show($"已成功导出 {count} 个文件到：\n{folder}", "全部输出完成",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void Print_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var field = typeof(System.Windows.Controls.WebBrowser).GetField(
                    "_axIWebBrowser2",
                    System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
                var axBrowser = field?.GetValue(PreviewWebView);
                axBrowser?.GetType().InvokeMember("ExecWB",
                    System.Reflection.BindingFlags.InvokeMethod, null, axBrowser,
                    new object[] { 6, 1 }); // OLECMDID_PRINT=6, OLECMDEXECOPT_PROMPTUSER=1
            }
            catch
            {
                MessageBox.Show("打印功能不可用。", "提示", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private bool CloseSingleTab(TabItem tab)
        {
            if (tab.Tag is Document doc && doc.IsDirty)
            {
                var result = MessageBox.Show(
                    $"是否保存 \"{doc.Title}\" 的更改？",
                    "MD文本编辑器", MessageBoxButton.YesNoCancel, MessageBoxImage.Warning);
                if (result == MessageBoxResult.Cancel)
                    return false;
                if (result == MessageBoxResult.Yes)
                {
                    if (!SaveCurrentDocument(false))
                        return false;
                }
            }
            EditorTabs.Items.Remove(tab);
            return true;
        }

        private void CloseTab_Click(object sender, RoutedEventArgs e)
        {
            if (EditorTabs.SelectedItem is TabItem tab)
            {
                CloseSingleTab(tab);
            }
            RefreshEditorState();
        }

        private static T? FindAncestor<T>(DependencyObject? child) where T : DependencyObject
        {
            while (child != null)
            {
                if (child is T t) return t;
                child = VisualTreeHelper.GetParent(child);
            }
            return null;
        }

        private void CloseTabButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is DependencyObject dobj && FindAncestor<TabItem>(dobj) is TabItem tab)
            {
                CloseSingleTab(tab);
            }
            RefreshEditorState();
        }

        private void Context_CloseCurrent_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem menuItem)
            {
                var menu = FindAncestor<ContextMenu>(menuItem);
                if (menu?.PlacementTarget is TabItem tab)
                {
                    CloseSingleTab(tab);
                }
            }
            RefreshEditorState();
        }

        private void Context_CloseOthers_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem menuItem)
            {
                var menu = FindAncestor<ContextMenu>(menuItem);
                if (menu?.PlacementTarget is TabItem current)
                {
                    var toClose = EditorTabs.Items.OfType<TabItem>().Where(t => t != current).ToList();
                    foreach (var t in toClose) EditorTabs.Items.Remove(t);
                    EditorTabs.SelectedItem = current;
                }
            }
        }

        private void Context_CloseAll_Click(object sender, RoutedEventArgs e)
        {
            EditorTabs.Items.Clear();
            RefreshEditorState();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Undo_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor?.CanUndo == true)
            {
                editor.Undo();
            }
        }

        private void Redo_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor?.CanRedo == true)
            {
                editor.Redo();
            }
        }

        private void Cut_Click(object sender, RoutedEventArgs e)
        {
            GetCurrentEditor()?.Cut();
        }

        private void Copy_Click(object sender, RoutedEventArgs e)
        {
            GetCurrentEditor()?.Copy();
        }

        private void CopyAsPlainText_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor != null)
            {
                ClipboardService.CopyPlainText(editor.SelectedText.Length > 0 ? editor.SelectedText : editor.Text);
            }
        }

        private void CopyAsMarkdown_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor != null)
            {
                ClipboardService.CopyMarkdown(editor.SelectedText.Length > 0 ? editor.SelectedText : editor.Text);
            }
        }

        private void CopyAsHtml_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor != null)
            {
                ClipboardService.CopyHtml(editor.SelectedText.Length > 0 ? editor.SelectedText : editor.Text);
            }
        }

        private void Paste_Click(object sender, RoutedEventArgs e)
        {
            GetCurrentEditor()?.Paste();
        }

        private void PastePlainText_Click(object sender, RoutedEventArgs e)
        {
            if (GetCurrentEditor() is { } editor)
            {
                editor.ReplaceSelectedText(Clipboard.GetText(TextDataFormat.Text));
            }
        }

        private void SelectAll_Click(object sender, RoutedEventArgs e)
        {
            GetCurrentEditor()?.SelectAll();
        }

        private void FindReplace_Click(object sender, RoutedEventArgs e)
        {
            ShowFindReplaceDialog();
        }

        private void FindNextShortcut()
        {
            if (string.IsNullOrEmpty(_lastSearchText)) return;
            var editor = GetCurrentEditor();
            if (editor == null) return;
            if (!editor.FindNext(_lastSearchText, _lastSearchMatchCase, _lastSearchUseRegex))
                StatusText.Text = "未找到匹配项";
        }

        public void RememberSearch(string text, bool matchCase, bool useRegex)
        {
            _lastSearchText = text;
            _lastSearchMatchCase = matchCase;
            _lastSearchUseRegex = useRegex;
        }

        private void ShowFindReplaceDialog()
        {
            var editor = GetCurrentEditor();
            if (editor == null)
            {
                return;
            }

            var window = new FindReplaceWindow(editor, this)
            {
                Owner = this
            };
            window.Show();
        }

        private void GoToLine_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor == null) return;

            var dialog = new GoToLineDialog(editor.LineCount)
            {
                Owner = this
            };
            if (dialog.ShowDialog() == true)
            {
                editor.GoToLine(dialog.LineNumber - 1);
            }
        }

        private void SourceMode_Click(object sender, RoutedEventArgs e) => ApplyViewState(ViewLayout.SourceOnly);

        private void PreviewMode_Click(object sender, RoutedEventArgs e) => ApplyViewState(ViewLayout.PreviewOnly);

        private void SplitVertical_Click(object sender, RoutedEventArgs e) => ApplyViewState(ViewLayout.SplitVertical);

        private void SplitHorizontal_Click(object sender, RoutedEventArgs e) => ApplyViewState(ViewLayout.SplitHorizontal);

        private void FullView_Click(object sender, RoutedEventArgs e) => ApplyViewState(ViewLayout.FullView);

        private void StandardView_Click(object sender, RoutedEventArgs e) => ApplyViewState(ViewLayout.StandardView);

        private void DefaultView_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem item && item.Tag is string tag && Enum.TryParse<ViewMode>(tag, out var mode))
            {
                _settings.DefaultView = mode;
                SettingsService.Save(_settings);
                UpdateDefaultViewCheckMarks();
            }
        }

        private void UpdateDefaultViewCheckMarks()
        {
            foreach (MenuItem item in DefaultViewMenu.Items)
            {
                if (item.Tag is string tag && Enum.TryParse<ViewMode>(tag, out var mode))
                {
                    item.IsChecked = mode == _settings.DefaultView;
                }
            }
        }

        private void ApplyViewMode(ViewMode mode)
        {
            ApplyViewState(mode switch
            {
                ViewMode.SourceOnly => ViewLayout.SourceOnly,
                ViewMode.PreviewOnly => ViewLayout.PreviewOnly,
                ViewMode.SplitVertical => ViewLayout.SplitVertical,
                ViewMode.SplitHorizontal => ViewLayout.SplitHorizontal,
                ViewMode.FullView => ViewLayout.FullView,
                ViewMode.StandardView => ViewLayout.StandardView,
                ViewMode.CustomView => ViewLayout.CustomView(
                    _settings.CustomSidebarRatio, _settings.CustomEditorRatio, _settings.CustomPreviewRatio),
                _ => ViewLayout.FullView
            });
        }

        private void CustomView_Click(object sender, RoutedEventArgs e) => ApplyCustomView();

        private void CustomViewSettings_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new CustomViewDialog(_settings.CustomSidebarRatio, _settings.CustomEditorRatio, _settings.CustomPreviewRatio)
            {
                Owner = this
            };
            if (dialog.ShowDialog() == true)
            {
                _settings.CustomSidebarRatio = dialog.SidebarRatio;
                _settings.CustomEditorRatio = dialog.EditorRatio;
                _settings.CustomPreviewRatio = dialog.PreviewRatio;
                SettingsService.Save(_settings);
                ApplyCustomView();
            }
        }

        private void ApplyCustomView()
        {
            ApplyViewState(ViewLayout.CustomView(
                _settings.CustomSidebarRatio, _settings.CustomEditorRatio, _settings.CustomPreviewRatio));
        }

        private static void SetGridPosition(UIElement element, int row, int col, int rowSpan, int colSpan)
        {
            Grid.SetRow(element, row);
            Grid.SetColumn(element, col);
            Grid.SetRowSpan(element, rowSpan);
            Grid.SetColumnSpan(element, colSpan);
        }

        private void ApplyViewState(ViewLayout layout)
        {
            _currentViewLayout = layout;

            // Sidebar
            if (Sidebar != null && SidebarColumn != null)
            {
                if (layout.Sidebar == PanelState.Visible)
                {
                    Sidebar.Visibility = Visibility.Visible;
                    SidebarColumn.Width = new GridLength(250);
                    var outerGrid = Sidebar.Parent as Grid;
                    if (outerGrid != null)
                        outerGrid.ColumnDefinitions[1].Width = new GridLength(1, GridUnitType.Star);
                }
                else
                {
                    Sidebar.Visibility = Visibility.Collapsed;
                    SidebarColumn.Width = new GridLength(0);
                    var outerGrid = Sidebar.Parent as Grid;
                    if (outerGrid != null)
                        outerGrid.ColumnDefinitions[1].Width = new GridLength(1, GridUnitType.Star);
                }
            }

            bool bothVisible = layout.Editor == PanelState.Visible && layout.Preview == PanelState.Visible;

            if (bothVisible)
            {
                if (layout.IsVerticalSplit)
                {
                    MainGrid.RowDefinitions[1].Height = new GridLength(0);
                    MainGrid.ColumnDefinitions[0].Width = new GridLength(layout.EditorRatio, GridUnitType.Star);
                    MainGrid.ColumnDefinitions[1].Width = new GridLength(5);
                    MainGrid.ColumnDefinitions[2].Width = new GridLength(layout.PreviewRatio, GridUnitType.Star);
                    PreviewSplitter.ResizeDirection = GridResizeDirection.Columns;
                    SetGridPosition(EditorTabs, 0, 0, 3, 1);
                    SetGridPosition(PreviewSplitter, 0, 1, 3, 1);
                    SetGridPosition(PreviewBorder, 0, 2, 3, 1);
                }
                else
                {
                    MainGrid.ColumnDefinitions[1].Width = new GridLength(10);
                    MainGrid.RowDefinitions[0].Height = new GridLength(layout.EditorRatio, GridUnitType.Star);
                    MainGrid.RowDefinitions[1].Height = new GridLength(5);
                    MainGrid.RowDefinitions[2].Height = new GridLength(layout.PreviewRatio, GridUnitType.Star);
                    PreviewSplitter.ResizeDirection = GridResizeDirection.Rows;
                    SetGridPosition(EditorTabs, 0, 0, 1, 3);
                    SetGridPosition(PreviewSplitter, 1, 0, 1, 3);
                    SetGridPosition(PreviewBorder, 2, 0, 1, 3);
                }
                EditorTabs.Visibility = Visibility.Visible;
                PreviewBorder.Visibility = Visibility.Visible;
                PreviewSplitter.Visibility = Visibility.Visible;
            }
            else if (layout.Editor == PanelState.Visible)
            {
                MainGrid.ColumnDefinitions[0].Width = new GridLength(1, GridUnitType.Star);
                MainGrid.ColumnDefinitions[1].Width = new GridLength(10);
                MainGrid.ColumnDefinitions[2].Width = new GridLength(0);
                MainGrid.RowDefinitions[1].Height = new GridLength(0);
                SetGridPosition(EditorTabs, 0, 0, 3, 3);
                EditorTabs.Visibility = Visibility.Visible;
                PreviewBorder.Visibility = Visibility.Collapsed;
                PreviewSplitter.Visibility = Visibility.Collapsed;
            }
            else
            {
                MainGrid.ColumnDefinitions[0].Width = new GridLength(0);
                MainGrid.ColumnDefinitions[1].Width = new GridLength(10);
                MainGrid.ColumnDefinitions[2].Width = new GridLength(1, GridUnitType.Star);
                MainGrid.RowDefinitions[1].Height = new GridLength(0);
                SetGridPosition(PreviewBorder, 0, 0, 3, 3);
                EditorTabs.Visibility = Visibility.Collapsed;
                PreviewBorder.Visibility = Visibility.Visible;
                PreviewSplitter.Visibility = Visibility.Collapsed;
            }

            StatusText.Text = layout.Label;
        }

        private void FullScreen_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
        }

        private void FocusMode_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("聚焦模式将在后续版本中完善。", "提示", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ToggleOutline_Click(object sender, RoutedEventArgs e)
        {
            if (OutlineView != null)
            {
                OutlineView.Visibility = OutlineView.Visibility == Visibility.Visible ? Visibility.Collapsed : Visibility.Visible;
                StatusText.Text = OutlineView.Visibility == Visibility.Visible ? "大纲：已显示" : "大纲：已隐藏";
            }
        }

        private void ToggleFileTree_Click(object sender, RoutedEventArgs e)
            => ToggleSidebar_Click(sender, e);

        private void SidebarToggleButton_Click(object sender, RoutedEventArgs e)
        {
            ToggleSidebar_Click(sender, e);
        }

        private void LineNumberToggleButton_Click(object sender, RoutedEventArgs e)
        {
            ToggleLineNumbers_Click(sender, e);
        }

        private void BoundaryButton_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e)
        {
            if (sender is System.Windows.Controls.Button btn)
            {
                btn.Opacity = 1.0;
            }
        }

        private void BoundaryButton_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {
            if (sender is System.Windows.Controls.Button btn)
            {
                btn.Opacity = 0.7;
            }
        }

        private void EditorToggleButton_Click(object sender, RoutedEventArgs e)
        {
            var cur = _currentViewLayout;
            if (cur.Editor == PanelState.Visible && cur.Preview == PanelState.Visible)
                ApplyViewState(ViewLayout.PreviewOnly);
            else if (cur.Editor == PanelState.Visible)
                ApplyViewState(ViewLayout.PreviewOnly);
            else if (cur.Preview == PanelState.Visible)
                ApplyViewState(ViewLayout.SplitVertical);
            else
                ApplyViewState(ViewLayout.SourceOnly);
        }

        private void PreviewToggleButton_Click(object sender, RoutedEventArgs e)
        {
            var cur = _currentViewLayout;
            if (cur.Editor == PanelState.Visible && cur.Preview == PanelState.Visible)
                ApplyViewState(ViewLayout.SourceOnly);
            else if (cur.Preview == PanelState.Visible)
                ApplyViewState(ViewLayout.SourceOnly);
            else if (cur.Editor == PanelState.Visible)
                ApplyViewState(ViewLayout.SplitVertical);
            else
                ApplyViewState(ViewLayout.PreviewOnly);
        }

        private void ToggleSidebar_Click(object sender, RoutedEventArgs e)
        {
            if (Sidebar != null && SidebarColumn != null)
            {
                var isVisible = Sidebar.Visibility == Visibility.Visible;
                Sidebar.Visibility = isVisible ? Visibility.Collapsed : Visibility.Visible;
                SidebarColumn.Width = isVisible ? new GridLength(0) : new GridLength(250);
    
                StatusText.Text = Sidebar.Visibility == Visibility.Visible ? "侧边栏：已显示" : "侧边栏：已隐藏";
            }
        }

        private void Window_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
        {
            if (Keyboard.Modifiers != ModifierKeys.Control)
                return;

            var editor = GetCurrentEditor();
            if (editor == null)
                return;

            if (e.Delta > 0)
                editor.ZoomIn();
            else
                editor.ZoomOut();

            e.Handled = true;
        }

        private void ZoomIn_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor != null)
            {
                editor.ZoomIn();
            }
        }

        private void ZoomOut_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor != null)
            {
                editor.ZoomOut();
            }
        }

        private void ResetZoom_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            editor?.ResetZoom();
        }

        private void ToggleTheme_Click(object sender, RoutedEventArgs e)
        {
            _settings.IsDarkTheme = !_settings.IsDarkTheme;
            SettingsService.Save(_settings);
            ApplyTheme();
            UpdatePreview();
        }

        private void Heading_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem item && int.TryParse(item.Tag?.ToString(), out var level))
            {
                InsertHeading(level);
            }
        }

        private void InsertHeading(int level)
        {
            var prefix = new string('#', Math.Max(1, Math.Min(level, 6))) + " ";
            WrapSelection(prefix, string.Empty);
        }

        private void Bold_Click(object sender, RoutedEventArgs e) => WrapSelection("**", "**");
        private void Italic_Click(object sender, RoutedEventArgs e) => WrapSelection("*", "*");
        private void Strikethrough_Click(object sender, RoutedEventArgs e) => WrapSelection("~~", "~~");
        private void InlineCode_Click(object sender, RoutedEventArgs e) => WrapSelection("`", "`");
        private void CodeBlock_Click(object sender, RoutedEventArgs e) => WrapSelection("```\r\n", "\r\n```");
        private void BlockQuote_Click(object sender, RoutedEventArgs e) => WrapSelection("> ", string.Empty);
        private void UnorderedList_Click(object sender, RoutedEventArgs e) => ApplyPerLinePrefix("- ");
        private void OrderedList_Click(object sender, RoutedEventArgs e) => ApplyOrderedList();
        private void TaskList_Click(object sender, RoutedEventArgs e) => ApplyPerLinePrefix("- [ ] ");
        private void Link_Click(object sender, RoutedEventArgs e) => WrapSelection("[", "]()" );
        private void Image_Click(object sender, RoutedEventArgs e) => WrapSelection("![", "]()" );
        private string _editorFontFamily;
        private double _editorFontSize;

        private void PopulateFontMenu()
        {
            FontMenu.Items.Clear();

            // Common English fonts
            var enFonts = new[] { "Consolas", "Courier New", "Arial", "Times New Roman", "Segoe UI", "Verdana", "Calibri", "Lucida Console" };
            foreach (var name in enFonts)
            {
                var item = new MenuItem { Header = name, Tag = name };
                item.Click += Font_Click;
                FontMenu.Items.Add(item);
            }

            FontMenu.Items.Add(new Separator());

            // System Chinese fonts — show Chinese display name, store English source for FontFamily
            var cnList = new List<(string eng, string cn)>();
            var seen = new HashSet<string>();
            try
            {
                var zhLang = System.Windows.Markup.XmlLanguage.GetLanguage("zh-cn");
                foreach (var f in System.Windows.Media.Fonts.SystemFontFamilies)
                {
                    var cn = f.FamilyNames.TryGetValue(zhLang, out var zhName) ? zhName : null;
                    if (string.IsNullOrEmpty(cn))
                    {
                        // Fallback: check if Source contains CJK characters
                        if (f.Source.Any(c => c >= 0x4E00 && c <= 0x9FFF))
                            cn = f.Source;
                    }
                    if (!string.IsNullOrEmpty(cn) && !seen.Contains(cn))
                    {
                        seen.Add(cn);
                        cnList.Add((f.Source, cn));
                    }
                }
            }
            catch { }

            if (cnList.Count == 0)
                cnList.AddRange(new[] {
                    ("SimSun", "宋体"), ("SimHei", "黑体"), ("KaiTi", "楷体"),
                    ("FangSong", "仿宋"), ("Microsoft YaHei", "微软雅黑")
                });

            cnList.Sort((a, b) => string.Compare(a.cn, b.cn));
            foreach (var (eng, cn) in cnList)
            {
                var item = new MenuItem { Header = cn, Tag = eng };
                item.Click += Font_Click;
                FontMenu.Items.Add(item);
            }
        }

        private void Font_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not MenuItem item || item.Tag is not string fontName)
                return;

            try
            {
                _editorFontFamily = fontName;
                _settings.EditorFontFamily = fontName;
                SettingsService.Save(_settings);
                ApplyFontToAllEditors();
                StatusText.Text = $"显示字体：{fontName}";
            }
            catch
            {
                StatusText.Text = $"字体无效：{fontName}";
            }
        }

        private void FontSize_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem item && item.Tag is string size)
            {
                if (TryParseFontSize(size, out var px))
                {
                    _editorFontSize = px;
                    _settings.EditorFontSize = px;
                    SettingsService.Save(_settings);
                    ApplyFontToAllEditors();
                }
            }
        }

        private void FontSizeCustom_Click(object sender, RoutedEventArgs e)
        {
            var input = ShowInputDialog("自定义字号", "请输入字号数值（如 12、16、20）：", "16");
            if (!string.IsNullOrWhiteSpace(input) && double.TryParse(input, out var px) && px > 0)
            {
                _editorFontSize = px;
                _settings.EditorFontSize = px;
                SettingsService.Save(_settings);
                ApplyFontToAllEditors();
            }
        }

        private void ApplyFontToAllEditors()
        {
            foreach (var tab in EditorTabs.Items.OfType<TabItem>())
            {
                if (tab.Content is MarkdownEditor editor)
                {
                    editor.SetFontFamily(_editorFontFamily);
                    editor.SetFontSize(_editorFontSize);
                }
            }
        }

        private static bool TryParseFontSize(string size, out double px)
        {
            px = 0;
            if (size.EndsWith("pt"))
            {
                if (double.TryParse(size.Replace("pt", ""), out var pt))
                {
                    px = Math.Round(pt * 4.0 / 3.0); // pt → WPF dip
                    return true;
                }
            }
            else if (size.EndsWith("px"))
            {
                return double.TryParse(size.Replace("px", ""), out px);
            }
            return false;
        }

        private static string? ShowInputDialog(string title, string prompt, string defaultValue)
        {
            var window = new Window
            {
                Title = title,
                Width = 360,
                Height = 160,
                ResizeMode = ResizeMode.NoResize,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                ShowInTaskbar = false
            };

            var grid = new System.Windows.Controls.Grid { Margin = new Thickness(12) };
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            var label = new System.Windows.Controls.Label { Content = prompt };
            System.Windows.Controls.Grid.SetRow(label, 0);

            var textBox = new System.Windows.Controls.TextBox { Text = defaultValue, Margin = new Thickness(0, 4, 0, 8) };
            System.Windows.Controls.Grid.SetRow(textBox, 1);

            var btnPanel = new System.Windows.Controls.StackPanel
            {
                Orientation = System.Windows.Controls.Orientation.Horizontal,
                HorizontalAlignment = System.Windows.HorizontalAlignment.Right
            };
            System.Windows.Controls.Grid.SetRow(btnPanel, 2);

            string? result = null;
            var okBtn = new System.Windows.Controls.Button { Content = "确定", Width = 70, Margin = new Thickness(4, 0, 0, 0), IsDefault = true };
            var cancelBtn = new System.Windows.Controls.Button { Content = "取消", Width = 70, Margin = new Thickness(4, 0, 0, 0), IsCancel = true };

            okBtn.Click += (_, _) => { result = textBox.Text; window.DialogResult = true; window.Close(); };
            cancelBtn.Click += (_, _) => { window.DialogResult = false; window.Close(); };

            btnPanel.Children.Add(okBtn);
            btnPanel.Children.Add(cancelBtn);

            grid.Children.Add(label);
            grid.Children.Add(textBox);
            grid.Children.Add(btnPanel);
            window.Content = grid;

            window.ShowDialog();
            return result;
        }

        private void Table_Click(object sender, RoutedEventArgs e) => WrapSelection("| 列1 | 列2 |\r\n| --- | --- |\r\n", string.Empty);
        private void HorizontalRule_Click(object sender, RoutedEventArgs e) => WrapSelection("---\r\n", string.Empty);

        private void WordCount_Click(object sender, RoutedEventArgs e)
        {
            var document = GetCurrentDocument();
            if (document != null)
            {
                var content = document.Content ?? string.Empty;
                var words = content.Split(new[] { ' ', '\r', '\n', '\t' }, StringSplitOptions.RemoveEmptyEntries).Length;
                MessageBox.Show($"当前文档字数：{words}", "字数统计", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void SpellCheck_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("拼写检查功能将在后续版本中集成。", "拼写检查", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void TableEditor_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("表格编辑器功能将在后续版本中完成。", "表格编辑器", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void InsertMath_Click(object sender, RoutedEventArgs e)
        {
            WrapSelection("$$\r\n", "\r\n$$");
        }

        private void InsertMermaid_Click(object sender, RoutedEventArgs e)
        {
            WrapSelection("```mermaid\r\n", "\r\n```\r\n");
        }

        private void InsertToc_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor == null) return;

            var lines = editor.Text.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
            var toc = new StringBuilder();
            toc.AppendLine("<!-- TOC -->");

            foreach (var line in lines)
            {
                var trimmed = line.TrimStart();
                if (!trimmed.StartsWith("#")) continue;

                var level = trimmed.TakeWhile(c => c == '#').Count();
                if (level < 1 || level > 6) continue;

                // Must have a space after # markers to be a proper heading
                if (trimmed.Length <= level || trimmed[level] != ' ') continue;

                var title = trimmed[(level + 1)..].Trim();
                if (string.IsNullOrWhiteSpace(title)) continue;

                var anchor = GenerateAnchor(title);
                var indent = new string(' ', (level - 1) * 2);
                toc.AppendLine($"{indent}- [{title}](#{anchor})");
            }

            toc.AppendLine();
            editor.InsertTextAtCaret(toc.ToString());
        }

        private static string GenerateAnchor(string heading)
        {
            var sb = new StringBuilder();
            var lastWasDash = false;
            foreach (var c in heading.ToLowerInvariant())
            {
                if (char.IsLetterOrDigit(c))
                {
                    sb.Append(c);
                    lastWasDash = false;
                }
                else if (!lastWasDash && (c == ' ' || c == '-' || c == '_'))
                {
                    sb.Append('-');
                    lastWasDash = true;
                }
                else if (c > 127)
                {
                    // Preserve CJK and other non-ASCII characters
                    sb.Append(c);
                    lastWasDash = false;
                }
            }
            // Trim trailing dashes
            while (sb.Length > 0 && sb[^1] == '-')
                sb.Length--;
            return sb.ToString();
        }

        private void Settings_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("设置窗口将在后续版本中添加。", "设置", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void HelpDoc_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("请参阅项目文档以获取更多帮助。", "帮助文档", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ShortcutReference_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("快捷键参考功能将在后续版本中完善。", "快捷键参考", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void SetDefaultApp_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var exePath = Environment.ProcessPath;
                if (string.IsNullOrEmpty(exePath) || !File.Exists(exePath))
                {
                    MessageBox.Show("无法获取程序路径，请将程序放置到固定目录后再试。", "设置失败", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                var progId = "MDEditor.md";

                // 1. Register ProgId with shell open command
                using (var progKey = Registry.CurrentUser.CreateSubKey($@"Software\Classes\{progId}"))
                    progKey?.SetValue("", "MD 文本编辑器文档");

                using (var iconKey = Registry.CurrentUser.CreateSubKey($@"Software\Classes\{progId}\DefaultIcon"))
                    iconKey?.SetValue("", $"\"{exePath}\",0");

                using (var cmdKey = Registry.CurrentUser.CreateSubKey($@"Software\Classes\{progId}\shell\open\command"))
                    cmdKey?.SetValue("", $"\"{exePath}\" \"%1\"");

                // 2. Register extension → ProgId mapping
                using (var extKey = Registry.CurrentUser.CreateSubKey(@"Software\Classes\.md"))
                {
                    if (extKey == null) throw new Exception("无法写入注册表");
                    extKey.SetValue("", progId);
                    using (var owp = extKey.CreateSubKey("OpenWithProgids"))
                        owp?.SetValue(progId, "");
                }

                // 3. Clear existing UserChoice so our ProgId mapping takes effect
                try
                {
                    var fileExtsPath = @"Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.md";
                    Registry.CurrentUser.DeleteSubKeyTree(fileExtsPath + @"\UserChoice", false);
                }
                catch { }

                // 4. Create a temp .md file and open the "Open With" dialog so user can confirm
                var result = MessageBox.Show(
                    "注册表已更新。是否立即打开系统关联对话框确认？\n\n" +
                    "(选择\"MD文本编辑器\"后勾选\"始终使用此应用打开\"即可完成设置)",
                    "设置默认程序", MessageBoxButton.YesNo, MessageBoxImage.Information);

                if (result == MessageBoxResult.Yes)
                {
                    var tempMd = Path.Combine(Path.GetTempPath(), "md_association_setup.md");
                    File.WriteAllText(tempMd, "# Test");
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                    {
                        FileName = "rundll32.exe",
                        Arguments = $"shell32.dll,OpenAs_RunDLL \"{tempMd}\"",
                        UseShellExecute = false
                    });
                }

                StatusText.Text = "已注册 .md 文件关联";
            }
            catch (Exception ex)
            {
                MessageBox.Show("设置默认程序失败：" + ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RemoveDefaultApp_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Remove ProgId registration
                Registry.CurrentUser.DeleteSubKeyTree(@"Software\Classes\MDEditor.md", false);
            }
            catch { }

            try
            {
                // Remove extension mapping (only if it points to us)
                using (var extKey = Registry.CurrentUser.OpenSubKey(@"Software\Classes\.md", writable: true))
                {
                    if (extKey?.GetValue("") as string == "MDEditor.md")
                    {
                        extKey.DeleteValue("");
                    }
                    // Remove our OpenWithProgids entry
                    try { extKey?.DeleteSubKeyTree("OpenWithProgids", false); } catch { }
                }
            }
            catch { }

            try
            {
                // Clear UserChoice if it references our ProgId
                var ucPath = @"Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.md\UserChoice";
                using (var ucKey = Registry.CurrentUser.OpenSubKey(ucPath, writable: true))
                {
                    if (ucKey?.GetValue("Progid") as string == "MDEditor.md")
                    {
                        Registry.CurrentUser.DeleteSubKeyTree(ucPath, false);
                    }
                }
            }
            catch { }

            StatusText.Text = "已取消 .md 文件默认关联";
            MessageBox.Show("已取消本程序与 .md 文件的关联。", "已取消", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void About_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("MD文本编辑器 for Win11\n版本：v2.57.202605242121\n作者：帅气的锅巴", "关于", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void WrapSelection(string prefix, string suffix)
        {
            var editor = GetCurrentEditor();
            if (editor == null)
            {
                return;
            }

            var selection = editor.SelectedText;
            if (string.IsNullOrEmpty(selection))
            {
                editor.InsertTextAtCaret(prefix + suffix);
            }
            else
            {
                editor.ReplaceSelectedText(prefix + selection + suffix);
            }
        }

        private void ApplyPerLinePrefix(string prefix)
        {
            var editor = GetCurrentEditor();
            if (editor == null) return;

            var selection = editor.SelectedText;
            if (string.IsNullOrEmpty(selection))
            {
                editor.InsertTextAtCaret(prefix);
                return;
            }

            var lines = selection.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
            var sb = new StringBuilder();
            for (var i = 0; i < lines.Length; i++)
            {
                if (i > 0) sb.AppendLine();
                if (!string.IsNullOrWhiteSpace(lines[i]))
                    sb.Append(prefix + lines[i]);
                else
                    sb.Append(lines[i]);
            }
            editor.ReplaceSelectedText(sb.ToString());
        }

        private void ApplyOrderedList()
        {
            var editor = GetCurrentEditor();
            if (editor == null) return;

            var selection = editor.SelectedText;
            if (string.IsNullOrEmpty(selection))
            {
                editor.InsertTextAtCaret("1. ");
                return;
            }

            var lines = selection.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
            var sb = new StringBuilder();
            var num = 1;
            for (var i = 0; i < lines.Length; i++)
            {
                if (i > 0) sb.AppendLine();
                if (!string.IsNullOrWhiteSpace(lines[i]))
                {
                    sb.Append(num + ". " + lines[i]);
                    num++;
                }
                else
                {
                    sb.Append(lines[i]);
                }
            }
            editor.ReplaceSelectedText(sb.ToString());
        }

        private void EditorTabs_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdatePreview();
        }
    }
}

using System.IO;
using System.IO.Pipes;
using System.Windows;
using System.Windows.Threading;

namespace MDEditor
{
    public partial class App : System.Windows.Application
    {
        private const string AppMutexName = "MDEditor_SingleInstance_v2";
        private const string PipeName = "MDEditor_Pipe_v2";
        private static Mutex? _mutex;
        private static MainWindow? _mainWindow;
        private static CancellationTokenSource? _pipeCts;

        protected override void OnStartup(StartupEventArgs e)
        {
            // Global exception handlers
            DispatcherUnhandledException += (_, args) =>
            {
                try { File.AppendAllText(Path.Combine(Path.GetTempPath(), "MDEditor_crash.log"), $"[{DateTime.Now}] UI: {args.Exception}\n"); }
                catch { }
                args.Handled = true;
            };
            AppDomain.CurrentDomain.UnhandledException += (_, args) =>
            {
                try { File.AppendAllText(Path.Combine(Path.GetTempPath(), "MDEditor_crash.log"), $"[{DateTime.Now}] BG: {args.ExceptionObject}\n"); }
                catch { }
            };
            TaskScheduler.UnobservedTaskException += (_, args) =>
            {
                try { File.AppendAllText(Path.Combine(Path.GetTempPath(), "MDEditor_crash.log"), $"[{DateTime.Now}] Task: {args.Exception}\n"); }
                catch { }
                args.SetObserved();
            };

            _mutex = new Mutex(true, AppMutexName, out bool createdNew);

            if (!createdNew)
            {
                foreach (var arg in e.Args)
                {
                    if (File.Exists(arg))
                        SendToExistingInstance(Path.GetFullPath(arg));
                }
                _mutex.Dispose();
                Environment.Exit(0);
                return;
            }

            base.OnStartup(e);

            _mainWindow = new MainWindow();
            _mainWindow.Closed += (_, _) =>
            {
                _pipeCts?.Cancel();
                _mutex?.ReleaseMutex();
                _mutex?.Dispose();
            };

            _pipeCts = new CancellationTokenSource();
            _ = StartPipeServer(_pipeCts.Token);
            _mainWindow.Show();
        }

        private static void SendToExistingInstance(string filePath)
        {
            try
            {
                using var client = new NamedPipeClientStream(".", PipeName, PipeDirection.Out);
                client.Connect(2000);
                using var writer = new StreamWriter(client);
                writer.WriteLine(filePath);
                writer.Flush();
            }
            catch
            {
                // Pipe not available — existing instance may still be starting
            }
        }

        private static async Task StartPipeServer(CancellationToken ct)
        {
            try
            {
                while (!ct.IsCancellationRequested)
                {
                    try
                    {
                        using var server = new NamedPipeServerStream(PipeName, PipeDirection.In, 1);
                        await server.WaitForConnectionAsync(ct);
                        using var reader = new StreamReader(server);
                        var filePath = await reader.ReadLineAsync(ct);
                        if (!string.IsNullOrEmpty(filePath) && _mainWindow != null)
                        {
                            _ = _mainWindow.Dispatcher.BeginInvoke(new Action(() =>
                            {
                                try
                                {
                                    _mainWindow.OpenDocumentFromExternal(filePath);
                                }
                                catch { }
                            }));
                        }
                    }
                    catch (OperationCanceledException)
                    {
                        break;
                    }
                    catch
                    {
                        // Pipe broken — restart listener
                    }
                }
            }
            catch
            {
                // Server stopped
            }
        }
    }
}

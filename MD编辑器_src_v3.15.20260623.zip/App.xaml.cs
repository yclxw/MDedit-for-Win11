using System.IO;
using System.Windows;
using System.Windows.Threading;

namespace MDEditor
{
    public partial class App : System.Windows.Application
    {
        private static MainWindow? _mainWindow;

        protected override void OnStartup(StartupEventArgs e)
        {
            // Global exception handlers — 便携版本：日志写入 exe 所在目录
            var crashLogPath = Path.Combine(
                Path.GetDirectoryName(PlatformHelper.ExePath) ?? ".", "MDEditor_crash.log");
            DispatcherUnhandledException += (_, args) =>
            {
                try { File.AppendAllText(crashLogPath, $"[{DateTime.Now}] UI: {args.Exception}\n"); }
                catch { }
                args.Handled = true;
            };
            AppDomain.CurrentDomain.UnhandledException += (_, args) =>
            {
                try { File.AppendAllText(crashLogPath, $"[{DateTime.Now}] BG: {args.ExceptionObject}\n"); }
                catch { }
            };
            TaskScheduler.UnobservedTaskException += (_, args) =>
            {
                try { File.AppendAllText(crashLogPath, $"[{DateTime.Now}] Task: {args.Exception}\n"); }
                catch { }
                args.SetObserved();
            };

            base.OnStartup(e);

            _mainWindow = new MainWindow();
            _mainWindow.Show();
        }
    }
}

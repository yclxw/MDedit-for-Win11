using System.IO;
using System.Reflection;

namespace MDEditor
{
    internal static class PlatformHelper
    {
#if NET10_0_OR_GREATER
        public static string ExePath => Environment.ProcessPath ?? "";
#else
        public static string ExePath => Assembly.GetEntryAssembly()?.Location ?? "";
#endif
        public static string ExeDir => Path.GetDirectoryName(ExePath) ?? ".";

        public static int Clamp(int value, int min, int max) =>
            value < min ? min : value > max ? max : value;

        public static void MoveFile(string source, string dest, bool overwrite)
        {
            if (overwrite && File.Exists(dest))
                File.Delete(dest);
            File.Move(source, dest);
        }
    }
}

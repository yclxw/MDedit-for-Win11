# -*- coding: utf-8 -*-
import os, sys, zipfile

os.chdir(r'C:\kfaxM\MD编辑器\bak\source')
sys.stdout.reconfigure(encoding='utf-8')

items = sorted(os.listdir('.'))
print('Count:', len(items))
for f in items:
    print(repr(f))

param($zipPath)
Add-Type -AssemblyName System.IO.Compression.FileSystem
$z = [System.IO.Compression.ZipFile]::OpenRead($zipPath)
$i = 0
foreach($e in $z.Entries) {
    if($i -ge 50) {break}
    Write-Output ($e.FullName + " | " + $e.Length)
    $i++
}
$z.Dispose()

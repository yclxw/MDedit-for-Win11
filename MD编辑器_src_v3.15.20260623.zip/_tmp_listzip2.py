# -*- coding: utf-8 -*-
import os, sys, zipfile

srcdir = r'C:\kfaxM\MD编辑器\bak\source'
sys.stdout.reconfigure(encoding='utf-8')

print('=== Directory contents ===')
for f in sorted(os.listdir(srcdir)):
    fp = os.path.join(srcdir, f)
    isdir = os.path.isdir(fp)
    size = os.path.getsize(fp) if not isdir else 0
    try:
        print('DIR ' + f.encode('ascii', errors='replace').decode() + ' ' + str(size))
    except:
        print('FILE ' + repr(f) + ' ' + str(size))

print('=== Checking specific files ===')
for name in sorted(os.listdir(srcdir)):
    fp = os.path.join(srcdir, name)
    if name.endswith('.zip'):
        print('ZIP: ' + repr(name) + ' size=' + str(os.path.getsize(fp)))

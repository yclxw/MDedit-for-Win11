using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using MDEditor.Models;

namespace MDEditor.Services
{
    public enum ViewMode
    {
        SourceOnly,
        PreviewOnly,
        SplitVertical,
        SplitHorizontal,
        FullView,
        StandardView,
        CustomView
    }

    public sealed class AppSettings
    {
        public bool IsDarkTheme { get; set; }
        public string PreviewThemeName { get; set; } = "默认";
        public bool AutoSaveEnabled { get; set; }
        public int AutoSaveIntervalMinutes { get; set; } = 5;
        public List<string> RecentFiles { get; set; } = new List<string>();
        public string? LastOpenedFolder { get; set; }
        public ViewMode DefaultView { get; set; } = ViewMode.FullView;
        public int CustomSidebarRatio { get; set; } = 20;
        public int CustomEditorRatio { get; set; } = 40;
        public int CustomPreviewRatio { get; set; } = 40;
        public string EditorFontFamily { get; set; } = "Consolas";
        public double EditorFontSize { get; set; } = 14;
        public int LastActiveTabIndex { get; set; }
        public int NewDocCounter { get; set; }
    }

    public static class SettingsService
    {
        // 便携设计：配置文件存放在 exe 所在目录的 Data/ 子目录中
        private static readonly string ExeDir = MDEditor.PlatformHelper.ExeDir;
        private static readonly string AppFolder = Path.Combine(ExeDir, "Data");
        private static readonly string SettingsFile = Path.Combine(AppFolder, "settings.json");
        private static readonly string SessionFile = Path.Combine(AppFolder, "session.json");
        private static readonly object _fileLock = new();

        // 旧路径（%LOCALAPPDATA%\MDEditor），用于迁移
        private static readonly string OldAppFolder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "MDEditor");

        /// <summary>首次加载时自动将旧路径的配置文件迁移到新便携目录</summary>
        private static void TryMigrateFromOldLocation()
        {
            if (!Directory.Exists(OldAppFolder))
                return;

            if (!Directory.Exists(AppFolder))
                Directory.CreateDirectory(AppFolder);

            var oldSettings = Path.Combine(OldAppFolder, "settings.json");
            if (File.Exists(oldSettings) && !File.Exists(SettingsFile))
            {
                try { File.Copy(oldSettings, SettingsFile); File.Delete(oldSettings); } catch { }
            }

            var oldSession = Path.Combine(OldAppFolder, "session.json");
            if (File.Exists(oldSession))
            {
                try { File.Copy(oldSession, SessionFile, overwrite: true); File.Delete(oldSession); } catch { }
            }

            // 清理旧目录（如果已空），防止残留空目录
            try
            {
                if (Directory.Exists(OldAppFolder) &&
                    !Directory.EnumerateFileSystemEntries(OldAppFolder).Any())
                {
                    Directory.Delete(OldAppFolder);
                }
            }
            catch { }
        }

        static SettingsService()
        {
            TryMigrateFromOldLocation();
        }

        public static AppSettings Load()
        {
            lock (_fileLock)
            {
                try
                {
                    if (!Directory.Exists(AppFolder))
                    {
                        Directory.CreateDirectory(AppFolder);
                    }

                    if (!File.Exists(SettingsFile))
                    {
                        return new AppSettings();
                    }

                    var text = File.ReadAllText(SettingsFile);
                    return JsonSerializer.Deserialize<AppSettings>(text,
                        new JsonSerializerOptions { MaxDepth = 10 }) ?? new AppSettings();
                }
                catch
                {
                    return new AppSettings();
                }
            }
        }

        public static void Save(AppSettings settings)
        {
            lock (_fileLock)
            {
                try
                {
                    if (!Directory.Exists(AppFolder))
                    {
                        Directory.CreateDirectory(AppFolder);
                    }

                    var text = JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true });
                    // 原子写入：先写临时文件再重命名，防止写入中途崩溃导致配置文件损坏
                    var tmpFile = SettingsFile + ".tmp";
                    File.WriteAllText(tmpFile, text);
                    MDEditor.PlatformHelper.MoveFile(tmpFile, SettingsFile, overwrite: true);
                }
                catch
                {
                    // Ignore settings save failures
                }
            }
        }

        public static List<SessionDocument> LoadSession()
        {
            lock (_fileLock)
            {
                try
                {
                    if (!File.Exists(SessionFile))
                        return new List<SessionDocument>();

                    var text = File.ReadAllText(SessionFile);
                    return JsonSerializer.Deserialize<List<SessionDocument>>(text,
                        new JsonSerializerOptions { MaxDepth = 12 }) ?? new List<SessionDocument>();
                }
                catch
                {
                    return new List<SessionDocument>();
                }
            }
        }

        public static void SaveSession(List<SessionDocument> tabs)
        {
            lock (_fileLock)
            {
                try
                {
                    if (!Directory.Exists(AppFolder))
                        Directory.CreateDirectory(AppFolder);

                    if (tabs == null || tabs.Count == 0)
                    {
                        // 所有标签页已关闭：删除会话缓存文件
                        DeleteSessionFile();
                        return;
                    }

                    var text = JsonSerializer.Serialize(tabs, new JsonSerializerOptions { WriteIndented = true });
                    // 原子写入
                    var tmpFile = SessionFile + ".tmp";
                    File.WriteAllText(tmpFile, text);
                    try
                    {
                        MDEditor.PlatformHelper.MoveFile(tmpFile, SessionFile, overwrite: true);
                    }
                    catch
                    {
                        // File.Move 失败（跨卷/权限），回退直接写入
                        File.WriteAllText(SessionFile, text);
                        try { if (File.Exists(tmpFile)) File.Delete(tmpFile); } catch { }
                    }
                }
                catch (Exception ex)
                {
                    try
                    {
                        File.AppendAllText(
                            Path.Combine(AppFolder, "settings_error.log"),
                            $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] SaveSession failed: {ex}\n");
                    }
                    catch { }
                }
            }
        }

        /// <summary>删除会话文件，失败时重试一次并记录日志</summary>
        private static void DeleteSessionFile()
        {
            if (!File.Exists(SessionFile)) return;

            try
            {
                File.Delete(SessionFile);
            }
            catch
            {
                // 文件可能短暂被占用，等待 50ms 重试
                try { System.Threading.Thread.Sleep(50); } catch { }
                try
                {
                    File.Delete(SessionFile);
                }
                catch (Exception ex)
                {
                    try
                    {
                        File.AppendAllText(
                            Path.Combine(AppFolder, "settings_error.log"),
                            $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] DeleteSessionFile failed: {ex}\n");
                    }
                    catch { }
                }
            }
        }
    }
}

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using HtmlAgilityPack;
using HtmlDocument = HtmlAgilityPack.HtmlDocument;
using Markdig;

namespace MDEditor.Services
{
    public static class MarkdownConverter
    {
        private static readonly MarkdownPipeline Pipeline = new MarkdownPipelineBuilder()
            .UseAdvancedExtensions()
            .UsePipeTables()
            .UseTaskLists()
            .UseAutoLinks()
            .UseMathematics()
            .Build();

        /// <summary>主题名称列表（.css + .md + 默认）</summary>
        public static readonly string[] ThemeNames = {
            "默认", "标准", "蓝色", "包豪斯", "知识库",
            "极简北欧", "现代科技", "复古打字机", "杂志编辑", "学术期刊",
            "水墨山水", "青花瓷韵", "朱砂印章", "宣纸卷轴", "竹简古风"
        };

        /// <summary>当前选中的预览主题（切换时清除 CSS 缓存）</summary>
        private static string _themeName = "默认";
        public static string ThemeName
        {
            get => _themeName;
            set
            {
                if (_themeName != value)
                {
                    _themeName = value;
                    _cachedCss = null;
                }
            }
        }

        /// <summary>缓存的 CSS 内容</summary>
        private static string? _cachedCss;

        /// <summary>嵌入式资源命名空间前缀</summary>
        private const string ResourcePrefix = "MDEditor.Att.";

        // GitHub Primer 风格 CSS（默认主题降级）
        private static readonly string LightCss = @"body {
  font-family: -apple-system, BlinkMacSystemFont, ""Segoe UI"", Noto Sans, Helvetica, Arial, sans-serif;
  margin: 0; padding: 32px;
  color: #1F2328; background: #f6f8fa;
  line-height: 1.6; font-size: 14px;
}
h1, h2 { border-bottom: 1px solid #d0d7de; font-weight: 600; }
h1 { padding-bottom: 8px; font-size: 2em; }
h2 { padding-bottom: 6px; font-size: 1.5em; }
h3 { font-weight: 600; font-size: 1.25em; }
h4 { font-weight: 600; font-size: 1em; }
h5 { font-weight: 600; font-size: 0.875em; }
h6 { font-weight: 600; font-size: 0.85em; color: #656d76; }
pre {
  font-family: ""Consolas"", ""Courier New"", monospace;
  background: #f6f8fa; border: 1px solid #d0d7de;
  border-radius: 6px; padding: 16px; overflow: auto; line-height: 1.45;
}
code {
  font-family: ""Consolas"", ""Courier New"", monospace;
  background: rgba(175,184,193,0.2); border-radius: 6px;
  padding: 2px 6px; font-size: 85%;
}
pre code { background: transparent; border: none; padding: 0; }
blockquote {
  border-left: 4px solid #d0d7de; margin: 0;
  padding: 0 16px; color: #656d76;
}
table { border-collapse: collapse; width: 100%; margin: 8px 0; }
th, td { border: 1px solid #d0d7de; padding: 6px 13px; }
th { font-weight: 600; background: #f6f8fa; }
img { max-width: 100%; }
a { color: #0969da; text-decoration: none; }
a:hover { text-decoration: underline; }
hr { height: 1px; background: #d0d7de; border: none; }
ul, ol { padding-left: 2em; }
li + li { margin-top: 4px; }
";

        private static readonly string DarkCss = @"body {
  font-family: -apple-system, BlinkMacSystemFont, ""Segoe UI"", Noto Sans, Helvetica, Arial, sans-serif;
  margin: 0; padding: 32px;
  color: #e6edf3; background: #161b22;
  line-height: 1.6; font-size: 14px;
}
h1, h2 { border-bottom: 1px solid #30363d; font-weight: 600; }
h1 { padding-bottom: 8px; font-size: 2em; }
h2 { padding-bottom: 6px; font-size: 1.5em; }
h3 { font-weight: 600; font-size: 1.25em; }
h4 { font-weight: 600; font-size: 1em; }
h5 { font-weight: 600; font-size: 0.875em; }
h6 { font-weight: 600; font-size: 0.85em; color: #7d8590; }
pre {
  font-family: ""Consolas"", ""Courier New"", monospace;
  background: #161b22; border: 1px solid #30363d;
  border-radius: 6px; padding: 16px; overflow: auto; line-height: 1.45;
}
code {
  font-family: ""Consolas"", ""Courier New"", monospace;
  background: rgba(240,246,252,0.15); border-radius: 6px;
  padding: 2px 6px; font-size: 85%;
}
pre code { background: transparent; border: none; padding: 0; }
blockquote {
  border-left: 4px solid #30363d; margin: 0;
  padding: 0 16px; color: #7d8590;
}
table { border-collapse: collapse; width: 100%; margin: 8px 0; }
th, td { border: 1px solid #30363d; padding: 6px 13px; }
th { font-weight: 600; background: #161b22; }
img { max-width: 100%; }
a { color: #2f81f7; text-decoration: none; }
a:hover { text-decoration: underline; }
hr { height: 1px; background: #30363d; border: none; }
ul, ol { padding-left: 2em; }
li + li { margin-top: 4px; }
";

        public static string ToHtml(string markdown, bool isDarkTheme)
        {
            var body = Markdown.ToHtml(markdown ?? string.Empty, Pipeline);
            return WrapHtml(body, isDarkTheme);
        }

        public static string ToPlainText(string markdown)
        {
            var html = Markdown.ToHtml(markdown ?? string.Empty, Pipeline);
            return HtmlToPlainText(html);
        }

        private static readonly Regex MermaidCodeBlockRegex = new(
            @"<pre><code class=""language-mermaid"">(.*?)</code></pre>",
            RegexOptions.Singleline | RegexOptions.IgnoreCase);

        /// <summary>将 Markdig 渲染的 mermaid 代码块转为 &lt;pre class="mermaid"&gt; 供 JS 渲染</summary>
        private static string ConvertMermaidBlocks(string html)
        {
            return MermaidCodeBlockRegex.Replace(html, match =>
            {
                var code = match.Groups[1].Value;
                // 不进行 HtmlDecode：Markdig 输出的内容已经是 HTML 编码的，
                // 直接放入 <pre class="mermaid"> 可防止 <>& 等字符破坏 DOM 结构，
                // 浏览器解析 textContent 时会自动解码回原始文本供 Mermaid 使用。
                return $"<pre class=\"mermaid\">{code}</pre>";
            });
        }

        /// <summary>缓存的 shell 页面（只生成一次，后续通过脚本注入内容）</summary>
        private static string? _cachedShell;

        /// <summary>获取 Mermaid shell 页面（不含内容，含 updateContent JS 函数）</summary>
        public static string GetBaseShell()
        {
            if (_cachedShell != null)
                return _cachedShell;

            _cachedShell = @"<!DOCTYPE html>
<html>
<head>
<meta charset=""utf-8"">
<style id=""theme-css""></style>
<script src=""http://mermaid.local/mermaid.min.js""></script>
</head>
<body>
<div id=""wemd""></div>
<script>
function updateContent(html, css, theme) {
    document.getElementById('theme-css').textContent = css;
    document.getElementById('wemd').innerHTML = html;
    try {
        mermaid.initialize({ startOnLoad: false, theme: theme });
        if (document.querySelector('#wemd .mermaid')) {
            mermaid.run({ querySelector: '#wemd .mermaid' });
        }
    } catch(e) {
        console.warn('Mermaid render error:', e);
    }
    reportScrollPercent();
}
function reportScrollPercent() {
    var el = document.getElementById('wemd');
    if (!el) return;
    el.onscroll = function() {
        var pct = el.scrollHeight > el.clientHeight
            ? Math.round(el.scrollTop / (el.scrollHeight - el.clientHeight) * 100)
            : 0;
        try { window.chrome.webview.postMessage('scroll:' + pct); } catch(e) {}
    };
    var pct = el.scrollHeight > el.clientHeight
        ? Math.round(el.scrollTop / (el.scrollHeight - el.clientHeight) * 100)
        : 0;
    try { window.chrome.webview.postMessage('scroll:' + pct); } catch(e) {}
}
</script>
</body>
</html>";
            return _cachedShell;
        }

        /// <summary>仅生成 Markdown → 处理后的 body HTML（不含外壳），用于脚本注入</summary>
        public static string GetContentHtml(string markdown, bool isDarkTheme)
        {
            var body = Markdown.ToHtml(markdown ?? string.Empty, Pipeline);
            var processedBody = ThemeName != "默认" ? WrapHeadingContent(body) : body;
            processedBody = ConvertMermaidBlocks(processedBody);
            return processedBody;
        }

        /// <summary>获取当前主题 CSS（公开方法）</summary>
        public static string GetCssContent(bool isDarkTheme) => GetCss(isDarkTheme);

        private static string WrapHtml(string body, bool isDarkTheme)
        {
            var css = GetCss(isDarkTheme);
            var processedBody = ThemeName != "默认" ? WrapHeadingContent(body) : body;
            processedBody = ConvertMermaidBlocks(processedBody);
            var mermaidTheme = isDarkTheme ? "dark" : "default";

            // 使用含 updateContent JS 函数的 shell 页面，首次加载通过 updateContent 注入内容和 CSS
            // 确保后续 InjectPreviewContent 快速路径也能正常调用 updateContent
            var escapedBody = System.Web.HttpUtility.JavaScriptStringEncode(processedBody);
            var escapedCss = System.Web.HttpUtility.JavaScriptStringEncode(css);
            var shell = GetBaseShell();
            var html = shell.Replace("</body>",
                $"<script>updateContent('{escapedBody}','{escapedCss}','{mermaidTheme}');</script></body>");
            return html;
        }

        /// <summary>获取当前主题的 CSS 内容（带缓存）</summary>
        private static string GetCss(bool isDarkTheme)
        {
            if (ThemeName == "默认")
                return isDarkTheme ? DarkCss : LightCss;

            if (_cachedCss != null)
                return _cachedCss;

            var assembly = Assembly.GetExecutingAssembly();

            // 先试 .css，再试 .md
            string? resourceName = null;
            foreach (var ext in new[] { "css", "md" })
            {
                var candidate = $"{ResourcePrefix}{ThemeName}.{ext}";
                if (assembly.GetManifestResourceInfo(candidate) != null)
                {
                    resourceName = candidate;
                    break;
                }
            }

            if (resourceName == null)
                return isDarkTheme ? DarkCss : LightCss;

            using var stream = assembly.GetManifestResourceStream(resourceName);
            if (stream == null)
                return isDarkTheme ? DarkCss : LightCss;

            using var reader = new StreamReader(stream, Encoding.UTF8);
            var css = reader.ReadToEnd();

            // .md 文件用 body 选择器，需要转为 #wemd 以适配预览容器
            if (resourceName.EndsWith(".md"))
                css = ConvertBodyToWemd(css);

            // 统一移除页面宽度限制（保留 max-width: 100% 用于图片自适应）
            css = RemoveMaxWidth(css);

            // 确保链接内图片（如 shields.io badge）保持行内显示，不换行居中
            css += "\n#wemd a img { display: inline-block; vertical-align: middle; margin: 0; }";

            _cachedCss = css;
            return css;
        }

        /// <summary>将 CSS 中的 body 选择器替换为 #wemd（用于 .md 主题文件）</summary>
        private static readonly Regex BodySelectorRegex = new Regex(
            @"(?<=^|[\s,;{}>+~])body(?=[\s.{,:>+~#]|$)",
            RegexOptions.Multiline);

        private static string ConvertBodyToWemd(string css)
        {
            return BodySelectorRegex.Replace(css, "#wemd");
        }

        /// <summary>移除所有非 100% 的 max-width 声明（解除页面宽度限制）</summary>
        private static readonly Regex MaxWidthRegex = new Regex(
            @"\bmax-width\s*:\s*(?!100%)[^;]+;?\s*",
            RegexOptions.Multiline);

        private static string RemoveMaxWidth(string css)
        {
            return MaxWidthRegex.Replace(css, "");
        }

        /// <summary>
        /// 将 h1-h4 的文本内容包装在 &lt;span class="content"&gt; 中，
        /// 适配 Att CSS 文件的标题选择器。
        /// </summary>
        private static string WrapHeadingContent(string html)
        {
            var doc = new HtmlDocument();
            doc.LoadHtml(html);

            foreach (var tag in new[] { "h1", "h2", "h3", "h4" })
            {
                var nodes = doc.DocumentNode.SelectNodes($"//{tag}");
                if (nodes == null) continue;

                foreach (var node in nodes)
                {
                    // 如果已有 .content 子元素则跳过
                    var existingSpan = node.SelectSingleNode("span[contains(@class,'content')]");
                    if (existingSpan != null) continue;

                    var span = doc.CreateElement("span");
                    span.SetAttributeValue("class", "content");
                    var children = node.ChildNodes.ToList();
                    foreach (var child in children)
                        node.RemoveChild(child);
                    foreach (var child in children)
                        span.AppendChild(child);
                    node.AppendChild(span);
                }
            }

            return doc.DocumentNode.OuterHtml;
        }

        private static string HtmlToPlainText(string html)
        {
            var document = new HtmlDocument();
            document.LoadHtml(html);
            var builder = new StringBuilder();
            ExtractText(document.DocumentNode, builder);
            return NormalizeWhitespace(builder.ToString());
        }

        private static void ExtractText(HtmlNode node, StringBuilder builder)
        {
            if (node.NodeType == HtmlNodeType.Text)
            {
                var text = HtmlEntity.DeEntitize(node.InnerText);
                if (!string.IsNullOrWhiteSpace(text))
                {
                    builder.Append(text);
                }
            }
            else if (node.Name == "li")
            {
                builder.Append("- ");
                foreach (var child in node.ChildNodes)
                {
                    ExtractText(child, builder);
                }
                builder.AppendLine();
            }
            else if (node.Name is "h1" or "h2" or "h3" or "h4" or "h5" or "h6"
                      or "br" or "p" or "div")
            {
                foreach (var child in node.ChildNodes)
                {
                    ExtractText(child, builder);
                }
                builder.AppendLine();
            }
            else
            {
                foreach (var child in node.ChildNodes)
                {
                    ExtractText(child, builder);
                }
            }
        }

        private static string NormalizeWhitespace(string text)
        {
            var lines = text.Split(new[] { '\r', '\n' }, StringSplitOptions.None)
                .Select(line => line.Trim());
            return string.Join(Environment.NewLine, lines);
        }
    }
}

using System;
using System.Collections.Generic;
using System.Text;

namespace MDEditor.Services
{
    /// <summary>
    /// Markdown 一键排版：解析 → 格式化 → 重新序列化
    /// 采用逐行状态机 + 块缓冲，识别块级结构后按规则重新排版。
    /// </summary>
    public static class MarkdownFormatter
    {
        public static string Format(string markdown)
        {
            if (string.IsNullOrEmpty(markdown))
                return markdown ?? string.Empty;

            // 统一换行符为 \n
            var text = markdown
                .Replace("\r\n", "\n")
                .Replace('\r', '\n');

            var lines = text.Split('\n');
            var result = new List<string>();
            var prevBlockType = BlockType.None;
            var inFencedCode = false;
            var fencedCodeFence = string.Empty;
            var blankCount = 0;

            var i = 0;

            // === YAML front matter 检测 ===
            if (lines.Length > 0 && lines[0].TrimEnd() == "---")
            {
                // 收集 front matter 行直到闭合 --- (或 ...)
                var fmLines = new List<string>();
                var j = 0;
                var closed = false;
                for (; j < lines.Length; j++)
                {
                    var l = lines[j].TrimEnd();
                    fmLines.Add(l);
                    if (j > 0 && (l == "---" || l == "..."))
                    {
                        closed = true;
                        j++;
                        break;
                    }
                }
                // 输出 front matter 原样（仅去行尾空格）
                foreach (var fm in fmLines)
                    result.Add(fm);
                if (closed && j < lines.Length && lines[j].Length == 0)
                {
                    // 跳过 front matter 后的第一个空行，统一由后续逻辑处理
                    // 但我们先不跳过，让主循环自然处理
                }
                // 如果未闭合，整个文档视为无 front matter，回退并交由主循环处理
                if (closed)
                {
                    prevBlockType = BlockType.FrontMatter;
                    blankCount = 0;
                    i = j;
                }
                else
                {
                    result.Clear(); // front matter 未闭合，丢回主循环
                }
            }

            for (; i < lines.Length; i++)
            {
                var rawLine = lines[i];
                var cleaned = rawLine.TrimEnd();

                // === 围栏代码块 ===
                if (!inFencedCode && IsFenceLine(cleaned, out var fence))
                {
                    inFencedCode = true;
                    fencedCodeFence = fence;
                    InsertBlankIfNeeded(result, ref blankCount, prevBlockType, BlockType.FencedCode);
                    result.Add(LowercaseCodeLang(cleaned));
                    prevBlockType = BlockType.FencedCode;
                    blankCount = 0;
                    continue;
                }

                if (inFencedCode)
                {
                    result.Add(rawLine.TrimEnd());
                    if (IsFenceLine(cleaned, out var closingFence) && closingFence == fencedCodeFence)
                    {
                        inFencedCode = false;
                        fencedCodeFence = string.Empty;
                        prevBlockType = BlockType.FencedCode;
                    }
                    blankCount = 0;
                    continue;
                }

                // === 空行 ===
                if (string.IsNullOrEmpty(cleaned))
                {
                    blankCount++;
                    if (blankCount <= 1) // 规则1: ≥2个连续空行 → 最多保留1个
                        result.Add(string.Empty);
                    continue;
                }

                // === 表格: 缓冲连续表格行，整体处理 ===
                if (IsTableLine(cleaned))
                {
                    var tableLines = new List<string>();
                    while (i < lines.Length && IsTableLine(lines[i].TrimEnd()))
                    {
                        tableLines.Add(lines[i].TrimEnd());
                        i++;
                    }
                    i--; // 回退一行，外层 for 会 ++

                    InsertBlankIfNeededWithBuffer(result, ref blankCount, prevBlockType, BlockType.Table);
                    var formatted = NormalizeTable(tableLines);
                    foreach (var tl in formatted)
                        result.Add(tl);
                    prevBlockType = BlockType.Table;
                    blankCount = 0;
                    continue;
                }

                // === 块引用: 缓冲连续引用行，整体处理 ===
                if (IsBlockQuoteLine(cleaned))
                {
                    var bqLines = new List<string>();
                    while (i < lines.Length && IsBlockQuoteLine(lines[i].TrimEnd()))
                    {
                        bqLines.Add(lines[i].TrimEnd());
                        i++;
                    }
                    i--;

                    InsertBlankIfNeededWithBuffer(result, ref blankCount, prevBlockType, BlockType.BlockQuote);
                    var formatted = NormalizeBlockQuote(bqLines);
                    foreach (var bq in formatted)
                        result.Add(bq);
                    prevBlockType = BlockType.BlockQuote;
                    blankCount = 0;
                    continue;
                }

                // === 行内 http URL 拆分 ===
                var urlSegments = SplitUrlSegments(cleaned);
                if (urlSegments != null)
                {
                    // 逐段输出，URL 段前后用空行隔离
                    foreach (var seg in urlSegments)
                    {
                        var segType = seg.IsUrl ? BlockType.UrlLine : BlockType.Paragraph;
                        if (NeedsBlankBefore(prevBlockType, segType) && blankCount == 0 && result.Count > 0)
                            result.Add(string.Empty);
                        var segText = NormalizeChinesePunctuation(seg.Text);
                        result.Add(segText);
                        prevBlockType = segType;
                        blankCount = 0;
                    }
                    continue;
                }

                // === 单行块类型 ===
                var blockType = IdentifyBlockType(cleaned);

                if (NeedsBlankBefore(prevBlockType, blockType) && blankCount == 0 && result.Count > 0)
                    result.Add(string.Empty);

                var normalized = NormalizeLine(cleaned, blockType);
                // 规则2: CJK 间距（URL 行不处理）+ 中文符号规范化
                if (blockType != BlockType.UrlLine)
                {
                    normalized = NormalizeCJKSpacing(normalized);
                    normalized = NormalizeChinesePunctuation(normalized);
                }
                result.Add(normalized);

                prevBlockType = blockType;
                blankCount = 0;
            }

            // 去除尾部空行，确保恰好一个尾换行
            while (result.Count > 0 && result[^1].Length == 0)
                result.RemoveAt(result.Count - 1);

            return string.Join("\r\n", result) + "\r\n";
        }

        // ====================================================================
        // 块类型
        // ====================================================================

        private enum BlockType
        {
            None,
            FrontMatter,
            Heading,
            FencedCode,
            HorizontalRule,
            UnorderedList,
            OrderedList,
            TaskList,
            BlockQuote,
            Table,
            UrlLine,
            Paragraph
        }

        // ====================================================================
        // 空行规则
        // ====================================================================

        /// <summary>
        /// 空行规则：标题上下空行、代码块前后空行、列表间空行、http URL 独立成段。
        /// 段落之间不额外增加空行，保留原文样貌。
        /// </summary>
        private static bool NeedsBlankBefore(BlockType prev, BlockType current)
        {
            // 标题前（文档开头/FrontMatter 除外）
            if (current == BlockType.Heading && prev != BlockType.None && prev != BlockType.FrontMatter)
                return true;

            // 标题后（标题 → 其他内容）
            if (prev == BlockType.Heading && current != BlockType.None)
                return true;

            // http URL 前后独立成段
            if (current == BlockType.UrlLine && prev != BlockType.None)
                return true;
            if (prev == BlockType.UrlLine && current != BlockType.None)
                return true;

            // 水平线前（标题后例外）
            if (current == BlockType.HorizontalRule && prev != BlockType.None && prev != BlockType.Heading)
                return true;

            // 不同列表类型之间
            if (IsListType(prev) && IsListType(current) && prev != current)
                return true;

            // 代码块后
            if (prev == BlockType.FencedCode)
                return true;

            // 表格前、块引用前
            if (current == BlockType.Table && prev != BlockType.None)
                return true;
            if (current == BlockType.BlockQuote && prev != BlockType.None && prev != BlockType.BlockQuote)
                return true;

            return false;
        }

        private static bool IsListType(BlockType type)
        {
            return type == BlockType.UnorderedList || type == BlockType.OrderedList || type == BlockType.TaskList;
        }

        // ====================================================================
        // 块类型识别
        // ====================================================================

        private static BlockType IdentifyBlockType(string line)
        {
            if (string.IsNullOrEmpty(line))
                return BlockType.Paragraph;

            if (CountHeadingLevel(line) > 0)
                return BlockType.Heading;

            if (IsHorizontalRule(line))
                return BlockType.HorizontalRule;

            if (IsBlockQuoteLine(line))
                return BlockType.BlockQuote;

            if (IsTaskListItem(line))
                return BlockType.TaskList;

            if (IsUnorderedListItem(line))
                return BlockType.UnorderedList;

            if (IsOrderedListItem(line))
                return BlockType.OrderedList;

            // 段落
            if (IsTableLine(line))
                return BlockType.Table;

            return BlockType.Paragraph;
        }

        // ====================================================================
        // 单行匹配器
        // ====================================================================

        private static int CountHeadingLevel(string line)
        {
            var count = 0;
            while (count < 7 && count < line.Length && line[count] == '#')
                count++;
            if (count < 1 || count > 6) return 0;
            if (count < line.Length && line[count] != ' ') return 0;
            return count;
        }

        private static bool IsHorizontalRule(string line)
        {
            var trimmed = line.Trim();
            if (trimmed.Length < 3) return false;
            var chars = trimmed.Replace(" ", "");
            if (chars.Length < 3) return false;
            var c = chars[0];
            if (c != '-' && c != '*' && c != '_') return false;
            for (var i = 1; i < chars.Length; i++)
                if (chars[i] != c) return false;
            return true;
        }

        private static bool IsFenceLine(string line, out string fence)
        {
            fence = string.Empty;
            if (string.IsNullOrEmpty(line)) return false;
            var trimmed = line.TrimStart();
            if (trimmed.Length < 3) return false;
            if (trimmed.StartsWith("```")) fence = "```";
            else if (trimmed.StartsWith("~~~")) fence = "~~~";
            else return false;
            return true;
        }

        private static bool IsBlockQuoteLine(string line)
        {
            return line.StartsWith(">");
        }

        /// <summary>
        /// 判断行内是否包含 http URL（http:// 或 https://）。
        /// 若包含，将行拆分为 (文本, 是否URL) 段列表。
        /// 若不包含，返回 null 表示按原文处理。
        /// </summary>
        private static List<UrlSegment>? SplitUrlSegments(string line)
        {
            var result = new List<UrlSegment>();
            var remaining = line;
            var found = false;

            while (remaining.Length > 0)
            {
                // 找 http:// 或 https://
                var idxHttp = remaining.IndexOf("http://", StringComparison.Ordinal);
                var idxHttps = remaining.IndexOf("https://", StringComparison.Ordinal);

                var idx = -1;
                if (idxHttp >= 0 && idxHttps >= 0)
                    idx = Math.Min(idxHttp, idxHttps);
                else if (idxHttp >= 0)
                    idx = idxHttp;
                else if (idxHttps >= 0)
                    idx = idxHttps;

                if (idx < 0)
                {
                    // 没有更 URL，剩余部分作为段落输出
                    // 前面已找到过 URL，输出剩余部分
                    if (remaining.TrimEnd().Length > 0)
                        result.Add(new UrlSegment(remaining.TrimEnd(), false));
                    break;
                }

                found = true;

                // URL 前的文本（trim 一下）
                var before = remaining[..idx].TrimEnd();
                if (before.Length > 0)
                    result.Add(new UrlSegment(before, false));

                // 提取 URL：从 http 到第一个空白或行尾
                var urlStart = idx;
                var urlEnd = remaining.Length;
                for (var j = idx; j < remaining.Length; j++)
                {
                    if (char.IsWhiteSpace(remaining[j]))
                    {
                        urlEnd = j;
                        break;
                    }
                }

                var url = remaining[urlStart..urlEnd].Trim();
                if (url.Length > 0)
                    result.Add(new UrlSegment(url, true));

                // 继续处理剩余部分
                remaining = remaining[urlEnd..];
            }

            return found ? result : null;
        }

        private readonly record struct UrlSegment(string Text, bool IsUrl);

        private static bool IsTableLine(string line)
        {
            return line.TrimStart().StartsWith("|");
        }

        private static bool IsUnorderedListItem(string line)
        {
            var trimmed = line.TrimStart();
            if (trimmed.Length < 2) return false;
            return (trimmed[0] == '-' || trimmed[0] == '*' || trimmed[0] == '+')
                   && trimmed[1] == ' ';
        }

        private static bool IsOrderedListItem(string line)
        {
            var trimmed = line.TrimStart();
            var i = 0;
            while (i < trimmed.Length && char.IsDigit(trimmed[i])) i++;
            return i > 0 && i < trimmed.Length - 1
                   && trimmed[i] == '.'
                   && trimmed[i + 1] == ' ';
        }

        private static bool IsTaskListItem(string line)
        {
            var trimmed = line.TrimStart();
            if (trimmed.Length < 6) return false;
            return (trimmed[0] == '-' || trimmed[0] == '*' || trimmed[0] == '+')
                   && trimmed[1] == ' '
                   && trimmed[2] == '['
                   && (trimmed[3] == ' ' || trimmed[3] == 'x' || trimmed[3] == 'X')
                   && trimmed[4] == ']'
                   && trimmed[5] == ' ';
        }

        // ====================================================================
        // 单行规范化
        // ====================================================================

        private static string NormalizeLine(string line, BlockType blockType)
        {
            switch (blockType)
            {
                case BlockType.Heading:
                    return NormalizeHeading(line);
                case BlockType.HorizontalRule:
                    return "---";
                case BlockType.UnorderedList:
                    return NormalizeUnorderedList(line);
                case BlockType.TaskList:
                    return NormalizeTaskList(line);
                case BlockType.Paragraph:
                    return line.TrimEnd();
                default:
                    return line.TrimEnd();
            }
        }

        private static string NormalizeHeading(string line)
        {
            var trimmed = line.TrimStart();
            var indent = line[..(line.Length - trimmed.Length)];
            var level = CountHeadingLevel(trimmed);
            if (level == 0) return line.TrimEnd();
            var content = trimmed[level..].TrimStart();
            return indent + new string('#', level) + ' ' + content;
        }

        private static string NormalizeUnorderedList(string line)
        {
            var trimmed = line.TrimStart();
            var indent = line[..(line.Length - trimmed.Length)];
            var content = trimmed[2..];
            return indent + "- " + content.TrimStart();
        }

        private static string NormalizeTaskList(string line)
        {
            var trimmed = line.TrimStart();
            var indent = line[..(line.Length - trimmed.Length)];
            var isChecked = trimmed[3] == 'x' || trimmed[3] == 'X';
            var marker = isChecked ? "- [x] " : "- [ ] ";
            var content = trimmed[6..];
            return indent + marker + content.TrimStart();
        }

        // ====================================================================
        // 规则2: CJK 间距 + 标点符号规范化
        // ====================================================================

        /// <summary>
        /// 在 CJK 与英文字母/数字间自动插入空格。
        /// 全角标点、百分号、数字与英文之间不插入空格。
        /// 同时规范化引号、省略号。
        /// </summary>
        private static string NormalizeCJKSpacing(string line)
        {
            if (string.IsNullOrEmpty(line)) return line;

            var sb = new StringBuilder(line.Length + 8);
            for (var i = 0; i < line.Length; i++)
            {
                var curr = line[i];
                sb.Append(curr);

                if (i + 1 >= line.Length) continue;
                var next = line[i + 1];

                var currIsCJK = IsCJKText(curr);
                var nextIsCJK = IsCJKText(next);
                var currIsLetter = IsAsciiLetter(curr);
                var nextIsLetter = IsAsciiLetter(next);
                var currIsDigit = IsAsciiDigit(curr);
                var nextIsDigit = IsAsciiDigit(next);
                var currIsPercent = curr == '%';
                var nextIsPercent = next == '%';
                var currIsFullwidthPunct = IsFullwidthPunct(curr);
                var nextIsFullwidthPunct = IsFullwidthPunct(next);
                var currIsLinkBracket = curr == '[' || curr == ']' || curr == '(' || curr == ')';
                var nextIsLinkBracket = next == '[' || next == ']' || next == '(' || next == ')';

                // 规则1: CJK + 英文 → 加空格
                if (currIsCJK && nextIsLetter)
                    sb.Append(' ');
                // 规则2: 英文 + CJK → 加空格
                else if (currIsLetter && nextIsCJK)
                    sb.Append(' ');
                // 规则3: CJK + 数字 → 加空格
                else if (currIsCJK && nextIsDigit)
                    sb.Append(' ');
                // 规则4: 数字 + CJK → 加空格
                else if (currIsDigit && nextIsCJK)
                    sb.Append(' ');

                // 规则5: 数字 + 英文 / 英文 + 数字 → 不加空格（默认行为，不额外处理）

                // 规则6: 全角标点 + 英文/数字 → 不加空格（不额外处理）

                // 规则7: 链接标记前后与中文加空格
                // CJK + [ ( → 加空格
                else if (currIsCJK && (next == '[' || next == '('))
                    sb.Append(' ');
                // ) ] + CJK → 加空格
                else if ((curr == ')' || curr == ']') && nextIsCJK)
                    sb.Append(' ');

                // 规则8: 百分号 + 数字 / 数字 + 百分号 → 不加空格（默认行为）
            }
            return sb.ToString();
        }

        /// <summary>
        /// CJK 汉字文本（不包括全角标点和符号）。
        /// </summary>
        private static bool IsCJKText(char c)
        {
            return (c >= 0x2E80 && c <= 0x2EFF)   // CJK Radicals Supplement
                || (c >= 0x3400 && c <= 0x4DBF)   // CJK Unified Ext-A
                || (c >= 0x4E00 && c <= 0x9FFF)   // CJK Unified Ideographs
                || (c >= 0xF900 && c <= 0xFAFF);  // CJK Compatibility Ideographs
        }

        private static bool IsAsciiLetter(char c)
        {
            return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
        }

        private static bool IsAsciiDigit(char c)
        {
            return c >= '0' && c <= '9';
        }

        /// <summary>
        /// 全角标点（FF00-FFEF 中不属于字母数字的部分）。
        /// 例如：， 。、！？【】（）等。
        /// </summary>
        private static bool IsFullwidthPunct(char c)
        {
            // 全角 ASCII 对应区间 FF01-FF5E（除去字母数字）
            // 全角标点/符号区间
            return (c >= 0xFF01 && c <= 0xFF0F)   // ！＂＃＄％＆＇（）＊＋，－．／
                || (c >= 0xFF1A && c <= 0xFF1F)   // ：；＜＝＞？
                || (c >= 0xFF3B && c <= 0xFF40)   // ［＼］＾＿｀
                || (c >= 0xFF5B && c <= 0xFF60)   // ｛｜｝～
                || (c >= 0xFF61 && c <= 0xFF64);  // ｡｢｣､
        }

        /// <summary>
        /// 规范化中文符号：全角引号、省略号等。
        /// </summary>
        private static string NormalizeChinesePunctuation(string line)
        {
            if (string.IsNullOrEmpty(line)) return line;

            var sb = new StringBuilder(line.Length + 4);
            var i = 0;
            while (i < line.Length)
            {
                var c = line[i];

                // 中文双引号: "..." → “...”
                if (c == '"')
                {
                    // 判断前后文：前有 CJK 或行首 → 判断为左引
                    var prevIsCJK = i > 0 && IsCJKText(line[i - 1]);
                    var nextIsCJK = i + 1 < line.Length && IsCJKText(line[i + 1]);

                    if (prevIsCJK || i == 0)
                        sb.Append('\u201C'); // “
                    else
                        sb.Append('\u201D'); // ”
                }
                // 中文单引号: '...' → ‘...’
                else if (c == '\'')
                {
                    var prevIsCJK = i > 0 && IsCJKText(line[i - 1]);
                    var nextIsCJK = i + 1 < line.Length && IsCJKText(line[i + 1]);

                    if (prevIsCJK || i == 0)
                        sb.Append('\u2018'); // ‘
                    else
                        sb.Append('\u2019'); // ’
                }
                // 省略号: ... → ……（连续3个点）
                else if (c == '.' && i + 2 < line.Length && line[i + 1] == '.' && line[i + 2] == '.')
                {
                    sb.Append("\u2026\u2026"); // ……
                    i += 3;
                    continue;
                }
                // 句号双写 → 省略号
                else if (c == '\u3002' && i + 1 < line.Length && line[i + 1] == '\u3002')
                {
                    sb.Append("\u2026\u2026"); // ……
                    i += 2;
                    continue;
                }
                else
                {
                    sb.Append(c);
                }

                i++;
            }
            return sb.ToString();
        }

        /// <summary>
        /// 将代码块围栏语言名转为小写。
        /// </summary>
        private static string LowercaseCodeLang(string line)
        {
            if (string.IsNullOrEmpty(line) || line.Length < 3) return line;
            var trimmed = line.TrimStart();
            // ```lang 或 ~~~lang
            if (!trimmed.StartsWith("```") && !trimmed.StartsWith("~~~")) return line;

            var fenceLen = trimmed[0] == '`' ? 3 : 3;
            if (trimmed.Length <= fenceLen) return line; // 只有围栏无语言名

            var lang = trimmed[fenceLen..].Trim();
            if (lang.Length == 0) return line;

            // 只转字母部分，保留其他字符
            var sb = new StringBuilder(line[..(line.Length - trimmed.Length + fenceLen)]);
            var sbLang = new StringBuilder(lang.Length);
            foreach (var ch in lang)
            {
                sbLang.Append(ch >= 'A' && ch <= 'Z' ? (char)(ch - 'A' + 'a') : ch);
            }
            sb.Append(' ');
            sb.Append(sbLang.ToString().Trim());
            return sb.ToString();
        }

        // ====================================================================
        // 规则4: 表格规范化（列对齐）
        // ====================================================================

        private static List<string> NormalizeTable(List<string> rawLines)
        {
            if (rawLines.Count == 0) return rawLines;

            // 解析每一行的单元格
            var rows = new List<List<string>>();
            foreach (var line in rawLines)
            {
                var cells = ParseTableRow(line);
                rows.Add(cells);
            }

            if (rows.Count == 0) return rawLines;

            // 计算最大列数
            var maxCols = 0;
            foreach (var row in rows)
                if (row.Count > maxCols) maxCols = row.Count;

            // 填充缺失列
            foreach (var row in rows)
                while (row.Count < maxCols) row.Add(string.Empty);

            // 计算每列最大宽度
            var colWidths = new int[maxCols];
            for (var col = 0; col < maxCols; col++)
            {
                foreach (var row in rows)
                {
                    var cellLen = VisualLength(row[col].Trim());
                    if (cellLen > colWidths[col])
                        colWidths[col] = cellLen;
                }
                // 最小宽度3（匹配 --- 分隔符）
                if (colWidths[col] < 3) colWidths[col] = 3;
            }

            // 检测分隔行（第二行通常是 |---|---|），确定对齐方式
            var alignments = new Alignment[maxCols];
            if (rows.Count >= 2 && IsTableSeparator(rows[1]))
            {
                var sepRow = rows[1];
                for (var col = 0; col < maxCols && col < sepRow.Count; col++)
                {
                    var cell = sepRow[col].Trim();
                    var left = cell.StartsWith(":") && cell.Length > 1 && cell[^1] != ':';
                    var right = cell.EndsWith(":") && cell.Length > 1 && cell[0] != ':';
                    var center = cell.StartsWith(":") && cell.EndsWith(":");

                    if (left) alignments[col] = Alignment.Left;
                    else if (right) alignments[col] = Alignment.Right;
                    else if (center) alignments[col] = Alignment.Center;
                    else alignments[col] = Alignment.Left; // 默认左对齐
                }
            }

            // 重新构建表格行
            var result = new List<string>();
            for (var r = 0; r < rows.Count; r++)
            {
                var isSep = (r == 1 && rows.Count >= 2 && IsTableSeparator(rows[r]));
                var cells = rows[r];
                var formattedCells = new List<string>();

                for (var col = 0; col < maxCols; col++)
                {
                    var cell = col < cells.Count ? cells[col].Trim() : string.Empty;
                    if (isSep)
                    {
                        // 重建分隔行
                        var sep = new string('-', colWidths[col]);
                        if (col < alignments.Length)
                        {
                            formattedCells.Add(alignments[col] switch
                            {
                                Alignment.Left => ":" + sep + "-",
                                Alignment.Right => "-" + sep + ":",
                                Alignment.Center => ":" + sep + ":",
                                _ => "-" + sep + "-"
                            });
                        }
                        else
                        {
                            formattedCells.Add("-" + sep + "-");
                        }
                    }
                    else
                    {
                        // 对齐单元格内容
                        formattedCells.Add(PadCell(cell, colWidths[col],
                            col < alignments.Length ? alignments[col] : Alignment.Left));
                    }
                }

                result.Add("| " + string.Join(" | ", formattedCells) + " |");
            }

            return result;
        }

        private enum Alignment { Left, Center, Right }

        private static List<string> ParseTableRow(string line)
        {
            var trimmed = line.Trim();
            // Trim leading/trailing | 
            if (trimmed.StartsWith("|")) trimmed = trimmed[1..];
            if (trimmed.EndsWith("|")) trimmed = trimmed[..^1];

            var cells = new List<string>();
            var parts = trimmed.Split('|');
            foreach (var p in parts)
                cells.Add(p);
            return cells;
        }

        private static bool IsTableSeparator(List<string> cells)
        {
            foreach (var cell in cells)
            {
                var trimmed = cell.Trim();
                // A separator cell looks like ---, :---, ---:, :---:, etc.
                var stripped = trimmed.TrimStart(':').TrimEnd(':').Trim();
                if (string.IsNullOrEmpty(stripped)) return false;
                foreach (var c in stripped)
                    if (c != '-') return false;
            }
            return true;
        }

        private static int VisualLength(string s)
        {
            var len = 0;
            foreach (var c in s)
            {
                if (c > 0x7F)
                    len += 2; // CJK approx 2宽度
                else
                    len += 1;
            }
            return len;
        }

        private static string PadCell(string content, int width, Alignment align)
        {
            var visual = VisualLength(content);
            var padding = width - visual;
            if (padding <= 0) return content;

            return align switch
            {
                Alignment.Right => new string(' ', padding) + content,
                Alignment.Center => new string(' ', padding / 2) + content + new string(' ', padding - padding / 2),
                _ => content + new string(' ', padding) // Left
            };
        }

        // ====================================================================
        // 规则5: 块引用规范化
        // ====================================================================

        private static List<string> NormalizeBlockQuote(List<string> lines)
        {
            var result = new List<string>();
            foreach (var line in lines)
            {
                var trimmed = line.TrimStart();
                var indent = line[..(line.Length - trimmed.Length)];

                // 找到 > 标记
                var gtIdx = trimmed.IndexOf('>');
                if (gtIdx < 0)
                {
                    result.Add(line);
                    continue;
                }

                // 前缀（多层引用如 "> > "）
                var prefix = trimmed[..(gtIdx + 1)]; // includes the >
                var rest = trimmed[(gtIdx + 1)..];

                // 确保 > 后有一个空格
                if (rest.Length > 0 && rest[0] == ' ')
                {
                    // 移除多余空格
                    rest = rest.TrimStart();
                    result.Add(indent + prefix + " " + rest);
                }
                else
                {
                    rest = rest.TrimStart();
                    result.Add(indent + prefix + " " + rest);
                }
            }
            return result;
        }

        // ====================================================================
        // 辅助
        // ====================================================================

        private static void InsertBlankIfNeeded(List<string> result, ref int blankCount, BlockType prev, BlockType current)
        {
            if (result.Count > 0 && result[^1].Length > 0 && blankCount == 0 && NeedsBlankBefore(prev, current))
                result.Add(string.Empty);
        }

        /// <summary>
        /// 缓冲块之前插入空行：检查上一行是否为空，不是则根据规则决定。
        /// </summary>
        private static void InsertBlankIfNeededWithBuffer(List<string> result, ref int blankCount, BlockType prev, BlockType current)
        {
            if (NeedsBlankBefore(prev, current) && blankCount == 0 && result.Count > 0 && result[^1].Length > 0)
                result.Add(string.Empty);
        }
    }
}

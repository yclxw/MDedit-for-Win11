import os, zipfile

# List files in source dir
srcdir = r'C:\kfaxM\MD编辑器\bak\source'
print("=== Directory contents ===")
for f in os.listdir(srcdir):
    fp = os.path.join(srcdir, f)
    isdir = os.path.isdir(fp)
    size = os.path.getsize(fp) if not isdir else 0
    print(f'{"DIR" if isdir else "FILE"} | {f} | {size}')

# List zip contents
zipfile_src = os.path.join(srcdir, 'MD编辑器_src_v3.15.20260623.zip')
zipfile_full = os.path.join(srcdir, 'MD编辑器_full_v3.15.20260623.zip')

if os.path.exists(zipfile_src):
    print("\n=== SRC ZIP contents (first 40) ===")
    with zipfile.ZipFile(zipfile_src, 'r') as z:
        for i, info in enumerate(z.infolist()):
            if i >= 40: break
            print(f'{info.filename} | {info.file_size}')
        print(f'... Total entries: {len(z.infolist())}')

if os.path.exists(zipfile_full):
    print(f"\n=== FULL ZIP contents (first 40) ===")
    with zipfile.ZipFile(zipfile_full, 'r') as z:
        for i, info in enumerate(z.infolist()):
            if i >= 40: break
            print(f'{info.filename} | {info.file_size}')
        print(f'... Total entries: {len(z.infolist())}')

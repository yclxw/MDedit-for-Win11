using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using Clipboard = System.Windows.Clipboard;
using DataFormats = System.Windows.DataFormats;
using MessageBox = System.Windows.MessageBox;
using TextDataFormat = System.Windows.TextDataFormat;
using Forms = System.Windows.Forms;
using ContextMenu = System.Windows.Controls.ContextMenu;
using MenuItem = System.Windows.Controls.MenuItem;
// Removed WebView2 dependency - using built-in WebBrowser as fallback
using MDEditor.Models;
using MDEditor.Services;
using MDEditor.Editor;
using System.Windows.Media;
using Microsoft.Win32;

namespace MDEditor
{
    public partial class MainWindow : Window
    {
        private AppSettings _settings = null!; // 构造函数中从文件加载
        private bool _webViewReady;
        private bool _showLineNumbers = false;
        private string? _lastPreviewContent;
        private bool _lastPreviewTheme;
        private Document? _lastPreviewDocument;
        private string? _lastSearchText;
        private bool _lastSearchMatchCase;
        private bool _lastSearchUseRegex;
        private string? _currentFolderPath;
        private DispatcherTimer? _autoSaveTimer;
        private ViewLayout _currentViewLayout = ViewLayout.FullView;
        private bool _isSyncingTabs;
        private bool _isInitializing;
        private bool _isRestoringSession;
        public MainWindow()
        {
            InitializeComponent();
            _settings = SettingsService.Load();
            _editorFontFamily = _settings.EditorFontFamily;
            _editorFontSize = _settings.EditorFontSize;
            _newDocCounter = _settings.NewDocCounter;
            ApplyTheme();
            InitializeAutoSave();
            PreviewWebView.CoreWebView2InitializationCompleted += PreviewWebView_InitializationCompleted;
            RegisterShortcuts();
            Dispatcher.BeginInvoke(new Action(() => PopulateRecentFiles()),
                System.Windows.Threading.DispatcherPriority.Background);
            if (!string.IsNullOrEmpty(_settings.LastOpenedFolder) && Directory.Exists(_settings.LastOpenedFolder))
            {
                Dispatcher.BeginInvoke(new Action(() =>
                {
                    _currentFolderPath = _settings.LastOpenedFolder;
                    LoadFileTree(_currentFolderPath!);
                }), System.Windows.Threading.DispatcherPriority.Background);
            }
        }

        private void RegisterShortcuts()
        {
            void Bind(Key key, ModifierKeys mod, ExecutedRoutedEventHandler handler)
            {
                var cmd = new RoutedUICommand();
                CommandBindings.Add(new CommandBinding(cmd, handler));
                InputBindings.Add(new KeyBinding(cmd, key, mod));
            }

            // === 文件 ===
            Bind(Key.N, ModifierKeys.Control, (_, _) => NewFile_Click(null!, null!));
            Bind(Key.O, ModifierKeys.Control, (_, _) => OpenFile_Click(null!, null!));
            Bind(Key.S, ModifierKeys.Control, (_, _) => SaveFile_Click(null!, null!));
            Bind(Key.S, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => SaveAsMd_Click(null!, null!));
            Bind(Key.P, ModifierKeys.Control, (_, _) => Print_Click(null!, null!));
            Bind(Key.W, ModifierKeys.Control, (_, _) => CloseTab_Click(null!, null!));

            // === 编辑 (non-native; Ctrl+Z/Y/X/C/V/A handled natively by TextBox) ===
            Bind(Key.C, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => CopyAsPlainText_Click(null!, null!));
            Bind(Key.V, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => PastePlainText_Click(null!, null!));
            Bind(Key.F, ModifierKeys.Control, (_, _) => FindReplace_Click(null!, null!));
            Bind(Key.F3, ModifierKeys.None, (_, _) => FindNextShortcut());
            Bind(Key.G, ModifierKeys.Control, (_, _) => GoToLine_Click(null!, null!));

            // === 视图 ===
            Bind(Key.D1, ModifierKeys.Control, (_, _) => FullView_Click(null!, null!));
            Bind(Key.D2, ModifierKeys.Control, (_, _) => PreviewMode_Click(null!, null!));
            Bind(Key.D3, ModifierKeys.Control, (_, _) => SourceMode_Click(null!, null!));
            Bind(Key.D4, ModifierKeys.Control, (_, _) => SplitVertical_Click(null!, null!));
            Bind(Key.D5, ModifierKeys.Control, (_, _) => SplitHorizontal_Click(null!, null!));
            Bind(Key.D6, ModifierKeys.Control, (_, _) => StandardView_Click(null!, null!));
            Bind(Key.D7, ModifierKeys.Control, (_, _) => CustomView_Click(null!, null!));
            Bind(Key.F11, ModifierKeys.None, (_, _) => FullScreen_Click(null!, null!));
            Bind(Key.B, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => ToggleSidebar_Click(null!, null!));
            Bind(Key.G, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => ToggleLineNumbers_Click(null!, null!));
            Bind(Key.OemPlus, ModifierKeys.Control, (_, _) => ZoomIn_Click(null!, null!));
            Bind(Key.OemMinus, ModifierKeys.Control, (_, _) => ZoomOut_Click(null!, null!));
            Bind(Key.D0, ModifierKeys.Control, (_, _) => ResetZoom_Click(null!, null!));
            Bind(Key.D, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => ToggleTheme_Click(null!, null!));

            // === 格式 ===
            Bind(Key.B, ModifierKeys.Control, (_, _) => Bold_Click(null!, null!));
            Bind(Key.I, ModifierKeys.Control, (_, _) => Italic_Click(null!, null!));
            Bind(Key.X, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => Strikethrough_Click(null!, null!));
            Bind(Key.Oem3, ModifierKeys.Control, (_, _) => InlineCode_Click(null!, null!));
            Bind(Key.Oem3, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => CodeBlock_Click(null!, null!));
            Bind(Key.Q, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => BlockQuote_Click(null!, null!));
            Bind(Key.U, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => UnorderedList_Click(null!, null!));
            Bind(Key.N, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => OrderedList_Click(null!, null!));
            Bind(Key.T, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => TaskList_Click(null!, null!));
            Bind(Key.K, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => Link_Click(null!, null!));
            Bind(Key.I, ModifierKeys.Control | ModifierKeys.Shift, (_, _) => Image_Click(null!, null!));

            // Ctrl+方向键 标题升降/行移动
            Bind(Key.Left,  ModifierKeys.Control, (_, _) => ToolBar_PromoteHeading_Click(null!, null!));
            Bind(Key.Right, ModifierKeys.Control, (_, _) => ToolBar_DemoteHeading_Click(null!, null!));
            Bind(Key.Up,    ModifierKeys.Control, (_, _) => ToolBar_MoveLineUp_Click(null!, null!));
            Bind(Key.Down,  ModifierKeys.Control, (_, _) => ToolBar_MoveLineDown_Click(null!, null!));

            // 标题 Ctrl+Shift+1~6 with CommandParameter
            var headingCmd = new RoutedUICommand();
            CommandBindings.Add(new CommandBinding(headingCmd, (_, e) =>
            {
                if (e.Parameter is int level) InsertHeading(level);
            }));
            for (var i = 1; i <= 6; i++)
            {
                InputBindings.Add(new KeyBinding(headingCmd, Key.D0 + i, ModifierKeys.Control | ModifierKeys.Shift)
                {
                    CommandParameter = i
                });
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Resources["TabItemWidth"] = System.Windows.SystemParameters.PrimaryScreenWidth / 10.0;

            Dispatcher.BeginInvoke(new Action(() => PopulateFontMenu()),
                System.Windows.Threading.DispatcherPriority.Background);

            UpdateDefaultViewCheckMarks();
            ApplyViewMode(_settings.DefaultView);

            _ = InitializeWebView2Async();

            // Handle files opened via command line / double-click association
            var args = Environment.GetCommandLineArgs();
            for (int i = 1; i < args.Length; i++)
            {
                if (File.Exists(args[i]))
                    OpenDocument(args[i]);
            }

            // Always restore previous session tabs alongside any opened file
            Dispatcher.BeginInvoke(new Action(() =>
            {
                RestoreSession();
                // ⚠ 恢复会话后重置脏标记：RestoreSession 创建标签页时
                // .Text = content 触发 TextChanged → document.IsDirty = true，
                // 但通过 _isInitializing=true 阻止了；现在确保一致。
                _isInitializing = false;
                _isRestoringSession = false;
            }),
                System.Windows.Threading.DispatcherPriority.Loaded);

            // 始终置顶
            Dispatcher.BeginInvoke(new Action(() =>
            {
                BringToFront();
            }),
                System.Windows.Threading.DispatcherPriority.Loaded);
        }

        private void Window_Closing(object? sender, System.ComponentModel.CancelEventArgs e)
        {
            // 自动缓存所有标签页到会话，下次启动恢复
            SaveSession();

            // 释放定时器
            _autoSaveTimer?.Stop();
            _autoSaveTimer = null;

            // 释放 WebView2
            PreviewWebView.Dispose();
        }

        private void Window_DragEnter(object sender, System.Windows.DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
                e.Effects = System.Windows.DragDropEffects.Copy;
            else
                e.Effects = System.Windows.DragDropEffects.None;
        }

        private void Window_Drop(object sender, System.Windows.DragEventArgs e)
        {
            if (e.Data.GetData(DataFormats.FileDrop) is string[] files)
            {
                foreach (var file in files)
                {
                    if (File.Exists(file))
                        OpenDocument(file);
                }
                BringToFront();
            }
        }

        private void SaveSession()
        {
            try
            {
                var tabs = new List<SessionDocument>();
                foreach (var item in EditorTabs.Items.OfType<TabItem>())
                {
                    if (item.Tag is Document doc && item.Content is MarkdownEditor editor)
                    {
                        // 以 editor.Text（用户实际内容）为主要来源，document.Content 为回退
                        var content = !string.IsNullOrEmpty(editor.Text) ? editor.Text : doc.Content;
                        // 仅在 editor.Text 有效时才同步回 document.Content
                        if (!string.IsNullOrEmpty(editor.Text))
                            doc.Content = editor.Text;

                        tabs.Add(new SessionDocument
                        {
                            Path = doc.Path,
                            Content = content,
                            IsDirty = doc.IsDirty,
                            CursorPosition = GetCaretIndexSafe(editor)
                        });
                    }
                }
                FileManager.SaveSession(tabs);
                // 保存当前激活标签页索引
                _settings.LastActiveTabIndex = EditorTabs.SelectedIndex;
                SettingsService.Save(_settings);
            }
            catch (Exception ex)
            {
                StatusText.Text = "会话缓存失败: " + ex.Message;
                LogCrash("SaveSession", ex);
            }
        }

        /// <summary>安全获取光标位置，防止编辑器未就绪时抛异常</summary>
        private static int GetCaretIndexSafe(MarkdownEditor editor)
        {
            try { return editor.GetCaretIndex(); }
            catch { return 0; }
        }

        /// <summary>记录错误到崩溃日志</summary>
        private static void LogCrash(string source, Exception ex)
        {
            try
            {
                System.IO.File.AppendAllText(
                    System.IO.Path.Combine(System.IO.Path.GetDirectoryName(Environment.ProcessPath) ?? ".", "MDEditor_crash.log"),
                    $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {source}: {ex}\n");
            }
            catch { }
        }

        private void RestoreSession()
        {
            var tabs = FileManager.LoadSession();
            var savedIndex = _settings.LastActiveTabIndex;
            _isRestoringSession = true;
            _isInitializing = true;
            try
            {
                for (int i = 0; i < tabs.Count; i++)
                {
                    var sessionDoc = tabs[i];

                    // 跳过已在命令行/拖拽中打开的文件，避免重复标签页
                    if (!string.IsNullOrEmpty(sessionDoc.Path) &&
                        EditorTabs.Items.OfType<TabItem>().Any(item =>
                            item.Tag is Document existingDoc &&
                            string.Equals(existingDoc.Path, sessionDoc.Path, StringComparison.OrdinalIgnoreCase)))
                    {
                        continue;
                    }

                    var document = new Document
                    {
                        Path = sessionDoc.Path,
                        Content = sessionDoc.Content,
                        IsDirty = sessionDoc.IsDirty
                    };
                    var editor = new MarkdownEditor();
                    editor.TextChanged += Editor_TextChanged;
                    editor.Text = sessionDoc.Content;
                    // 显式同步：editor.Text 赋值后立即回写 document.Content，
                    // 防止因 Editor_TextChanged 找不到 TabItem 导致不同步
                    document.Content = editor.Text;
                    editor.ShowLineNumbers = _showLineNumbers;
                    editor.SetFontFamily(_editorFontFamily);
                    editor.SetFontSize(_editorFontSize);

                    var tab = new TabItem
                    {
                        Header = CreateTabHeader(document.Title + (document.IsDirty ? " *" : string.Empty)),
                        Content = editor,
                        Tag = document,
                        ContextMenu = CreateTabContextMenu()
                    };
                    tab.PreviewMouseRightButtonDown += Tab_PreviewMouseRightButtonDown;

                    EditorTabs.Items.Add(tab);
                }
            }
            catch (Exception ex)
            {
                try { System.IO.File.AppendAllText(
                    System.IO.Path.Combine(System.IO.Path.GetDirectoryName(Environment.ProcessPath) ?? ".", "MDEditor_crash.log"),
                    $"[{DateTime.Now}] RestoreSession: {ex}\n"); } catch { }
            }
            finally
            {
                _isInitializing = false;
                _isRestoringSession = false;
            }

            if (EditorTabs.Items.Count > 0)
            {
                // 恢复上次激活的标签页
                var idx = savedIndex >= 0 && savedIndex < EditorTabs.Items.Count
                    ? savedIndex : 0;
                // 防御: 确保 idx 不会越界（例如 savedIndex == -1 且 Items.Count == 0 已在上面排除）
                idx = Math.Clamp(idx, 0, EditorTabs.Items.Count - 1);
                EditorTabs.SelectedIndex = idx;

                // 恢复所有标签页光标位置
                for (int i = 0; i < Math.Min(tabs.Count, EditorTabs.Items.Count); i++)
                {
                    if (EditorTabs.Items[i] is TabItem tab &&
                        tab.Content is MarkdownEditor editor)
                    {
                        var pos = Math.Min(tabs[i].CursorPosition, editor.Text.Length);
                        if (pos >= 0 && pos <= editor.Text.Length)
                            editor.SetCaretIndex(pos);
                    }
                }

                if (EditorTabs.SelectedItem is TabItem selectedTab &&
                    selectedTab.Content is MarkdownEditor selectedEditor)
                {
                    selectedEditor.Focus();
                }
            }

            RefreshEditorState();
        }

        private void InitializeAutoSave()
        {
            _autoSaveTimer = new DispatcherTimer();
            _autoSaveTimer.Interval = TimeSpan.FromMinutes(_settings.AutoSaveIntervalMinutes);
            _autoSaveTimer.Tick += AutoSaveTimer_Tick;
            _autoSaveTimer.IsEnabled = _settings.AutoSaveEnabled;
        }

        private void AutoSaveTimer_Tick(object? sender, EventArgs e)
        {
            var document = GetCurrentDocument();
            if (document != null && document.IsDirty)
            {
                SaveCurrentDocument(false);
            }
            // 同时缓存所有标签页到会话，防止崩溃丢失
            SaveSession();
        }

        private Document? GetCurrentDocument()
        {
            if (EditorTabs.SelectedItem is TabItem tab && tab.Tag is Document document)
            {
                return document;
            }
            return null;
        }

        private MarkdownEditor? GetCurrentEditor()
        {
            if (EditorTabs.SelectedItem is TabItem tab && tab.Content is MarkdownEditor editor)
            {
                return editor;
            }
            return null;
        }

        private int _newDocCounter;

        private void NewDocument()
        {
            _newDocCounter = Math.Max(_newDocCounter, _settings.NewDocCounter) + 1;
            _settings.NewDocCounter = _newDocCounter;
            var document = new Document { DefaultTitle = $"新文本{_newDocCounter}" };
            AddEditorTab(document);
        }

        private void AddEditorTab(Document document)
        {
            var editor = new MarkdownEditor();
            editor.TextChanged += Editor_TextChanged;
            _isInitializing = true;
            try
            {
                editor.Text = document.Content;
            }
            finally
            {
                _isInitializing = false;
            }
            editor.ShowLineNumbers = _showLineNumbers;
            editor.SetFontFamily(_editorFontFamily);
            editor.SetFontSize(_editorFontSize);

            var tab = new TabItem
            {
                Header = CreateTabHeader(document.Title + (document.IsDirty ? " *" : string.Empty)),
                Content = editor,
                Tag = document,
                ContextMenu = CreateTabContextMenu()
            };
            tab.PreviewMouseRightButtonDown += Tab_PreviewMouseRightButtonDown;

            EditorTabs.Items.Add(tab);
            SyncPreviewTabs();
            EditorTabs.SelectedItem = tab; // SyncPreviewTabs 先于 SelectedItem 切换，
            // 确保 EditorTabs_SelectionChanged → SyncPreviewTabSelection 能在已重建的 PreviewTabs 上正确同步
            Dispatcher.BeginInvoke(new Action(() => UpdatePreview()),
                System.Windows.Threading.DispatcherPriority.Loaded);
        }

        private void Editor_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (sender is not MarkdownEditor editor)
                return;

            var document = FindDocumentForEditor(editor);
            if (document == null)
                return;

            document.Content = editor.Text;
            if (!_isInitializing)
            {
                document.IsDirty = true;
                UpdateTabHeader(document);
            }
        }

        /// <summary>更新所有工具栏图标颜色（主题切换时）</summary>
        private void UpdateAllToolbarIcons()
        {
            var prefix = _settings.IsDarkTheme ? "黑" : "蓝";
            var allBtns = new System.Windows.Controls.Button[]
            {
                ToolBar_NewBtn, ToolBar_OpenBtn, ToolBar_SaveBtn, ToolBar_SaveAsBtn, ToolBar_PrintBtn,
                ToolBar_BodyBtn, ToolBar_H1Btn, ToolBar_H2Btn, ToolBar_H3Btn, ToolBar_H4Btn, ToolBar_H5Btn, ToolBar_H6Btn,
                ToolBar_BoldBtn, ToolBar_ItalicBtn, ToolBar_StrikethroughBtn, ToolBar_InlineCodeBtn, ToolBar_BlockQuoteBtn, ToolBar_CodeBlockBtn,
                ToolBar_OrderedListBtn, ToolBar_UnorderedListBtn, ToolBar_TaskListBtn, ToolBar_LinkBtn, ToolBar_HorizontalRuleBtn, ToolBar_ColorBtn,
                ToolBar_SidebarBtn, ToolBar_PreviewBtn, ToolBar_SourceBtn, ToolBar_LineNumberBtn,
                ToolBar_PromoteHeadingBtn, ToolBar_DemoteHeadingBtn, ToolBar_MoveLineUpBtn, ToolBar_MoveLineDownBtn
            };
            foreach (var btn in allBtns)
            {
                var tag = btn.Tag as string;
                if (!string.IsNullOrEmpty(tag))
                    SetButtonIcon(btn, prefix, tag);
            }
        }

        private static void SetButtonIcon(System.Windows.Controls.Button btn, string prefix, string? tagOverride = null)
        {
            var name = tagOverride ?? btn.Tag as string;
            if (string.IsNullOrEmpty(name)) return;
            if (btn.Content is System.Windows.Controls.Image img)
            {
                img.Source = new System.Windows.Media.Imaging.BitmapImage(
                    new Uri($"pack://application:,,,/Resources/{prefix}{name}.ico"));
            }
        }

        private Document? FindDocumentForEditor(MarkdownEditor editor)
        {
            foreach (var item in EditorTabs.Items.OfType<TabItem>())
            {
                if (item.Content == editor)
                    return item.Tag as Document;
            }
            return null;
        }

        private void UpdateTabHeader(Document document)
        {
            foreach (var item in EditorTabs.Items.OfType<TabItem>())
            {
                if (item.Tag == document)
                {
                    if (item.Header is DockPanel panel && panel.Children.OfType<TextBlock>().FirstOrDefault() is TextBlock textBlock)
                    {
                        textBlock.Text = document.Title + (document.IsDirty ? " *" : string.Empty);
                    }
                    else
                    {
                        item.Header = CreateTabHeader(document.Title + (document.IsDirty ? " *" : string.Empty));
                    }
                    break;
                }
            }

            for (var i = 0; i < Math.Min(EditorTabs.Items.Count, PreviewTabs.Items.Count); i++)
            {
                if (EditorTabs.Items[i] is TabItem editorTab && editorTab.Tag == document &&
                    PreviewTabs.Items[i] is TabItem previewTab)
                {
                    var title = document.Title + (document.IsDirty ? " *" : string.Empty);
                    if (previewTab.Header is DockPanel dp && dp.Children.OfType<TextBlock>().FirstOrDefault() is TextBlock ptb)
                        ptb.Text = title;
                    else
                    {
                        var titleText = new TextBlock
                        {
                            Text = title,
                            VerticalAlignment = VerticalAlignment.Center,
                            TextTrimming = TextTrimming.CharacterEllipsis,
                            MaxWidth = double.PositiveInfinity
                        };
                        var newPanel = new DockPanel
                        {
                            LastChildFill = true,
                            Margin = new Thickness(5, 1, 0, 1),
                            ToolTip = title
                        };
                        newPanel.Children.Add(titleText);
                        previewTab.Header = newPanel;
                    }
                    break;
                }
            }
        }

        private DockPanel CreateTabHeader(string title)
        {
            var titleText = new TextBlock
            {
                Text = title,
                VerticalAlignment = VerticalAlignment.Center,
                TextTrimming = TextTrimming.CharacterEllipsis,
                MaxWidth = double.PositiveInfinity
            };
            DockPanel.SetDock(titleText, Dock.Left);

            var closeBtn = new System.Windows.Controls.Button
            {
                Content = "×",
                Width = 20,
                Height = 20,
                VerticalAlignment = VerticalAlignment.Center,
                ToolTip = "关闭",
                Focusable = false,
                FontSize = 14,
                FontWeight = FontWeights.Bold,
                Foreground = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0x88, 0x88, 0x88)),
                Background = System.Windows.Media.Brushes.Transparent,
                BorderThickness = new Thickness(0),
                Padding = new Thickness(0),
                Cursor = System.Windows.Input.Cursors.Hand,
                HorizontalAlignment = System.Windows.HorizontalAlignment.Right,
                Margin = new Thickness(0)
            };
            closeBtn.MouseEnter += (_, _) =>
            {
                closeBtn.Background = new SolidColorBrush(System.Windows.Media.Color.FromArgb(0xE6, 0xFF, 0x00, 0x00));
                closeBtn.Foreground = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0xFF, 0xFF, 0xFF));
            };
            closeBtn.MouseLeave += (_, _) =>
            {
                closeBtn.Background = System.Windows.Media.Brushes.Transparent;
                closeBtn.Foreground = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0x88, 0x88, 0x88));
            };
            closeBtn.Click += CloseTabButton_Click;
            DockPanel.SetDock(closeBtn, Dock.Right);

            var panel = new DockPanel
            {
                LastChildFill = true,
                Margin = new Thickness(5, 1, 0, 1),
                ToolTip = title
            };
            panel.Children.Add(closeBtn);
            panel.Children.Add(titleText);
            return panel;
        }

        private ContextMenu CreateTabContextMenu()
        {
            var menu = new ContextMenu();
            var closeCurrent = new MenuItem { Header = "关闭当前页签" };
            var closeOthers = new MenuItem { Header = "关闭其他页签" };
            var closeAll = new MenuItem { Header = "关闭全部页签" };
            closeCurrent.Click += Context_CloseCurrent_Click;
            closeOthers.Click += Context_CloseOthers_Click;
            closeAll.Click += Context_CloseAll_Click;
            menu.Items.Add(closeCurrent);
            menu.Items.Add(closeOthers);
            menu.Items.Add(closeAll);
            return menu;
        }

        private ContextMenu CreatePreviewTabContextMenu()
        {
            var menu = new ContextMenu();
            var closeCurrent = new MenuItem { Header = "关闭当前页签" };
            var closeOthers = new MenuItem { Header = "关闭其他页签" };
            var closeAll = new MenuItem { Header = "关闭全部页签" };
            closeCurrent.Click += PreviewContext_CloseCurrent_Click;
            closeOthers.Click += PreviewContext_CloseOthers_Click;
            closeAll.Click += PreviewContext_CloseAll_Click;
            menu.Items.Add(closeCurrent);
            menu.Items.Add(closeOthers);
            menu.Items.Add(closeAll);
            return menu;
        }

        private void Tab_PreviewMouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (sender is TabItem tab)
            {
                tab.IsSelected = true;
            }
        }

        private void UpdatePreview()
        {
            if (_isRestoringSession) return;
            var editor = GetCurrentEditor();
            if (editor == null || !_webViewReady)
                return;

            var document = GetCurrentDocument();

            // Skip re-render if content and theme unchanged (fast tab switch)
            if (document == _lastPreviewDocument
                && editor.Text == _lastPreviewContent
                && _settings.IsDarkTheme == _lastPreviewTheme)
            {
                return;
            }

            _lastPreviewDocument = document;
            _lastPreviewContent = editor.Text;
            _lastPreviewTheme = _settings.IsDarkTheme;

            var html = MarkdownConverter.ToHtml(editor.Text, _settings.IsDarkTheme);
            PreviewWebView.NavigateToString(html);
            UpdateOutline();
        }

        private async Task InitializeWebView2Async()
        {
            try
            {
                var userDataFolder = Path.Combine(Path.GetTempPath(), "MDEditor_WebView2");
                var env = await Microsoft.Web.WebView2.Core.CoreWebView2Environment.CreateAsync(
                    userDataFolder: userDataFolder);
                await PreviewWebView.EnsureCoreWebView2Async(env);
            }
            catch
            {
                Dispatcher.Invoke(() =>
                    StatusText.Text = "WebView2 初始化失败，预览功能不可用");
            }
        }

        private void PreviewWebView_InitializationCompleted(object? sender, Microsoft.Web.WebView2.Core.CoreWebView2InitializationCompletedEventArgs e)
        {
            if (e.IsSuccess)
            {
                _webViewReady = true;
                UpdatePreview();
            }
        }

        private void RefreshEditorState()
        {
            SyncPreviewTabs();
            var editor = GetCurrentEditor();
            if (editor == null)
            {
                OutlineView?.Items.Clear();
                if (_webViewReady)
                {
                    PreviewWebView.NavigateToString("<html><body></body></html>");
                }
                return;
            }

            UpdatePreview();
        }

        private void ToggleLineNumbers_Click(object sender, RoutedEventArgs e)
        {
            _showLineNumbers = !_showLineNumbers;
            SetLineNumbersForAllEditors(_showLineNumbers);
            StatusText.Text = _showLineNumbers ? "行号：已显示" : "行号：已隐藏";
        }

        private void SetLineNumbersForAllEditors(bool show)
        {
            foreach (var tab in EditorTabs.Items.OfType<TabItem>())
            {
                if (tab.Content is MarkdownEditor editor)
                {
                    editor.ShowLineNumbers = show;
                }
            }
        }

        private void ApplyTheme()
        {
            if (_settings.IsDarkTheme)
            {
                Resources["WindowBackgroundBrush"]  = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0x0D, 0x11, 0x17));
                Resources["PanelBackgroundBrush"]   = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0x16, 0x1B, 0x22));
                Resources["ControlBackgroundBrush"] = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0x0D, 0x11, 0x17));
                Resources["ControlForegroundBrush"] = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0xE6, 0xED, 0xF3));
                Resources["BorderBrush"]            = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0x30, 0x36, 0x3D));
                Resources["AccentBrush"]            = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0x2F, 0x81, 0xF7));
                Resources["AccentTextBrush"]        = System.Windows.Media.Brushes.White;
                Resources["HoverBrush"]             = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0x30, 0x36, 0x3D));
                Resources["SelectedBgBrush"]        = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0x0D, 0x28, 0x47)); // 暗色深蓝灰，与浅色文字 #E6EDF3 对比度 12.3:1
                Resources["SubtleTextBrush"]        = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0x7D, 0x85, 0x90));
                Resources["PressedBrush"]           = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0x21, 0x26, 0x2D));
                Resources["HeadingActiveBrush"]    = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0xE5, 0x39, 0x35));
                // 覆盖 WPF 默认 TreeViewItem 的系统高亮色，防止 Windows 11 强调蓝覆盖 Primer 选中色
                Resources[System.Windows.SystemColors.HighlightBrushKey]     = (System.Windows.Media.SolidColorBrush)Resources["SelectedBgBrush"];
                Resources[System.Windows.SystemColors.HighlightTextBrushKey] = (System.Windows.Media.SolidColorBrush)Resources["ControlForegroundBrush"];
                UpdateAllToolbarIcons();
                StatusText.Text = "深色主题";
            }
            else
            {
                Resources["WindowBackgroundBrush"]  = System.Windows.Media.Brushes.White;
                Resources["PanelBackgroundBrush"]   = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0xF6, 0xF8, 0xFA));
                Resources["ControlBackgroundBrush"] = System.Windows.Media.Brushes.White;
                Resources["ControlForegroundBrush"] = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0x1F, 0x23, 0x28));
                Resources["BorderBrush"]            = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0xD0, 0xD7, 0xDE));
                Resources["AccentBrush"]            = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0x09, 0x69, 0xDA));
                Resources["AccentTextBrush"]        = System.Windows.Media.Brushes.White;
                Resources["HoverBrush"]             = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0xF3, 0xF4, 0xF6));
                Resources["SelectedBgBrush"]        = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0xDD, 0xF4, 0xFF));
                Resources["SubtleTextBrush"]        = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0x65, 0x6D, 0x76));
                Resources["PressedBrush"]           = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0xD0, 0xD7, 0xDE));
                Resources["HeadingActiveBrush"]    = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0xE5, 0x39, 0x35));
                // 覆盖 WPF 默认 TreeViewItem 的系统高亮色，防止 Windows 11 强调蓝覆盖 Primer 选中色
                Resources[System.Windows.SystemColors.HighlightBrushKey]     = (System.Windows.Media.SolidColorBrush)Resources["SelectedBgBrush"];
                Resources[System.Windows.SystemColors.HighlightTextBrushKey] = (System.Windows.Media.SolidColorBrush)Resources["ControlForegroundBrush"];
                UpdateAllToolbarIcons();
                StatusText.Text = "浅色主题";
            }
        }

        private void PopulateRecentFiles()
        {
            RecentFilesMenu.Items.Clear();
            foreach (var path in FileManager.GetRecentFiles())
            {
                var item = new MenuItem { Header = path, Tag = path };
                item.Click += RecentFile_Click;
                RecentFilesMenu.Items.Add(item);
            }

            if (RecentFilesMenu.Items.Count == 0)
            {
                RecentFilesMenu.Items.Add(new MenuItem { Header = "无最近文件", IsEnabled = false });
            }
        }

        private void AddRecentFile(string path)
        {
            FileManager.AddRecentFile(path);
            PopulateRecentFiles();
        }

        private void RecentFile_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem item && item.Tag is string path)
            {
                OpenDocument(path);
            }
        }

        private void OpenDocument(string path)
        {
            try
            {
                // 检查是否已打开，避免重复标签页
                foreach (var item in EditorTabs.Items.OfType<TabItem>())
                {
                    if (item.Tag is Document existingDoc &&
                        string.Equals(existingDoc.Path, path, StringComparison.OrdinalIgnoreCase))
                    {
                        EditorTabs.SelectedItem = item;
                        StatusText.Text = $"已切换到: {System.IO.Path.GetFileName(path)}";
                        return;
                    }
                }

                Document document;
                if (FileManager.IsLargeFile(path))
                {
                    document = FileManager.CreatePlaceholder(path);
                    AddEditorTab(document);
                    AddRecentFile(path);
                    _ = LoadLargeFileAsync(path, document);
                }
                else
                {
                    document = FileManager.Open(path);
                    AddEditorTab(document);
                    AddRecentFile(path);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("无法打开文档：" + ex.Message, "打开失败", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async Task LoadLargeFileAsync(string path, Document document)
        {
            try
            {
                var loaded = await FileManager.OpenAsync(path);
                document.Content = loaded.Content;
                document.IsDirty = false;

                await Dispatcher.InvokeAsync(() =>
                {
                    foreach (var item in EditorTabs.Items.OfType<TabItem>())
                    {
                        if (item.Tag == document && item.Content is MarkdownEditor editor)
                        {
                            _isInitializing = true;
                            try { editor.Text = loaded.Content; }
                            finally { _isInitializing = false; }
                            UpdateTabHeader(document);
                            UpdatePreview();
                            break;
                        }
                    }
                    StatusText.Text = $"已加载: {System.IO.Path.GetFileName(path)}";
                });
            }
            catch (Exception ex)
            {
                await Dispatcher.InvokeAsync(() =>
                {
                    MessageBox.Show("无法打开文档：" + ex.Message, "打开失败", MessageBoxButton.OK, MessageBoxImage.Error);
                    var tab = EditorTabs.Items.OfType<TabItem>().FirstOrDefault(t => t.Tag == document);
                    if (tab != null)
                    {
                        EditorTabs.Items.Remove(tab);
                        RefreshEditorState();
                    }
                });
            }
        }

        public void OpenDocumentFromExternal(string path)
        {
            OpenDocument(path);
            BringToFront();
        }

        private void BringToFront()
        {
            if (WindowState == WindowState.Minimized)
                WindowState = WindowState.Normal;

            Topmost = true;
            Activate();
            Topmost = false;
        }

        private void OpenFolder_Click(object sender, RoutedEventArgs e)
        {
            using var dialog = new Forms.FolderBrowserDialog
            {
                Description = "选择 Markdown 工作区文件夹",
                ShowNewFolderButton = false
            };

            if (dialog.ShowDialog() == Forms.DialogResult.OK)
            {
                _currentFolderPath = dialog.SelectedPath;
                _settings.LastOpenedFolder = _currentFolderPath;
                SettingsService.Save(_settings);
                LoadFileTree(_currentFolderPath);
                StatusText.Text = $"工作区已打开：{_currentFolderPath}";
            }
        }

        private void LoadFileTree(string folderPath)
        {
            FileTreeView.Items.Clear();
            var rootItem = CreateFolderTreeItem(folderPath);
            FileTreeView.Items.Add(rootItem);
            rootItem.IsExpanded = true;
        }

        private TreeViewItem CreateFolderTreeItem(string path)
        {
            var item = new TreeViewItem
            {
                Header = Path.GetFileName(path) == string.Empty ? path : Path.GetFileName(path),
                Tag = path,
                IsExpanded = false
            };

            try
            {
                foreach (var dir in Directory.GetDirectories(path))
                {
                    item.Items.Add(CreateFolderTreeItem(dir));
                }

                foreach (var file in Directory.GetFiles(path).Where(file => file.EndsWith(".md", StringComparison.OrdinalIgnoreCase) || file.EndsWith(".txt", StringComparison.OrdinalIgnoreCase)))
                {
                    var fileItem = new TreeViewItem
                    {
                        Header = Path.GetFileName(file),
                        Tag = file
                    };
                    item.Items.Add(fileItem);
                }
            }
            catch
            {
                // Ignore permission exceptions or inaccessible folders
            }

            return item;
        }

        private void FileTreeView_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            if (e.NewValue is TreeViewItem item && item.Tag is string path && File.Exists(path))
            {
                OpenDocument(path);
            }
        }

        private void UpdateOutline()
        {
            if (OutlineView == null)
            {
                return;
            }

            OutlineView.Items.Clear();
            var editor = GetCurrentEditor();
            if (editor == null)
            {
                return;
            }

            var text = editor.Text;
            var lines = text.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
            var parents = new TreeViewItem?[7];
            var charPos = 0;

            foreach (var line in lines)
            {
                var trimmed = line.TrimStart();
                var isHeading = trimmed.StartsWith("#");

                if (isHeading)
                {
                    var level = trimmed.TakeWhile(c => c == '#').Count();
                    if (level >= 1 && level <= 6 && trimmed.Length > level && trimmed[level] == ' ')
                    {
                        var title = trimmed[(level + 1)..].Trim();
                        if (!string.IsNullOrWhiteSpace(title))
                        {
                            var lineIndex = editor.GetLineIndexFromCharacterIndex(charPos);
                            var outlineItem = new TreeViewItem
                            {
                                Header = title,
                                Tag = lineIndex,
                                IsExpanded = true
                            };
                            // Only handle via SelectedItemChanged — no separate Selected handler needed
                            parents[level] = outlineItem;
                            for (var clear = level + 1; clear < parents.Length; clear++)
                                parents[clear] = null;

                            if (level == 1)
                                OutlineView.Items.Add(outlineItem);
                            else if (parents[level - 1] != null)
                                parents[level - 1]!.Items.Add(outlineItem);
                            else
                                OutlineView.Items.Add(outlineItem);
                        }
                    }
                }

                charPos += line.Length;
                // Account for newline characters between lines
                if (charPos < text.Length)
                {
                    var c = text[charPos];
                    if (c == '\r')
                    {
                        charPos++;
                        if (charPos < text.Length && text[charPos] == '\n') charPos++;
                    }
                    else if (c == '\n')
                    {
                        charPos++;
                    }
                }
            }
        }

        private void OutlineView_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            if (e.NewValue is TreeViewItem item && item.Tag is int lineIndex)
            {
                var editor = GetCurrentEditor();
                editor?.GoToLine(lineIndex);
            }
        }

        private void OutlineView_PreviewMouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (sender is not System.Windows.Controls.TreeView treeView) return;

            // Don't intercept clicks on the expand/collapse toggle button
            var hit = treeView.InputHitTest(e.GetPosition(treeView));
            if (hit is System.Windows.Controls.Primitives.ToggleButton) return;

            var item = FindParentTreeViewItem(hit as DependencyObject);
            if (item?.Tag is int lineIndex)
            {
                var editor = GetCurrentEditor();
                editor?.GoToLine(lineIndex);
            }
        }

        private static TreeViewItem? FindParentTreeViewItem(DependencyObject? child)
        {
            while (child != null)
            {
                if (child is TreeViewItem tvi) return tvi;
                child = VisualTreeHelper.GetParent(child);
            }
            return null;
        }

        private bool SaveCurrentDocument(bool forceSaveAsMd)
        {
            var document = GetCurrentDocument();
            if (document == null)
            {
                return false;
            }

            if (string.IsNullOrEmpty(document.Path))
            {
                return SaveDocumentAs(document, forceSaveAsMd
                    ? "Markdown 文件 (*.md)|*.md"
                    : "Markdown 文件 (*.md)|*.md|文本文件 (*.txt)|*.txt",
                    ".md");
            }

            try
            {
                FileManager.Save(document.Path, document.Content);
                document.IsDirty = false;
                UpdateTabHeader(document);
                AddRecentFile(document.Path);
                UpdatePreview();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("保存失败：" + ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
        }

        private bool SaveDocumentAs(Document document, string filter, string defaultExtension)
        {
            var dialog = new Microsoft.Win32.SaveFileDialog
            {
                Filter = filter,
                DefaultExt = defaultExtension,
                FileName = string.IsNullOrEmpty(document.Path) ? document.Title : System.IO.Path.GetFileNameWithoutExtension(document.Path),
                AddExtension = true
            };

            if (dialog.ShowDialog(this) == true)
            {
                FileManager.Save(dialog.FileName, document.Content);
                document.Path = dialog.FileName;
                document.IsDirty = false;
                UpdateTabHeader(document);
                AddRecentFile(dialog.FileName);
                UpdatePreview();
                return true;
            }

            return false;
        }

        private void NewFile_Click(object sender, RoutedEventArgs e) => NewDocument();

        private void OpenFile_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.OpenFileDialog
            {
                Filter = "所有文件 (*.*)|*.*|Markdown 文件 (*.md)|*.md|文本文件 (*.txt)|*.txt",
                Multiselect = true
            };

            if (dialog.ShowDialog(this) == true)
            {
                foreach (var file in dialog.FileNames)
                {
                    OpenDocument(file);
                }
            }
        }

        private void SaveFile_Click(object sender, RoutedEventArgs e) => SaveCurrentDocument(false);

        private void SaveAsMd_Click(object sender, RoutedEventArgs e)
        {
            var document = GetCurrentDocument();
            if (document == null)
            {
                return;
            }

            SaveDocumentAs(document, "Markdown 文件 (*.md)|*.md", ".md");
        }

        private void SaveAsTxt_Click(object sender, RoutedEventArgs e)
        {
            var document = GetCurrentDocument();
            if (document == null) return;

            var dialog = new Microsoft.Win32.SaveFileDialog
            {
                Filter = "文本文件 (*.txt)|*.txt",
                DefaultExt = ".txt",
                FileName = string.IsNullOrEmpty(document.Path) ? document.Title : System.IO.Path.GetFileNameWithoutExtension(document.Path)
            };

            if (dialog.ShowDialog(this) == true)
            {
                FileService.SaveAsText(document.Content, dialog.FileName);
                document.Path = dialog.FileName;
                document.IsDirty = false;
                UpdateTabHeader(document);
                AddRecentFile(dialog.FileName);
            }
        }

        private void ExportHtml_Click(object sender, RoutedEventArgs e)
        {
            var document = GetCurrentDocument();
            if (document == null) return;

            var dialog = new Microsoft.Win32.SaveFileDialog
            {
                Filter = "HTML 文件 (*.html)|*.html",
                DefaultExt = ".html",
                FileName = string.IsNullOrEmpty(document.Path) ? document.Title : System.IO.Path.GetFileNameWithoutExtension(document.Path)
            };

            if (dialog.ShowDialog(this) == true)
            {
                FileService.SaveAsHtml(MarkdownConverter.ToHtml(document.Content, _settings.IsDarkTheme), dialog.FileName);
                AddRecentFile(dialog.FileName);
            }
        }

        private void ExportAll_Click(object sender, RoutedEventArgs e)
        {
            using var dialog = new Forms.FolderBrowserDialog
            {
                Description = "选择输出目录——所有已打开页面将保存到此文件夹",
                ShowNewFolderButton = true
            };

            if (dialog.ShowDialog() != Forms.DialogResult.OK) return;

            var folder = dialog.SelectedPath;
            var dateTag = DateTime.Now.ToString("yyyyMMddHHmmss"); // 包含秒，避免短时间内重复导出文件名冲突
            var count = 0;

            foreach (var item in EditorTabs.Items.OfType<TabItem>())
            {
                if (item.Tag is not Document doc || item.Content is not MarkdownEditor editor)
                    continue;

                if (string.IsNullOrWhiteSpace(editor.Text))
                    continue;

                // Generate filename: tab title without *, append date if duplicate
                var title = doc.Title.Replace(" *", "").Replace("*", "");
                if (string.IsNullOrEmpty(title))
                    title = doc.DefaultTitle;

                var name = Path.GetFileNameWithoutExtension(title);
                if (string.IsNullOrEmpty(name))
                    name = title;

                // Clean invalid filename chars
                foreach (var c in Path.GetInvalidFileNameChars())
                    name = name.Replace(c.ToString(), "");

                var fileName = $"{name}_{dateTag}_{count + 1}.md";
                var fullPath = Path.Combine(folder, fileName);

                try
                {
                    File.WriteAllText(fullPath, editor.Text, Encoding.UTF8);
                    count++;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"无法保存 {fileName}：{ex.Message}", "导出失败",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }

            StatusText.Text = $"已导出 {count} 个文件 → {folder}";
            MessageBox.Show($"已成功导出 {count} 个文件到：\n{folder}", "全部输出完成",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private async void Print_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (PreviewWebView.CoreWebView2 != null)
                    await PreviewWebView.CoreWebView2.ExecuteScriptAsync("window.print();");
            }
            catch
            {
                MessageBox.Show("打印功能不可用。", "提示", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private bool CloseSingleTab(TabItem tab)
        {
            if (tab.Tag is Document doc && doc.IsDirty)
            {
                var result = MessageBox.Show(
                    $"是否保存 \"{doc.Title}\" 的更改？",
                    "MD编辑器", MessageBoxButton.YesNoCancel, MessageBoxImage.Warning);
                if (result == MessageBoxResult.Cancel)
                    return false;
                if (result == MessageBoxResult.Yes)
                {
                    if (!SaveCurrentDocument(false))
                        return false;
                }
            }

            // 取消订阅编辑器事件，防止内存泄漏
            if (tab.Content is MarkdownEditor editor)
            {
                editor.TextChanged -= Editor_TextChanged;
            }

            EditorTabs.Items.Remove(tab);

            // 所有标签页已关闭：立即持久化空会话状态，避免下次启动恢复已关闭标签
            if (EditorTabs.Items.Count == 0)
                SaveSession();

            return true;
        }

        private void CloseTab_Click(object sender, RoutedEventArgs e)
        {
            if (EditorTabs.SelectedItem is TabItem tab)
            {
                if (CloseSingleTab(tab))
                    RefreshEditorState();
            }
        }

        private static T? FindAncestor<T>(DependencyObject? child) where T : DependencyObject
        {
            while (child != null)
            {
                if (child is T t) return t;
                child = VisualTreeHelper.GetParent(child);
            }
            return null;
        }

        private void CloseTabButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is DependencyObject dobj && FindAncestor<TabItem>(dobj) is TabItem tab)
            {
                if (CloseSingleTab(tab))
                    RefreshEditorState();
            }
        }

        private void Context_CloseCurrent_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem menuItem)
            {
                var menu = FindAncestor<ContextMenu>(menuItem);
                if (menu?.PlacementTarget is TabItem tab)
                {
                    if (CloseSingleTab(tab))
                        RefreshEditorState();
                }
            }
        }

        private void Context_CloseOthers_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem menuItem)
            {
                var menu = FindAncestor<ContextMenu>(menuItem);
                if (menu?.PlacementTarget is TabItem current)
                {
                    var toClose = EditorTabs.Items.OfType<TabItem>().Where(t => t != current).ToList();
                    foreach (var t in toClose)
                    {
                        if (!CloseSingleTab(t))
                            return;
                    }
                    if (EditorTabs.Items.Contains(current))
                        EditorTabs.SelectedItem = current;
                }
            }
            RefreshEditorState();
        }

        private void Context_CloseAll_Click(object sender, RoutedEventArgs e)
        {
            var all = EditorTabs.Items.OfType<TabItem>().ToList();
            foreach (var t in all)
            {
                if (!CloseSingleTab(t))
                    return;
            }
            RefreshEditorState();
        }

        private void PreviewTab_PreviewMouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (sender is TabItem tab)
            {
                tab.IsSelected = true;
            }
        }

        private void PreviewContext_CloseCurrent_Click(object sender, RoutedEventArgs e)
        {
            if (PreviewTabs.SelectedIndex >= 0 && PreviewTabs.SelectedIndex < EditorTabs.Items.Count)
            {
                var editorTab = EditorTabs.Items[PreviewTabs.SelectedIndex] as TabItem;
                if (editorTab != null) CloseSingleTab(editorTab);
                RefreshEditorState();
            }
        }

        private void PreviewContext_CloseOthers_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem menuItem)
            {
                var menu = FindAncestor<ContextMenu>(menuItem);
                if (menu?.PlacementTarget is TabItem current)
                {
                    var idx = PreviewTabs.Items.IndexOf(current);
                    var toClose = new List<TabItem>();
                    for (var i = 0; i < Math.Min(EditorTabs.Items.Count, PreviewTabs.Items.Count); i++)
                    {
                        if (i != idx && EditorTabs.Items[i] is TabItem et)
                            toClose.Add(et);
                    }
                    foreach (var t in toClose)
                    {
                        if (!CloseSingleTab(t))
                            return;
                    }
                }
            }
            RefreshEditorState();
        }

        private void PreviewContext_CloseAll_Click(object sender, RoutedEventArgs e)
        {
            var all = EditorTabs.Items.OfType<TabItem>().ToList();
            foreach (var t in all)
            {
                if (!CloseSingleTab(t))
                    return;
            }
            RefreshEditorState();
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Undo_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor?.CanUndo == true)
            {
                editor.Undo();
            }
        }

        private void Redo_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor?.CanRedo == true)
            {
                editor.Redo();
            }
        }

        private void Cut_Click(object sender, RoutedEventArgs e)
        {
            GetCurrentEditor()?.Cut();
        }

        private void Copy_Click(object sender, RoutedEventArgs e)
        {
            GetCurrentEditor()?.Copy();
        }

        private void CopyAsPlainText_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor != null)
            {
                ClipboardService.CopyPlainText(editor.SelectedText.Length > 0 ? editor.SelectedText : editor.Text);
            }
        }

        private void CopyAsMarkdown_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor != null)
            {
                ClipboardService.CopyMarkdown(editor.SelectedText.Length > 0 ? editor.SelectedText : editor.Text);
            }
        }


        private void Paste_Click(object sender, RoutedEventArgs e)
        {
            GetCurrentEditor()?.Paste();
        }

        private void PastePlainText_Click(object sender, RoutedEventArgs e)
        {
            if (GetCurrentEditor() is { } editor)
            {
                editor.ReplaceSelectedText(Clipboard.GetText(TextDataFormat.Text));
            }
        }

        private void SelectAll_Click(object sender, RoutedEventArgs e)
        {
            GetCurrentEditor()?.SelectAll();
        }

        private void FindReplace_Click(object sender, RoutedEventArgs e)
        {
            ShowFindReplaceDialog();
        }

        private void FindNextShortcut()
        {
            if (string.IsNullOrEmpty(_lastSearchText)) return;
            var editor = GetCurrentEditor();
            if (editor == null) return;
            if (!editor.FindNext(_lastSearchText, _lastSearchMatchCase, _lastSearchUseRegex))
                StatusText.Text = "未找到匹配项";
        }

        public void RememberSearch(string text, bool matchCase, bool useRegex)
        {
            _lastSearchText = text;
            _lastSearchMatchCase = matchCase;
            _lastSearchUseRegex = useRegex;
        }

        private void ShowFindReplaceDialog()
        {
            var editor = GetCurrentEditor();
            if (editor == null)
            {
                return;
            }

            var window = new FindReplaceWindow(editor, this)
            {
                Owner = this
            };
            window.Show();
        }

        private void GoToLine_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor == null) return;

            var dialog = new GoToLineDialog(editor.LineCount)
            {
                Owner = this
            };
            if (dialog.ShowDialog() == true)
            {
                editor.GoToLine(dialog.LineNumber - 1);
            }
        }

        private void SourceMode_Click(object sender, RoutedEventArgs e) => ApplyViewState(ViewLayout.SourceOnly);

        private void PreviewMode_Click(object sender, RoutedEventArgs e) => ApplyViewState(ViewLayout.PreviewOnly);

        private void SplitVertical_Click(object sender, RoutedEventArgs e) => ApplyViewState(ViewLayout.SplitVertical);

        private void SplitHorizontal_Click(object sender, RoutedEventArgs e) => ApplyViewState(ViewLayout.SplitHorizontal);

        private void FullView_Click(object sender, RoutedEventArgs e) => ApplyViewState(ViewLayout.FullView);

        private void StandardView_Click(object sender, RoutedEventArgs e) => ApplyViewState(ViewLayout.StandardView);

        private void DefaultView_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem item && item.Tag is string tag && Enum.TryParse<ViewMode>(tag, out var mode))
            {
                _settings.DefaultView = mode;
                SettingsService.Save(_settings);
                UpdateDefaultViewCheckMarks();
            }
        }

        private void UpdateDefaultViewCheckMarks()
        {
            foreach (MenuItem item in DefaultViewMenu.Items)
            {
                if (item.Tag is string tag && Enum.TryParse<ViewMode>(tag, out var mode))
                {
                    item.IsChecked = mode == _settings.DefaultView;
                }
            }
        }

        private void ApplyViewMode(ViewMode mode)
        {
            ApplyViewState(mode switch
            {
                ViewMode.SourceOnly => ViewLayout.SourceOnly,
                ViewMode.PreviewOnly => ViewLayout.PreviewOnly,
                ViewMode.SplitVertical => ViewLayout.SplitVertical,
                ViewMode.SplitHorizontal => ViewLayout.SplitHorizontal,
                ViewMode.FullView => ViewLayout.FullView,
                ViewMode.StandardView => ViewLayout.StandardView,
                ViewMode.CustomView => ViewLayout.CustomView(
                    _settings.CustomSidebarRatio, _settings.CustomEditorRatio, _settings.CustomPreviewRatio),
                _ => ViewLayout.FullView
            });
        }

        private void CustomView_Click(object sender, RoutedEventArgs e) => ApplyCustomView();

        private void CustomViewSettings_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new CustomViewDialog(_settings.CustomSidebarRatio, _settings.CustomEditorRatio, _settings.CustomPreviewRatio)
            {
                Owner = this
            };
            if (dialog.ShowDialog() == true)
            {
                _settings.CustomSidebarRatio = dialog.SidebarRatio;
                _settings.CustomEditorRatio = dialog.EditorRatio;
                _settings.CustomPreviewRatio = dialog.PreviewRatio;
                SettingsService.Save(_settings);
                ApplyCustomView();
            }
        }

        private void ApplyCustomView()
        {
            ApplyViewState(ViewLayout.CustomView(
                _settings.CustomSidebarRatio, _settings.CustomEditorRatio, _settings.CustomPreviewRatio));
        }

        private static void SetGridPosition(UIElement element, int row, int col, int rowSpan, int colSpan)
        {
            Grid.SetRow(element, row);
            Grid.SetColumn(element, col);
            Grid.SetRowSpan(element, rowSpan);
            Grid.SetColumnSpan(element, colSpan);
        }

        private void ApplyViewState(ViewLayout layout)
        {
            _currentViewLayout = layout;

            // Sidebar
            if (Sidebar != null && SidebarColumn != null)
            {
                var outerGrid = Sidebar.Parent as Grid;
                if (layout.Sidebar == PanelState.Visible)
                {
                    Sidebar.Visibility = Visibility.Visible;
                    if (outerGrid != null)
                    {
                        if (layout.SidebarRatio > 0)
                        {
                            SidebarColumn.MinWidth = 0;
                            SidebarColumn.Width = new GridLength(layout.SidebarRatio, GridUnitType.Star);
                            outerGrid.ColumnDefinitions[2].Width = new GridLength(100 - layout.SidebarRatio, GridUnitType.Star);
                        }
                        else
                        {
                            SidebarColumn.MinWidth = 150;
                            SidebarColumn.Width = new GridLength(250);
                            outerGrid.ColumnDefinitions[2].Width = new GridLength(1, GridUnitType.Star);
                        }
                        outerGrid.ColumnDefinitions[1].Width = new GridLength(2);
                    }
                }
                else
                {
                    Sidebar.Visibility = Visibility.Collapsed;
                    SidebarColumn.MinWidth = 0;
                    SidebarColumn.Width = new GridLength(0);
                    if (outerGrid != null)
                    {
                        outerGrid.ColumnDefinitions[1].Width = new GridLength(0);
                        outerGrid.ColumnDefinitions[2].Width = new GridLength(1, GridUnitType.Star);
                    }
                }
            }

            bool bothVisible = layout.Editor == PanelState.Visible && layout.Preview == PanelState.Visible;

            if (bothVisible)
            {
                if (layout.IsVerticalSplit)
                {
                    MainGrid.RowDefinitions[1].Height = new GridLength(0);
                    MainGrid.ColumnDefinitions[0].Width = new GridLength(layout.EditorRatio, GridUnitType.Star);
                    MainGrid.ColumnDefinitions[1].Width = new GridLength(2);
                    MainGrid.ColumnDefinitions[2].Width = new GridLength(layout.PreviewRatio, GridUnitType.Star);
                    PreviewSplitter.ResizeDirection = GridResizeDirection.Columns;
                    SetGridPosition(EditorTabs, 0, 0, 3, 1);
                    SetGridPosition(PreviewSplitter, 0, 1, 3, 1);
                    SetGridPosition(PreviewBorder, 0, 2, 3, 1);
                }
                else
                {
                    MainGrid.ColumnDefinitions[1].Width = new GridLength(10);
                    MainGrid.RowDefinitions[0].Height = new GridLength(layout.EditorRatio, GridUnitType.Star);
                    MainGrid.RowDefinitions[1].Height = new GridLength(2);
                    MainGrid.RowDefinitions[2].Height = new GridLength(layout.PreviewRatio, GridUnitType.Star);
                    PreviewSplitter.ResizeDirection = GridResizeDirection.Rows;
                    SetGridPosition(EditorTabs, 0, 0, 1, 3);
                    SetGridPosition(PreviewSplitter, 1, 0, 1, 3);
                    SetGridPosition(PreviewBorder, 2, 0, 1, 3);
                }
                EditorTabs.Visibility = Visibility.Visible;
                PreviewBorder.Visibility = Visibility.Visible;
                PreviewSplitter.Visibility = Visibility.Visible;
            }
            else if (layout.Editor == PanelState.Visible)
            {
                MainGrid.ColumnDefinitions[0].Width = new GridLength(1, GridUnitType.Star);
                MainGrid.ColumnDefinitions[1].Width = new GridLength(10);
                MainGrid.ColumnDefinitions[2].Width = new GridLength(0);
                MainGrid.RowDefinitions[1].Height = new GridLength(0);
                SetGridPosition(EditorTabs, 0, 0, 3, 3);
                EditorTabs.Visibility = Visibility.Visible;
                PreviewBorder.Visibility = Visibility.Collapsed;
                PreviewSplitter.Visibility = Visibility.Collapsed;
            }
            else
            {
                MainGrid.ColumnDefinitions[0].Width = new GridLength(0);
                MainGrid.ColumnDefinitions[1].Width = new GridLength(10);
                MainGrid.ColumnDefinitions[2].Width = new GridLength(1, GridUnitType.Star);
                MainGrid.RowDefinitions[1].Height = new GridLength(0);
                SetGridPosition(PreviewBorder, 0, 0, 3, 3);
                EditorTabs.Visibility = Visibility.Collapsed;
                PreviewBorder.Visibility = Visibility.Visible;
                PreviewSplitter.Visibility = Visibility.Collapsed;
            }

            StatusText.Text = layout.Label;
        }

        private void FullScreen_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
        }


        private void SidebarToggleButton_Click(object sender, RoutedEventArgs e)
        {
            ToggleSidebar_Click(sender, e);
        }

        private void LineNumberToggleButton_Click(object sender, RoutedEventArgs e)
        {
            ToggleLineNumbers_Click(sender, e);
        }



        private void EditorToggleButton_Click(object sender, RoutedEventArgs e)
        {
            var cur = _currentViewLayout;
            if (cur.Editor == PanelState.Visible && cur.Preview == PanelState.Visible)
                ApplyViewState(ViewLayout.PreviewOnly);
            else if (cur.Editor == PanelState.Visible)
                ApplyViewState(ViewLayout.PreviewOnly);
            else if (cur.Preview == PanelState.Visible)
                ApplyViewState(ViewLayout.SplitVertical);
            else
                ApplyViewState(ViewLayout.SourceOnly);
        }

        private void PreviewToggleButton_Click(object sender, RoutedEventArgs e)
        {
            var cur = _currentViewLayout;
            if (cur.Preview == PanelState.Visible && cur.Editor == PanelState.Visible)
                ApplyViewState(ViewLayout.SourceOnly);
            else if (cur.Preview == PanelState.Visible)
                ApplyViewState(ViewLayout.SourceOnly);
            else if (cur.Editor == PanelState.Visible)
                ApplyViewState(ViewLayout.SplitVertical);
            else
                ApplyViewState(ViewLayout.PreviewOnly);
        }

        private void ToggleSidebar_Click(object sender, RoutedEventArgs e)
        {
            if (Sidebar != null && SidebarColumn != null)
            {
                var isVisible = Sidebar.Visibility == Visibility.Visible;
                Sidebar.Visibility = isVisible ? Visibility.Collapsed : Visibility.Visible;
                SidebarColumn.MinWidth = isVisible ? 0 : 150;
                SidebarColumn.Width = isVisible ? new GridLength(0) : new GridLength(250);

                var outerGrid = Sidebar.Parent as Grid;
                if (outerGrid != null)
                {
                    outerGrid.ColumnDefinitions[1].Width = isVisible ? new GridLength(0) : new GridLength(2);
                }

                StatusText.Text = Sidebar.Visibility == Visibility.Visible ? "侧边栏：已显示" : "侧边栏：已隐藏";
            }
        }

        private void Window_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
        {
            if (Keyboard.Modifiers != ModifierKeys.Control)
                return;

            var editor = GetCurrentEditor();
            if (editor == null)
                return;

            if (e.Delta > 0)
                editor.ZoomIn();
            else
                editor.ZoomOut();

            e.Handled = true;
        }

        private void Window_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (Keyboard.Modifiers != ModifierKeys.Control)
                return;

            switch (e.Key)
            {
                case Key.Left:
                    ToolBar_PromoteHeading_Click(null!, null!);
                    e.Handled = true;
                    break;
                case Key.Right:
                    ToolBar_DemoteHeading_Click(null!, null!);
                    e.Handled = true;
                    break;
                case Key.Up:
                    ToolBar_MoveLineUp_Click(null!, null!);
                    e.Handled = true;
                    break;
                case Key.Down:
                    ToolBar_MoveLineDown_Click(null!, null!);
                    e.Handled = true;
                    break;
            }
        }

        private void ZoomIn_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor != null)
            {
                editor.ZoomIn();
            }
        }

        private void ZoomOut_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor != null)
            {
                editor.ZoomOut();
            }
        }

        private void ResetZoom_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            editor?.ResetZoom();
        }

        private void ToggleTheme_Click(object sender, RoutedEventArgs e)
        {
            _settings.IsDarkTheme = !_settings.IsDarkTheme;
            SettingsService.Save(_settings);
            ApplyTheme();
            UpdatePreview();
        }

        private void Heading_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem item && int.TryParse(item.Tag?.ToString(), out var level))
            {
                InsertHeading(level);
            }
        }

        private void InsertHeading(int level)
        {
            var prefix = new string('#', Math.Max(1, Math.Min(level, 6))) + " ";
            WrapSelection(prefix, string.Empty);
        }

        private void Bold_Click(object sender, RoutedEventArgs e) => WrapSelection("**", "**");
        private void Italic_Click(object sender, RoutedEventArgs e) => WrapSelection("*", "*");
        private void Strikethrough_Click(object sender, RoutedEventArgs e) => WrapSelection("~~", "~~");
        private void InlineCode_Click(object sender, RoutedEventArgs e) => WrapSelection("`", "`");
        private void CodeBlock_Click(object sender, RoutedEventArgs e) => WrapSelection("```\r\n", "\r\n```");
        private void BlockQuote_Click(object sender, RoutedEventArgs e) => WrapSelection("> ", string.Empty);
        private void UnorderedList_Click(object sender, RoutedEventArgs e) => ApplyPerLinePrefix("- ");
        private void OrderedList_Click(object sender, RoutedEventArgs e) => ApplyOrderedList();
        private void TaskList_Click(object sender, RoutedEventArgs e) => ApplyPerLinePrefix("- [ ] ");
        private void Link_Click(object sender, RoutedEventArgs e) => WrapSelection("[", "]()" );
        private void Image_Click(object sender, RoutedEventArgs e) => WrapSelection("![", "]()" );
        private string _editorFontFamily;
        private double _editorFontSize;

        private void PopulateFontMenu()
        {
            FontMenu.Items.Clear();

            // Common English fonts
            var enFonts = new[] { "Consolas", "Courier New", "Arial", "Times New Roman", "Segoe UI", "Verdana", "Calibri", "Lucida Console" };
            foreach (var name in enFonts)
            {
                var item = new MenuItem { Header = name, Tag = name };
                item.Click += Font_Click;
                FontMenu.Items.Add(item);
            }

            FontMenu.Items.Add(new Separator());

            // System Chinese fonts — show Chinese display name, store English source for FontFamily
            var cnList = new List<(string eng, string cn)>();
            var seen = new HashSet<string>();
            try
            {
                var zhLang = System.Windows.Markup.XmlLanguage.GetLanguage("zh-cn");
                foreach (var f in System.Windows.Media.Fonts.SystemFontFamilies)
                {
                    var cn = f.FamilyNames.TryGetValue(zhLang, out var zhName) ? zhName : null;
                    if (string.IsNullOrEmpty(cn))
                    {
                        // Fallback: check if Source contains CJK characters
                        if (f.Source.Any(c => c >= 0x4E00 && c <= 0x9FFF))
                            cn = f.Source;
                    }
                    if (!string.IsNullOrEmpty(cn) && !seen.Contains(cn))
                    {
                        seen.Add(cn);
                        cnList.Add((f.Source, cn));
                    }
                }
            }
            catch { }

            if (cnList.Count == 0)
                cnList.AddRange(new[] {
                    ("SimSun", "宋体"), ("SimHei", "黑体"), ("KaiTi", "楷体"),
                    ("FangSong", "仿宋"), ("Microsoft YaHei", "微软雅黑")
                });

            cnList.Sort((a, b) => string.Compare(a.cn, b.cn));
            foreach (var (eng, cn) in cnList)
            {
                var item = new MenuItem { Header = cn, Tag = eng };
                item.Click += Font_Click;
                FontMenu.Items.Add(item);
            }
        }

        private void Font_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not MenuItem item || item.Tag is not string fontName)
                return;

            try
            {
                _editorFontFamily = fontName;
                _settings.EditorFontFamily = fontName;
                SettingsService.Save(_settings);
                ApplyFontToAllEditors();
                StatusText.Text = $"显示字体：{fontName}";
            }
            catch
            {
                StatusText.Text = $"字体无效：{fontName}";
            }
        }

        private void FontSize_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem item && item.Tag is string size)
            {
                if (TryParseFontSize(size, out var px))
                {
                    _editorFontSize = px;
                    _settings.EditorFontSize = px;
                    SettingsService.Save(_settings);
                    ApplyFontToAllEditors();
                }
            }
        }

        private void FontSizeCustom_Click(object sender, RoutedEventArgs e)
        {
            var input = ShowInputDialog("自定义字号", "请输入字号数值（如 12、16、20）：", "16");
            if (!string.IsNullOrWhiteSpace(input) && double.TryParse(input, out var px) && px > 0)
            {
                _editorFontSize = px;
                _settings.EditorFontSize = px;
                SettingsService.Save(_settings);
                ApplyFontToAllEditors();
            }
        }

        private void ApplyFontToAllEditors()
        {
            foreach (var tab in EditorTabs.Items.OfType<TabItem>())
            {
                if (tab.Content is MarkdownEditor editor)
                {
                    editor.SetFontFamily(_editorFontFamily);
                    editor.SetFontSize(_editorFontSize);
                }
            }
        }

        private static bool TryParseFontSize(string size, out double px)
        {
            px = 0;
            if (size.EndsWith("pt"))
            {
                if (double.TryParse(size.Replace("pt", ""), out var pt))
                {
                    px = Math.Round(pt * 4.0 / 3.0); // pt → WPF dip
                    return true;
                }
            }
            else if (size.EndsWith("px"))
            {
                return double.TryParse(size.Replace("px", ""), out px);
            }
            return false;
        }

        private static string? ShowInputDialog(string title, string prompt, string defaultValue)
        {
            var window = new Window
            {
                Title = title,
                Width = 360,
                Height = 160,
                ResizeMode = ResizeMode.NoResize,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                Owner = System.Windows.Application.Current.MainWindow,
                ShowInTaskbar = false
            };

            var grid = new System.Windows.Controls.Grid { Margin = new Thickness(12) };
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            var label = new System.Windows.Controls.Label { Content = prompt };
            System.Windows.Controls.Grid.SetRow(label, 0);

            var textBox = new System.Windows.Controls.TextBox { Text = defaultValue, Margin = new Thickness(0, 4, 0, 8) };
            System.Windows.Controls.Grid.SetRow(textBox, 1);

            var btnPanel = new System.Windows.Controls.StackPanel
            {
                Orientation = System.Windows.Controls.Orientation.Horizontal,
                HorizontalAlignment = System.Windows.HorizontalAlignment.Right
            };
            System.Windows.Controls.Grid.SetRow(btnPanel, 2);

            string? result = null;
            var okBtn = new System.Windows.Controls.Button { Content = "确定", Width = 70, Margin = new Thickness(4, 0, 0, 0), IsDefault = true };
            var cancelBtn = new System.Windows.Controls.Button { Content = "取消", Width = 70, Margin = new Thickness(4, 0, 0, 0), IsCancel = true };

            okBtn.Click += (_, _) => { result = textBox.Text; window.DialogResult = true; window.Close(); };
            cancelBtn.Click += (_, _) => { window.DialogResult = false; window.Close(); };

            btnPanel.Children.Add(okBtn);
            btnPanel.Children.Add(cancelBtn);

            grid.Children.Add(label);
            grid.Children.Add(textBox);
            grid.Children.Add(btnPanel);
            window.Content = grid;

            window.ShowDialog();
            return result;
        }

        private void Table_Click(object sender, RoutedEventArgs e) => WrapSelection("| 列1 | 列2 |\r\n| --- | --- |\r\n", string.Empty);
        private void HorizontalRule_Click(object sender, RoutedEventArgs e) => WrapSelection("---\r\n", string.Empty);

        // === 工具栏按钮处理（委托到现有方法） ===
        // 文件操作
        private void ToolBar_New_Click(object sender, RoutedEventArgs e) => NewFile_Click(sender, e);
        private void ToolBar_Open_Click(object sender, RoutedEventArgs e) => OpenFile_Click(sender, e);
        private void ToolBar_Save_Click(object sender, RoutedEventArgs e) => SaveFile_Click(sender, e);
        private void ToolBar_SaveAs_Click(object sender, RoutedEventArgs e) => SaveAsMd_Click(sender, e);
        private void ToolBar_Print_Click(object sender, RoutedEventArgs e) => Print_Click(sender, e);

        // 格式
        private void ToolBar_Bold_Click(object sender, RoutedEventArgs e) => Bold_Click(sender, e);
        private void ToolBar_Italic_Click(object sender, RoutedEventArgs e) => Italic_Click(sender, e);
        private void ToolBar_Strikethrough_Click(object sender, RoutedEventArgs e) => Strikethrough_Click(sender, e);
        private void ToolBar_InlineCode_Click(object sender, RoutedEventArgs e) => InlineCode_Click(sender, e);
        private void ToolBar_CodeBlock_Click(object sender, RoutedEventArgs e) => CodeBlock_Click(sender, e);
        private void ToolBar_BlockQuote_Click(object sender, RoutedEventArgs e) => BlockQuote_Click(sender, e);
        private void ToolBar_UnorderedList_Click(object sender, RoutedEventArgs e) => UnorderedList_Click(sender, e);
        private void ToolBar_OrderedList_Click(object sender, RoutedEventArgs e) => OrderedList_Click(sender, e);
        private void ToolBar_TaskList_Click(object sender, RoutedEventArgs e) => TaskList_Click(sender, e);
        private void ToolBar_Link_Click(object sender, RoutedEventArgs e) => Link_Click(sender, e);

        private void ToolBar_HorizontalRule_Click(object sender, RoutedEventArgs e) => HorizontalRule_Click(sender, e);
        private void ToolBar_Color_Click(object sender, RoutedEventArgs e)
        {
            if (sender is System.Windows.Controls.Button btn)
            {
                var menu = new ContextMenu();
                var colors = new (string Name, string Hex)[]
                {
                    ("红色",   "#FF0000"),
                    ("橙色",   "#FF6600"),
                    ("黄色",   "#CCAA00"),
                    ("绿色",   "#008000"),
                    ("蓝色",   "#0066FF"),
                    ("青色",   "#0088AA"),
                    ("紫色",   "#800080"),
                    ("粉色",   "#FF3399"),
                    ("白色",   "#FFFFFF"),
                    ("灰色",   "#808080"),
                    ("棕色",   "#8B4513"),
                    ("黑色",   "#000000"),
                };
                foreach (var (name, hex) in colors)
                {
                    var item = new MenuItem { Header = name, Tag = hex };
                    item.Click += ColorItem_Click;
                    menu.Items.Add(item);
                }
                menu.PlacementTarget = btn;
                menu.IsOpen = true;
            }
        }
        private void ColorItem_Click(object sender, RoutedEventArgs e)
        {
            if (sender is MenuItem item && item.Tag is string color)
            {
                WrapSelection($"<span style=\"color:{color}\">", "</span>");
            }
        }

        // === 当前行标题级别操作 ===

        /// <summary>获取当前光标所在行的上下文（所有行数组 + 当前行索引）</summary>
        private (string[] Lines, int LineIdx) GetCurrentLineContext()
        {
            var editor = GetCurrentEditor();
            if (editor == null) return (Array.Empty<string>(), -1);

            var text = editor.Text;
            if (string.IsNullOrEmpty(text)) return (new[] { string.Empty }, 0);

            var caret = editor.GetCaretIndex();
            var lines = SplitLines(text);

            var pos = 0;
            for (var i = 0; i < lines.Length; i++)
            {
                var lineEnd = pos + lines[i].Length;
                if (caret >= pos && caret <= lineEnd)
                    return (lines, i);
                pos = lineEnd + GetNewlineLength(text, pos);
            }
            // 光标在文本末尾
            return (lines, Math.Max(0, lines.Length - 1));
        }

        private static string[] SplitLines(string text) =>
            text.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);

        private static int GetNewlineLength(string text, int pos)
        {
            if (pos >= text.Length) return 0;
            if (text[pos] == '\r') return pos + 1 < text.Length && text[pos + 1] == '\n' ? 2 : 1;
            if (text[pos] == '\n') return 1;
            return 0;
        }

        /// <summary>将修改后的行数组写回编辑器，并定位光标到目标行</summary>
        private void ApplyLineChanges(string[] lines, int caretLine)
        {
            var editor = GetCurrentEditor();
            if (editor == null) return;

            // 检测并保留原始换行符
            var newline = editor.Text.Contains("\r\n") ? "\r\n"
                : editor.Text.Contains("\n") ? "\n"
                : Environment.NewLine;
            var newText = string.Join(newline, lines);

            // 计算新光标位置：目标行起始 + 该行标题前缀后的偏移
            var newCaret = 0;
            for (var i = 0; i < caretLine && i < lines.Length; i++)
                newCaret += lines[i].Length + newline.Length; // 使用检测到的换行符长度，而非 Environment.NewLine.Length
            newCaret = Math.Min(newCaret, newText.Length);

            editor.Text = newText;
            editor.SetCaretIndex(newCaret);
            editor.Focus();
        }

        /// <summary>去掉标题行首的 ## 标记和可选编号，返回纯内容</summary>
        private static (string Indent, string Content) StripHeadingLine(string line)
        {
            var trimmedStart = line.TrimStart();
            var indent = line[..(line.Length - trimmedStart.Length)];

            if (string.IsNullOrEmpty(trimmedStart) || trimmedStart[0] != '#')
                return (indent, trimmedStart);

            var level = trimmedStart.TakeWhile(c => c == '#').Count();
            if (level < 1 || level > 6 || trimmedStart.Length <= level || trimmedStart[level] != ' ')
                return (indent, trimmedStart);

            var afterMarkers = trimmedStart[(level + 1)..].TrimStart();
            // 移除可能的编号（如 1. / 1.1.）
            afterMarkers = StripHeadingNumber(afterMarkers);
            return (indent, afterMarkers);
        }

        /// <summary>将当前行设为指定级别的标题</summary>
        private void SetCurrentLineHeading(int level)
        {
            if (level < 1 || level > 6) return;
            var (lines, lineIdx) = GetCurrentLineContext();
            if (lineIdx < 0 || lineIdx >= lines.Length) return;

            var (indent, content) = StripHeadingLine(lines[lineIdx]);
            if (string.IsNullOrWhiteSpace(content))
                content = "标题";
            lines[lineIdx] = indent + new string('#', level) + " " + content;
            ApplyLineChanges(lines, lineIdx);
            StatusText.Text = $"已设为标题 {level}";
        }

        /// <summary>当前行设为正文（移除标题标记）</summary>
        private void SetCurrentLineToBody()
        {
            var (lines, lineIdx) = GetCurrentLineContext();
            if (lineIdx < 0 || lineIdx >= lines.Length) return;

            var trimmed = lines[lineIdx].TrimStart();
            if (trimmed.Length == 0 || trimmed[0] != '#')
            {
                StatusText.Text = "当前行非标题";
                return;
            }

            var (indent, content) = StripHeadingLine(lines[lineIdx]);
            lines[lineIdx] = indent + content;
            ApplyLineChanges(lines, lineIdx);
            StatusText.Text = "已设为正文";
        }

        /// <summary>标题升级：减少 # 数量（## → # → 正文）</summary>
        private void PromoteHeadingLevel()
        {
            var (lines, lineIdx) = GetCurrentLineContext();
            if (lineIdx < 0 || lineIdx >= lines.Length) return;

            var trimmed = lines[lineIdx].TrimStart();
            if (trimmed.Length == 0 || trimmed[0] != '#')
            {
                StatusText.Text = "当前行非标题";
                return;
            }

            var level = trimmed.TakeWhile(c => c == '#').Count();
            if (level < 1 || level > 6)
            {
                StatusText.Text = "当前行非标题";
                return;
            }

            var (indent, content) = StripHeadingLine(lines[lineIdx]);
            if (level == 1)
            {
                // 已经是最高级标题，再升级变为正文
                lines[lineIdx] = indent + content;
                StatusText.Text = "已升级为正文";
            }
            else
            {
                lines[lineIdx] = indent + new string('#', level - 1) + " " + content;
                StatusText.Text = $"已升级为标题 {level - 1}";
            }
            ApplyLineChanges(lines, lineIdx);
        }

        /// <summary>标题降级：增加 # 数量（正文 → # → ## → … → ######）</summary>
        private void DemoteHeadingLevel()
        {
            var (lines, lineIdx) = GetCurrentLineContext();
            if (lineIdx < 0 || lineIdx >= lines.Length) return;

            var trimmed = lines[lineIdx].TrimStart();
            var indent = lines[lineIdx][..(lines[lineIdx].Length - trimmed.Length)];

            if (trimmed.Length == 0 || trimmed[0] != '#')
            {
                // 正文 → 变为标题 1
                lines[lineIdx] = indent + "# " + (string.IsNullOrWhiteSpace(trimmed) ? "标题" : trimmed);
                StatusText.Text = "已降级为标题 1";
                ApplyLineChanges(lines, lineIdx);
                return;
            }

            var level = trimmed.TakeWhile(c => c == '#').Count();
            if (level < 1 || level > 6)
            {
                StatusText.Text = "当前行非标题";
                return;
            }

            if (level == 6)
            {
                // 已经是最低级标题，降级变为正文
                var (_, content) = StripHeadingLine(lines[lineIdx]);
                lines[lineIdx] = indent + content;
                StatusText.Text = "已降级为正文";
            }
            else
            {
                var (_, content) = StripHeadingLine(lines[lineIdx]);
                lines[lineIdx] = indent + new string('#', level + 1) + " " + content;
                StatusText.Text = $"已降级为标题 {level + 1}";
            }
            ApplyLineChanges(lines, lineIdx);
        }

        /// <summary>当前行上移</summary>
        private void MoveCurrentLineUp()
        {
            var (lines, lineIdx) = GetCurrentLineContext();
            if (lineIdx <= 0 || lineIdx >= lines.Length) return;

            (lines[lineIdx - 1], lines[lineIdx]) = (lines[lineIdx], lines[lineIdx - 1]);
            ApplyLineChanges(lines, lineIdx - 1);
            StatusText.Text = "当前行已上移";
        }

        /// <summary>当前行下移</summary>
        private void MoveCurrentLineDown()
        {
            var (lines, lineIdx) = GetCurrentLineContext();
            if (lineIdx < 0 || lineIdx >= lines.Length - 1) return;

            (lines[lineIdx], lines[lineIdx + 1]) = (lines[lineIdx + 1], lines[lineIdx]);
            ApplyLineChanges(lines, lineIdx + 1);
            StatusText.Text = "当前行已下移";
        }

        // 工具栏 Click 转发
        private void ToolBar_PromoteHeading_Click(object sender, RoutedEventArgs e) => PromoteHeadingLevel();
        private void ToolBar_DemoteHeading_Click(object sender, RoutedEventArgs e) => DemoteHeadingLevel();
        private void ToolBar_MoveLineUp_Click(object sender, RoutedEventArgs e) => MoveCurrentLineUp();
        private void ToolBar_MoveLineDown_Click(object sender, RoutedEventArgs e) => MoveCurrentLineDown();
        private void ToolBar_SetBody_Click(object sender, RoutedEventArgs e) => SetCurrentLineToBody();
        private void ToolBar_SetH1_Click(object sender, RoutedEventArgs e) => SetCurrentLineHeading(1);
        private void ToolBar_SetH2_Click(object sender, RoutedEventArgs e) => SetCurrentLineHeading(2);
        private void ToolBar_SetH3_Click(object sender, RoutedEventArgs e) => SetCurrentLineHeading(3);
        private void ToolBar_SetH4_Click(object sender, RoutedEventArgs e) => SetCurrentLineHeading(4);
        private void ToolBar_SetH5_Click(object sender, RoutedEventArgs e) => SetCurrentLineHeading(5);
        private void ToolBar_SetH6_Click(object sender, RoutedEventArgs e) => SetCurrentLineHeading(6);

        private void WordCount_Click(object sender, RoutedEventArgs e)
        {
            var document = GetCurrentDocument();
            if (document != null)
            {
                var content = document.Content ?? string.Empty;
                var words = content.Split(new[] { ' ', '\r', '\n', '\t' }, StringSplitOptions.RemoveEmptyEntries).Length;
                MessageBox.Show($"当前文档字数：{words}", "字数统计", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }



        private void InsertToc_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor == null) return;

            var lines = editor.Text.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
            var toc = new StringBuilder();
            toc.AppendLine("<!-- TOC -->");

            foreach (var line in lines)
            {
                var trimmed = line.TrimStart();
                if (!trimmed.StartsWith("#")) continue;

                var level = trimmed.TakeWhile(c => c == '#').Count();
                if (level < 1 || level > 6) continue;

                // Must have a space after # markers to be a proper heading
                if (trimmed.Length <= level || trimmed[level] != ' ') continue;

                var title = trimmed[(level + 1)..].Trim();
                if (string.IsNullOrWhiteSpace(title)) continue;

                var anchor = GenerateAnchor(title);
                var indent = new string(' ', (level - 1) * 2);
                toc.AppendLine($"{indent}- [{title}](#{anchor})");
            }

            toc.AppendLine();
            editor.InsertTextAtCaret(toc.ToString());
        }

        private static string GenerateAnchor(string heading)
        {
            var sb = new StringBuilder();
            var lastWasDash = false;
            foreach (var c in heading.ToLowerInvariant())
            {
                if (char.IsLetterOrDigit(c))
                {
                    sb.Append(c);
                    lastWasDash = false;
                }
                else if (!lastWasDash && (c == ' ' || c == '-' || c == '_'))
                {
                    sb.Append('-');
                    lastWasDash = true;
                }
                else if (c > 127)
                {
                    // Preserve CJK and other non-ASCII characters
                    sb.Append(c);
                    lastWasDash = false;
                }
            }
            // Trim trailing dashes
            while (sb.Length > 0 && sb[^1] == '-')
                sb.Length--;
            return sb.ToString();
        }

        // === 标题编号 ===

        /// <summary>
        /// 重新标题编号：为文档中所有标题按层级添加序号（如 1. / 1.1. / 1.1.1.）
        /// </summary>
        private void RenumberHeadings_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor == null) return;

            var text = editor.Text;
            var lines = text.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
            var counters = new int[7]; // index 1-6 for h1-h6, index 0 unused
            var sb = new StringBuilder();

            foreach (var line in lines)
            {
                var trimmedStart = line.TrimStart();
                if (IsHeadingLine(trimmedStart, out var level, out var title))
                {
                    // Remove any existing numbering first
                    title = StripHeadingNumber(title);

                    // Increment counter for this level and reset deeper levels
                    counters[level]++;
                    for (var i = level + 1; i <= 6; i++)
                        counters[i] = 0;

                    // Build number string: e.g. "1.", "1.1.", "1.1.1."
                    var numberStr = new StringBuilder();
                    for (var i = 1; i <= level; i++)
                    {
                        numberStr.Append(counters[i]);
                        numberStr.Append('.');
                    }

                    var indent = line[..(line.Length - trimmedStart.Length)];
                    sb.Append(indent);
                    sb.Append(new string('#', level));
                    sb.Append(' ');
                    sb.Append(numberStr);
                    sb.Append(' ');
                    sb.Append(title);
                }
                else
                {
                    sb.Append(line);
                }
                sb.AppendLine();
            }

            // Remove trailing newline
            if (sb.Length > 0 && sb[^1] == '\n')
                sb.Length -= Environment.NewLine.Length > 0 && sb.Length >= Environment.NewLine.Length
                    ? Environment.NewLine.Length : 1;

            editor.Text = sb.ToString();
            StatusText.Text = "标题编号已完成";
        }

        /// <summary>
        /// 取消标题编号：移除所有标题前的数字序号（如 1. / 1.1. / 2.3.1.）
        /// </summary>
        private void RemoveHeadingNumbers_Click(object sender, RoutedEventArgs e)
        {
            var editor = GetCurrentEditor();
            if (editor == null) return;

            var text = editor.Text;
            var lines = text.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
            var sb = new StringBuilder();
            var changed = false;

            foreach (var line in lines)
            {
                var trimmedStart = line.TrimStart();
                if (IsHeadingLine(trimmedStart, out var level, out var title))
                {
                    var stripped = StripHeadingNumber(title);
                    if (stripped != title)
                    {
                        changed = true;
                        var indent = line[..(line.Length - trimmedStart.Length)];
                        sb.Append(indent);
                        sb.Append(new string('#', level));
                        sb.Append(' ');
                        sb.Append(stripped);
                    }
                    else
                    {
                        sb.Append(line);
                    }
                }
                else
                {
                    sb.Append(line);
                }
                sb.AppendLine();
            }

            if (sb.Length > 0 && sb[^1] == '\n')
                sb.Length -= Environment.NewLine.Length > 0 && sb.Length >= Environment.NewLine.Length
                    ? Environment.NewLine.Length : 1;

            editor.Text = sb.ToString();
            StatusText.Text = changed ? "标题编号已取消" : "未检测到标题编号";
        }

        /// <summary>
        /// 判断是否为标题行。格式：1-6 个 # 后跟空格 + 内容。
        /// </summary>
        private static bool IsHeadingLine(string trimmed, out int level, out string title)
        {
            level = 0;
            title = string.Empty;

            if (string.IsNullOrEmpty(trimmed) || trimmed[0] != '#')
                return false;

            level = trimmed.TakeWhile(c => c == '#').Count();
            if (level < 1 || level > 6)
                return false;

            if (trimmed.Length <= level || trimmed[level] != ' ')
                return false;

            title = trimmed[(level + 1)..].TrimEnd();
            return true;
        }

        /// <summary>
        /// 移除标题文本开头的数字编号。支持格式：1. / 1.1. / 1.1.1. / 1.1.1.1. 等（最多6层）
        /// </summary>
        private static string StripHeadingNumber(string title)
        {
            if (string.IsNullOrEmpty(title))
                return title;

            var span = title.AsSpan().TrimStart();

            // Match pattern: digit(s).digit(s). ... digit(s). with 1-6 levels
            var pos = 0;
            var dotCount = 0;
            while (pos < span.Length && dotCount < 6)
            {
                // Skip leading whitespace
                while (pos < span.Length && span[pos] == ' ')
                    pos++;

                // Read digits
                var digitStart = pos;
                while (pos < span.Length && char.IsDigit(span[pos]))
                    pos++;

                if (pos == digitStart)
                    break; // no digits found

                // Expect a dot
                if (pos >= span.Length || span[pos] != '.')
                    break;

                pos++; // skip dot
                dotCount++;

                // After the dot, expect either:
                // - a space (end of number prefix)
                // - more digits (next level)
                // - end of string
                if (pos < span.Length && span[pos] == ' ')
                {
                    pos++; // skip space after number
                    break;
                }
            }

            if (dotCount == 0)
                return title;

            return span[pos..].TrimStart().ToString();
        }



        private void SetDefaultApp_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var exePath = Environment.ProcessPath;
                if (string.IsNullOrEmpty(exePath) || !File.Exists(exePath))
                {
                    MessageBox.Show("无法获取程序路径，请将程序放置到固定目录后再试。", "设置失败", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                var progId = "MDEditor.md";

                // 1. Register ProgId with shell open command
                using (var progKey = Registry.CurrentUser.CreateSubKey($@"Software\Classes\{progId}"))
                    progKey?.SetValue("", "MD 文本编辑器文档");

                using (var iconKey = Registry.CurrentUser.CreateSubKey($@"Software\Classes\{progId}\DefaultIcon"))
                    iconKey?.SetValue("", $"\"{exePath}\",0");

                using (var cmdKey = Registry.CurrentUser.CreateSubKey($@"Software\Classes\{progId}\shell\open\command"))
                    cmdKey?.SetValue("", $"\"{exePath}\" \"%1\"");

                // 2. Register extension → ProgId mapping
                using (var extKey = Registry.CurrentUser.CreateSubKey(@"Software\Classes\.md"))
                {
                    if (extKey == null) throw new Exception("无法写入注册表");
                    extKey.SetValue("", progId);
                    using (var owp = extKey.CreateSubKey("OpenWithProgids"))
                        owp?.SetValue(progId, "");
                }

                // 3. Clear existing UserChoice so our ProgId mapping takes effect
                try
                {
                    var fileExtsPath = @"Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.md";
                    Registry.CurrentUser.DeleteSubKeyTree(fileExtsPath + @"\UserChoice", false);
                }
                catch { }

                // 4. Create a temp .md file and open the "Open With" dialog so user can confirm
                var result = MessageBox.Show(
                    "注册表已更新。是否立即打开系统关联对话框确认？\n\n" +
                    "(选择\"MD编辑器\"后勾选\"始终使用此应用打开\"即可完成设置)",
                    "设置默认程序", MessageBoxButton.YesNo, MessageBoxImage.Information);

                if (result == MessageBoxResult.Yes)
                {
                    var tempMd = Path.Combine(
                        Path.GetDirectoryName(Environment.ProcessPath) ?? Path.GetTempPath(),
                        "md_association_setup.md");
                    try
                    {
                        File.WriteAllText(tempMd, "# Test");
                        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                        {
                            FileName = "rundll32.exe",
                            Arguments = $"shell32.dll,OpenAs_RunDLL \"{tempMd}\"",
                            UseShellExecute = false
                        });
                    }
                    finally
                    {
                        try { File.Delete(tempMd); } catch { }
                    }
                }

                StatusText.Text = "已注册 .md 文件关联";
            }
            catch (Exception ex)
            {
                MessageBox.Show("设置默认程序失败：" + ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RemoveDefaultApp_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Remove ProgId registration
                Registry.CurrentUser.DeleteSubKeyTree(@"Software\Classes\MDEditor.md", false);
            }
            catch { }

            try
            {
                // Remove extension mapping (only if it points to us)
                using (var extKey = Registry.CurrentUser.OpenSubKey(@"Software\Classes\.md", writable: true))
                {
                    if (extKey?.GetValue("") as string == "MDEditor.md")
                    {
                        extKey.DeleteValue("");
                    }
                    // Remove our OpenWithProgids entry
                    try { extKey?.DeleteSubKeyTree("OpenWithProgids", false); } catch { }
                }
            }
            catch { }

            try
            {
                // Clear UserChoice if it references our ProgId
                var ucPath = @"Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.md\UserChoice";
                using (var ucKey = Registry.CurrentUser.OpenSubKey(ucPath, writable: true))
                {
                    if (ucKey?.GetValue("Progid") as string == "MDEditor.md")
                    {
                        Registry.CurrentUser.DeleteSubKeyTree(ucPath, false);
                    }
                }
            }
            catch { }

            StatusText.Text = "已取消 .md 文件默认关联";
            MessageBox.Show("已取消本程序与 .md 文件的关联。", "已取消", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void About_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("MD编辑器 for Win11\n版本：v3.7\n作者：帅气的锅巴\n技术栈：WPF + .NET 10 + WebView2 + Markdig", "关于", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void WrapSelection(string prefix, string suffix)
        {
            var editor = GetCurrentEditor();
            if (editor == null)
            {
                return;
            }

            var selection = editor.SelectedText;
            if (string.IsNullOrEmpty(selection))
            {
                editor.InsertTextAtCaret(prefix + suffix);
            }
            else
            {
                editor.ReplaceSelectedText(prefix + selection + suffix);
            }
        }

        private void ApplyPerLinePrefix(string prefix)
        {
            var editor = GetCurrentEditor();
            if (editor == null) return;

            var selection = editor.SelectedText;
            if (string.IsNullOrEmpty(selection))
            {
                editor.InsertTextAtCaret(prefix);
                return;
            }

            var lines = selection.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
            var sb = new StringBuilder();
            for (var i = 0; i < lines.Length; i++)
            {
                if (i > 0) sb.AppendLine();
                if (!string.IsNullOrWhiteSpace(lines[i]))
                    sb.Append(prefix + lines[i]);
                else
                    sb.Append(lines[i]);
            }
            editor.ReplaceSelectedText(sb.ToString());
        }

        private void ApplyOrderedList()
        {
            var editor = GetCurrentEditor();
            if (editor == null) return;

            var selection = editor.SelectedText;
            if (string.IsNullOrEmpty(selection))
            {
                editor.InsertTextAtCaret("1. ");
                return;
            }

            var lines = selection.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
            var sb = new StringBuilder();
            var num = 1;
            for (var i = 0; i < lines.Length; i++)
            {
                if (i > 0) sb.AppendLine();
                if (!string.IsNullOrWhiteSpace(lines[i]))
                {
                    sb.Append(num + ". " + lines[i]);
                    num++;
                }
                else
                {
                    sb.Append(lines[i]);
                }
            }
            editor.ReplaceSelectedText(sb.ToString());
        }

        private void EditorTabs_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdatePreview();
            SyncPreviewTabSelection();
        }

        private void PreviewTabs_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_isSyncingTabs) return;
            _isSyncingTabs = true;
            if (PreviewTabs.SelectedIndex >= 0 && PreviewTabs.SelectedIndex < EditorTabs.Items.Count)
                EditorTabs.SelectedIndex = PreviewTabs.SelectedIndex;
            _isSyncingTabs = false;
        }

        private void SyncPreviewTabSelection()
        {
            if (_isSyncingTabs) return;
            _isSyncingTabs = true;
            if (EditorTabs.SelectedIndex >= 0 && EditorTabs.SelectedIndex < PreviewTabs.Items.Count)
                PreviewTabs.SelectedIndex = EditorTabs.SelectedIndex;
            _isSyncingTabs = false;
        }

        private void SyncPreviewTabs()
        {
            PreviewTabs.Items.Clear();
            for (var i = 0; i < EditorTabs.Items.Count; i++)
            {
                if (EditorTabs.Items[i] is TabItem editorTab && editorTab.Tag is Document doc)
                {
                    var idx = i;
                    var titleText = new TextBlock
                    {
                        Text = doc.Title,
                        VerticalAlignment = VerticalAlignment.Center,
                        TextTrimming = TextTrimming.CharacterEllipsis,
                        MaxWidth = double.PositiveInfinity
                    };

                    var closeBtn = new System.Windows.Controls.Button
                    {
                        Content = "×",
                        Width = 20,
                        Height = 20,
                        VerticalAlignment = VerticalAlignment.Center,
                        ToolTip = "关闭",
                        Focusable = false,
                        FontSize = 14,
                        FontWeight = FontWeights.Bold,
                        Foreground = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0x88, 0x88, 0x88)),
                        Background = System.Windows.Media.Brushes.Transparent,
                        BorderThickness = new Thickness(0),
                        Padding = new Thickness(0),
                        Cursor = System.Windows.Input.Cursors.Hand,
                        HorizontalAlignment = System.Windows.HorizontalAlignment.Right,
                        Margin = new Thickness(0)
                    };
                    var capture = idx;
                    closeBtn.MouseEnter += (_, _) =>
                    {
                        closeBtn.Background = new SolidColorBrush(System.Windows.Media.Color.FromArgb(0xE6, 0xFF, 0x00, 0x00));
                        closeBtn.Foreground = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0xFF, 0xFF, 0xFF));
                    };
                    closeBtn.MouseLeave += (_, _) =>
                    {
                        closeBtn.Background = System.Windows.Media.Brushes.Transparent;
                        closeBtn.Foreground = new SolidColorBrush(System.Windows.Media.Color.FromRgb(0x88, 0x88, 0x88));
                    };
                    closeBtn.Click += (_, _) =>
                    {
                        if (capture < EditorTabs.Items.Count)
                        {
                            var tab = EditorTabs.Items[capture] as TabItem;
                            if (tab != null) CloseSingleTab(tab);
                            RefreshEditorState();
                        }
                    };

                    DockPanel.SetDock(closeBtn, Dock.Right);
                    var panel = new DockPanel
                    {
                        LastChildFill = true,
                        Margin = new Thickness(5, 1, 0, 1)
                    };
                    panel.Children.Add(closeBtn);
                    panel.Children.Add(titleText);

                    var previewTab = new TabItem { Header = panel, ToolTip = doc.Title, ContextMenu = CreatePreviewTabContextMenu() };
                    previewTab.PreviewMouseRightButtonDown += PreviewTab_PreviewMouseRightButtonDown;
                    PreviewTabs.Items.Add(previewTab);
                }
            }
            SyncPreviewTabSelection();
        }
    }
}

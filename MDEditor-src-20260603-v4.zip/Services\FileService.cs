using System.IO;
using System.Text;
using MDEditor.Models;

namespace MDEditor.Services
{
    public static class FileService
    {
        /// <summary>自动检测编码打开文件（优先BOM，回退UTF-8）</summary>
        public static Document Open(string path)
        {
            var content = File.ReadAllText(path, DetectEncoding(path));
            return new Document
            {
                Path = path,
                Content = content,
                IsDirty = false
            };
        }

        public static void Save(string path, string content)
        {
            var dir = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                Directory.CreateDirectory(dir);
            File.WriteAllText(path, content, new UTF8Encoding(true));
        }

        public static void SaveAsText(string markdown, string path)
        {
            var text = MarkdownConverter.ToPlainText(markdown);
            File.WriteAllText(path, text, new UTF8Encoding(true));
        }

        public static void SaveAsHtml(string html, string path)
        {
            File.WriteAllText(path, html, new UTF8Encoding(true));
        }

        /// <summary>读取文件前4字节检测编码，有BOM用对应编码，无BOM回退UTF-8</summary>
        private static Encoding DetectEncoding(string path)
        {
            using var reader = new StreamReader(path, Encoding.UTF8, true);
            reader.Peek(); // 触发BOM检测
            return reader.CurrentEncoding;
        }
    }
}

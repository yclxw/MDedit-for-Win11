using System.Text.RegularExpressions;
using System.Windows.Controls;
using System.Windows.Input;

namespace MDEditor.Editor
{
    public partial class MarkdownEditor : System.Windows.Controls.UserControl
    {
        public MarkdownEditor()
        {
            InitializeComponent();
            EditorTextBox.TextChanged += EditorTextBox_TextChanged;
            // 将内部 TextBox 的 TextChanged 以自身为 sender 重新引发，
            // 确保外部订阅者收到的 sender 是 MarkdownEditor 而非 TextBox
            EditorTextBox.TextChanged += (_, e) => _textChanged?.Invoke(this, e);
            EditorTextBox.AddHandler(ScrollViewer.ScrollChangedEvent, new ScrollChangedEventHandler(EditorTextBox_ScrollChanged));
            LineNumberBorder.Visibility = System.Windows.Visibility.Collapsed;
        }

        public bool ShowLineNumbers
        {
            get => LineNumberBorder.Visibility == System.Windows.Visibility.Visible;
            set
            {
                LineNumberBorder.Visibility = value ? System.Windows.Visibility.Visible : System.Windows.Visibility.Collapsed;
                if (value)
                {
                    UpdateLineNumbers();
                }
            }
        }

        public string Text
        {
            get => EditorTextBox.Text;
            set => EditorTextBox.Text = value;
        }

        public int LineCount => EditorTextBox.LineCount;

        public int GetLineIndexFromCharacterIndex(int charIndex) =>
            EditorTextBox.GetLineIndexFromCharacterIndex(charIndex);

        public int GetCaretIndex() => EditorTextBox.CaretIndex;

        public void SetCaretIndex(int index) => EditorTextBox.CaretIndex = index;

        public string GetCurrentLineText()
        {
            var lineIndex = EditorTextBox.GetLineIndexFromCharacterIndex(EditorTextBox.CaretIndex);
            return lineIndex >= 0 && lineIndex < EditorTextBox.LineCount
                ? EditorTextBox.GetLineText(lineIndex)
                : string.Empty;
        }

        public string SelectedText => EditorTextBox.SelectedText;

        public bool CanUndo => EditorTextBox.CanUndo;

        public bool CanRedo => EditorTextBox.CanRedo;

        private event TextChangedEventHandler? _textChanged;

        public event TextChangedEventHandler TextChanged
        {
            add => _textChanged += value;
            remove => _textChanged -= value;
        }

        public void Undo() => EditorTextBox.Undo();

        public void Redo() => EditorTextBox.Redo();

        public void Cut() => EditorTextBox.Cut();

        public void Copy() => EditorTextBox.Copy();

        public void Paste() => EditorTextBox.Paste();

        public void SelectAll() => EditorTextBox.SelectAll();

        public void ReplaceSelectedText(string replacement)
        {
            var start = EditorTextBox.SelectionStart;
            EditorTextBox.SelectedText = replacement;
            EditorTextBox.SelectionStart = start + replacement.Length;
            EditorTextBox.Focus();
        }

        public bool FindNext(string searchText, bool matchCase, bool useRegex)
        {
            if (string.IsNullOrEmpty(searchText))
            {
                return false;
            }

            var comparison = matchCase ? StringComparison.Ordinal : StringComparison.OrdinalIgnoreCase;
            var text = EditorTextBox.Text;
            var startIndex = EditorTextBox.SelectionStart + EditorTextBox.SelectionLength;
            int foundIndex;

            if (useRegex)
            {
                try
                {
                    var options = matchCase ? RegexOptions.None : RegexOptions.IgnoreCase;
                    var regex = new Regex(searchText, options);
                    var match = regex.Match(text, startIndex);
                    if (match.Success)
                    {
                        foundIndex = match.Index;
                        var length = match.Length;
                        EditorTextBox.Select(foundIndex, length);
                        EditorTextBox.Focus();
                        return true;
                    }
                }
                catch
                {
                    return false;
                }
            }
            else
            {
                foundIndex = text.IndexOf(searchText, startIndex, comparison);
                if (foundIndex >= 0)
                {
                    EditorTextBox.Select(foundIndex, searchText.Length);
                    EditorTextBox.Focus();
                    return true;
                }
            }

            if (useRegex)
            {
                try
                {
                    var options = matchCase ? RegexOptions.None : RegexOptions.IgnoreCase;
                    var regex = new Regex(searchText, options);
                    var match = regex.Match(text);
                    if (match.Success)
                    {
                        EditorTextBox.Select(match.Index, match.Length);
                        EditorTextBox.Focus();
                        return true;
                    }
                }
                catch
                {
                    return false;
                }
            }
            else
            {
                foundIndex = text.IndexOf(searchText, comparison);
                if (foundIndex >= 0)
                {
                    EditorTextBox.Select(foundIndex, searchText.Length);
                    EditorTextBox.Focus();
                    return true;
                }
            }

            return false;
        }

        public int ReplaceAll(string searchText, string replaceText, bool matchCase, bool useRegex)
        {
            if (string.IsNullOrEmpty(searchText))
            {
                return 0;
            }

            var text = EditorTextBox.Text;

            if (useRegex)
            {
                try
                {
                    var options = matchCase ? RegexOptions.None : RegexOptions.IgnoreCase;
                    var regex = new Regex(searchText, options);
                    var result = regex.Replace(text, replaceText);
                    EditorTextBox.Text = result;
                    return regex.Matches(text).Count;
                }
                catch
                {
                    return 0;
                }
            }

            var comparison = matchCase ? StringComparison.Ordinal : StringComparison.OrdinalIgnoreCase;
            var count = 0;
            var currentIndex = 0;
            var buffer = new System.Text.StringBuilder();

            while (currentIndex < text.Length)
            {
                var index = text.IndexOf(searchText, currentIndex, comparison);
                if (index < 0)
                {
                    buffer.Append(text[currentIndex..]);
                    break;
                }

                buffer.Append(text[currentIndex..index]);
                buffer.Append(replaceText);
                currentIndex = index + searchText.Length;
                count++;
            }

            if (count > 0)
            {
                EditorTextBox.Text = buffer.ToString();
            }

            return count;
        }

        public void InsertTextAtCaret(string text)
        {
            EditorTextBox.SelectedText = text;
            EditorTextBox.CaretIndex += text.Length;
            EditorTextBox.Focus();
        }

        public void GoToLine(int lineIndex)
        {
            if (EditorTextBox.LineCount == 0)
                return;

            if (lineIndex < 0)
            {
                lineIndex = 0;
            }

            if (lineIndex >= EditorTextBox.LineCount)
            {
                lineIndex = EditorTextBox.LineCount - 1;
            }

            var offset = EditorTextBox.GetCharacterIndexFromLineIndex(lineIndex);
            EditorTextBox.CaretIndex = offset;
            EditorTextBox.ScrollToLine(lineIndex);
            EditorTextBox.Focus();
            if (ShowLineNumbers)
            {
                UpdateLineNumbers();
            }
        }

        private void EditorTextBox_TextChanged(object? sender, TextChangedEventArgs e)
        {
            if (ShowLineNumbers)
            {
                UpdateLineNumbers();
            }
        }

        private void EditorTextBox_ScrollChanged(object? sender, ScrollChangedEventArgs e)
        {
            if (ShowLineNumbers)
            {
                UpdateLineNumbers();
            }
        }

        private void UpdateLineNumbers()
        {
            if (!ShowLineNumbers)
            {
                return;
            }

            var first = EditorTextBox.GetFirstVisibleLineIndex();
            var last = EditorTextBox.GetLastVisibleLineIndex();
            if (first < 0 || last < 0)
            {
                LineNumbersTextBlock.Text = string.Empty;
                return;
            }

            var builder = new System.Text.StringBuilder();
            for (var i = first; i <= last; i++)
            {
                builder.AppendLine((i + 1).ToString());
            }

            LineNumbersTextBlock.Text = builder.ToString();
        }

        public void ZoomIn()
        {
            EditorTextBox.FontSize += 1;
            LineNumbersTextBlock.FontSize = EditorTextBox.FontSize;
        }

        public void ZoomOut()
        {
            if (EditorTextBox.FontSize > 8)
            {
                EditorTextBox.FontSize -= 1;
                LineNumbersTextBlock.FontSize = EditorTextBox.FontSize;
            }
        }

        public void ResetZoom()
        {
            EditorTextBox.FontSize = 14;
            LineNumbersTextBlock.FontSize = 14;
        }

        public void SetFontFamily(System.Windows.Media.FontFamily fontFamily)
        {
            EditorTextBox.FontFamily = fontFamily;
            LineNumbersTextBlock.FontFamily = fontFamily;
        }

        public void SetFontFamily(string fontName)
        {
            try
            {
                var ff = new System.Windows.Media.FontFamily(fontName);
                EditorTextBox.FontFamily = ff;
                LineNumbersTextBlock.FontFamily = ff;
            }
            catch { }
        }

        public void SetFontSize(double size)
        {
            if (size > 0 && size <= 200)
            {
                EditorTextBox.FontSize = size;
                LineNumbersTextBlock.FontSize = size;
            }
        }

        private void EditorTextBox_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key != Key.Tab) return;

            var lineIndex = EditorTextBox.GetLineIndexFromCharacterIndex(EditorTextBox.CaretIndex);
            var lineText = EditorTextBox.GetLineText(lineIndex);
            if (lineText.EndsWith("\r\n")) lineText = lineText[..^2];
            else if (lineText.EndsWith("\n") || lineText.EndsWith("\r")) lineText = lineText[..^1];

            if (e.KeyboardDevice.Modifiers == ModifierKeys.None)
            {
                // Tab: increase nesting for list items
                if (TryIndentListLine(lineIndex)) e.Handled = true;
            }
            else if (e.KeyboardDevice.Modifiers == ModifierKeys.Shift)
            {
                // Shift+Tab: decrease nesting
                if (TryOutdentListLine(lineIndex)) e.Handled = true;
            }
        }

        private bool TryIndentListLine(int lineIndex)
        {
            var line = GetLineText(lineIndex);
            var match = System.Text.RegularExpressions.Regex.Match(line, @"^(\s*)(\d+\.\s|[-*]\s\[?\s?\]?\s?)(.*)$");
            if (!match.Success) return false;

            var indent = match.Groups[1].Value;
            var marker = match.Groups[2].Value.TrimEnd();
            var rest = match.Groups[3].Value;

            // Determine sub-level marker (check task list BEFORE generic dash)
            string newMarker;
            if (marker == "- [ ] " || marker == "- [x] ")
                newMarker = "  - [ ] ";
            else if (marker.StartsWith("-") || marker.StartsWith("*"))
                newMarker = "  * ";
            else
                newMarker = "1. ";

            var start = EditorTextBox.GetCharacterIndexFromLineIndex(lineIndex);
            var len = line.Length;
            EditorTextBox.Select(start, len);
            EditorTextBox.SelectedText = indent + "    " + newMarker + rest;
            return true;
        }

        private bool TryOutdentListLine(int lineIndex)
        {
            var line = GetLineText(lineIndex);
            if (!line.StartsWith("    ") && !line.StartsWith("\t")) return false;

            var match = System.Text.RegularExpressions.Regex.Match(line, @"^(\s{4}|\t)(\s*)(\d+\.\s|[-*]\s\[?\s?\]?\s?)(.*)$");
            if (!match.Success) return false;

            var innerIndent = match.Groups[2].Value;
            var marker = match.Groups[3].Value.TrimEnd();
            var rest = match.Groups[4].Value;

            var start = EditorTextBox.GetCharacterIndexFromLineIndex(lineIndex);
            var len = line.Length;
            EditorTextBox.Select(start, len);
            EditorTextBox.SelectedText = innerIndent + marker.TrimEnd() + " " + rest;
            return true;
        }

        private string GetLineText(int lineIndex)
        {
            var line = EditorTextBox.GetLineText(lineIndex);
            if (line.EndsWith("\r\n")) return line[..^2];
            if (line.EndsWith("\n") || line.EndsWith("\r")) return line[..^1];
            return line;
        }
    }
}

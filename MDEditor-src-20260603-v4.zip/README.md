﻿<h1 align="center">MD编辑器 for Win11</h1>

<p align="center">
  <strong>Windows 11 原生 Markdown 所见即所得编辑器</strong>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/版本-v3.7-0969DA?style=flat-square" alt="版本" />
  <img src="https://img.shields.io/badge/平台-Windows%2011-0078D4?style=flat-square&logo=windows" alt="平台" />
  <img src="https://img.shields.io/badge/框架-.NET%2010-512BD4?style=flat-square&logo=dotnet" alt="框架" />
  <img src="https://img.shields.io/badge/语言-C%23%2012-239120?style=flat-square&logo=csharp" alt="语言" />
  <img src="https://img.shields.io/badge/许可-Proprietary-red?style=flat-square" alt="许可" />
  <img src="https://img.shields.io/badge/架构-x64-blue?style=flat-square" alt="架构" />
</p>

<p align="center">
  <a href="#-特性">✨ 特性</a> ·
  <a href="#-快速开始">🚀 快速开始</a> ·
  <a href="#-系统需求">💻 系统需求</a> ·
  <a href="#-技术栈">🛠 技术栈</a> ·
  <a href="#-文档">📚 文档</a> ·
  <a href="#-项目结构">📁 项目结构</a> ·
  <a href="#-快捷键">⌨️ 快捷键</a> ·
  <a href="#-开发">🔧 开发</a>
</p>

---

## 📖 简介

**MD编辑器 for Win11** 是一款面向 Windows 11 的原生 Markdown 桌面编辑器，采用 **WPF** 框架和 **WebView2 Chromium** 预览引擎构建。它像浏览器一样管理你的文档——关闭窗口无需担心丢失任何内容，下次打开一切如初。

### 设计哲学

> **零摩擦恢复**：关闭窗口静默缓存全部标签页，下次启动完整恢复工作上下文。仅在用户**主动**关闭单个标签页时才询问是否保存。

---

## ✨ 特性

### 核心体验

| 特性 | 说明 |
|------|------|
| 🔄 **浏览器式会话恢复** | 关闭窗口自动缓存全部标签页（含修改未保存），下次启动完整恢复，连光标位置都不丢失 |
| 📝 **多标签页编辑** | 无限标签页，拖放文件即打开，支持关闭/关闭其他/关闭全部 |
| 👁️ **Chromium 实时预览** | WebView2 引擎 + GitHub Primer CSS，保存后即时刷新，内容未变则跳过渲染 |
| 🎨 **GitHub Primer 主题** | 亮/暗双主题即时切换，12 个设计 Token 统一管理，WCAG AA 对比度合规 |

### 编辑体验

| 特性 | 说明 |
|------|------|
| 🏷️ **7 种视图布局** | 完整视图 · 仅预览 · 仅源码 · 双栏左右 · 双栏上下 · 标准视图 · 个性视图 |
| 🧰 **32 按钮工具栏** | 48×48 ICO 四色变体图标，自动适配亮/暗主题，6 组功能分区 |
| ⌨️ **40+ 快捷键** | Ctrl+方向键 标题升降/行移动，支持全部格式操作的键盘快捷方式 |
| 📋 **三格式剪贴板** | 复制同时包含 Markdown 源码 + HTML 渲染结果 + 纯文本，粘贴到 Word/浏览器保留格式 |

### 文件与工具

| 特性 | 说明 |
|------|------|
| 🌲 **文件树导航** | 显示当前文件夹的 .md/.txt 目录结构，点击即打开 |
| 📑 **大纲导航** | 自动解析标题生成文档大纲，点击跳转到对应位置 |
| 📂 **最近文件** | 记录最近 20 个打开文件，支持去重和文件存在性过滤 |
| 🔍 **查找替换** | 非模态窗口，支持正则表达式、大小写匹配、全部替换 |
| 🔢 **标题重编号** | 自动为标题添加/移除数字序号（`1.` / `1.1.` / `2.3.1.`） |
| 💾 **多格式导出** | 保存为 .md / 导出纯文本 .txt / 导出 .html / 批量全部输出 |
| 🖨️ **打印支持** | WebView2 内置 `window.print()` 调用系统打印对话框 |

### 工程品质

| 特性 | 说明 |
|------|------|
| 🛡️ **安全加固** | 命名管道 ACL 访问控制、Mutex 单实例、JSON MaxDepth 防护 |
| 📦 **便携单文件** | 自包含发布（186 MB），无需安装 .NET 运行时，数据在 exe 同级 `Data/` 目录 |
| 🌐 **编码兼容** | BOM 自动检测（UTF-8/UTF-16/UTF-32），输出统一 UTF-8 BOM |
| ⚡ **大文件优化** | 500KB 以上文件异步加载，UI 线程零阻塞 |
| 💥 **三级异常保护** | Dispatcher / AppDomain / TaskScheduler 异常统一捕获，写入崩溃日志 |

---

## 🚀 快速开始

### 直接运行（推荐）

下载最新发布版本，双击运行。**无需安装任何运行时**。

```powershell
# 下载并运行
.\bak\publish\MD编辑器v3.7.20260603.exe
```

### 从源码构建

<details>
<summary>点击展开构建步骤</summary>

#### 前置条件

- [.NET 10 SDK](https://dotnet.microsoft.com/download/dotnet/10.0) (10.0.300+)
- Windows 10 1809+ 或 Windows 11
- Git（可选）

#### 安装 .NET SDK

```powershell
# 使用 winget 安装
winget install --id Microsoft.DotNet.SDK.10 -e

# 验证安装
dotnet --version
# 预期输出：10.0.300 或更高
```

#### 克隆项目

```bash
git clone <repo-url>
cd "MD编辑器 for Win11"
```

#### 构建与运行

```bash
# 还原依赖
dotnet restore

# 编译（Debug）
dotnet build

# 编译（Release）
dotnet build -c Release

# 直接运行
dotnet run
```

#### 发布自包含 exe

```bash
dotnet publish -c Release -r win-x64 \
  --self-contained true \
  -p:PublishSingleFile=true \
  -p:PublishReadyToRun=true \
  -p:IncludeNativeLibrariesForSelfExtract=true \
  -o ./bak/publish
```

产物：`bak/publish/MD编辑器v3.7.20260603.exe`（约 186 MB，自包含单文件）

</details>

### 首次使用

```
1. 双击运行 MD编辑器v3.7.20260603.exe
2. 自动创建 Data\ 目录（settings.json + session.json）
3. Ctrl+O 打开文件，或拖放 .md 文件到窗口
4. Ctrl+S 保存，预览区即时刷新
5. Ctrl+1~7 切换视图布局
6. Ctrl+Shift+D 切换亮/暗主题
```

---

## 💻 系统需求

| 需求项 | 最低配置 | 推荐配置 |
|--------|----------|----------|
| **操作系统** | Windows 10 1809+ (Build 17763) | Windows 11 24H2 |
| **CPU 架构** | x64 | x64 |
| **内存** | 512 MB | 4 GB+ |
| **磁盘空间** | 200 MB | 500 MB |
| **显示器** | 1024×768 | 1920×1080+ |
| **.NET 运行时** | 无需安装（自包含） | — |
| **WebView2** | 自动内嵌 | 系统预装更佳 |

---

## 🛠 技术栈

| 层级 | 技术 | 版本 | 许可 | 说明 |
|------|------|------|------|------|
| **运行时** | .NET | 10.0 | MIT | ReadyToRun 预编译，单文件发布 |
| **UI 框架** | WPF | .NET 10 | MIT | XAML + DynamicResource 热切换主题 |
| **Web 引擎** | WebView2 | 1.0.3124.44 | Proprietary | Chromium 内核预览 |
| **Markdown** | Markdig | 0.34.0 | BSD-2-Clause | 高性能解析器，20+ 扩展支持 |
| **HTML** | HtmlAgilityPack | 1.11.60 | MIT | HTML 解析与纯文本提取 |
| **JSON** | System.Text.Json | 内置 | MIT | 零依赖高性能序列化 |
| **语言** | C# | 12 | — | Nullable + ImplicitUsings 启用 |
| **架构** | Code-Behind | — | — | 约 4,500 行代码 |

### 架构图

```
┌─────────────────────────────────────────┐
│         Presentation (Code-Behind)       │
│  MainWindow.xaml.cs    ~2,900 行         │
│  MarkdownEditor        ~413 行           │
├─────────────────────────────────────────┤
│           Service Layer (5 类)           │
│  FileService / FileManager               │
│  MarkdownConverter / SettingsService     │
│  ClipboardService                        │
├─────────────────────────────────────────┤
│           Model Layer (3 类)             │
│  Document / SessionDocument / ViewLayout │
├─────────────────────────────────────────┤
│       Infrastructure (.NET 10)           │
│  WPF + WebView2 + Markdig + HtmlAP      │
└─────────────────────────────────────────┘
```

---

## 📚 文档

完整的项目文档位于 [`docs/`](docs/) 目录：

| 序号 | 文档 | 说明 |
|------|------|------|
| 01 | [系统说明](docs/01%20系统说明.md) | 系统架构、核心设计原则、子系统说明、开发环境、大模型信息 |
| 02 | [版本说明](docs/02%20版本说明.md) | 版本号规则、完整版本历史、兼容性矩阵、路线图 |
| 03 | [业务说明](docs/03%20业务说明.md) | 产品设计哲学、核心业务逻辑、会话生命周期、个性化设计（4 项） |
| 04 | [技术说明](docs/04%20技术说明.md) | 技术栈详解、架构决策记录、服务层 API、关键子系统实现 |
| 05 | [UI 说明](docs/05%20UI说明.md) | 设计理念、配色方案、布局规范、工具栏/菜单/预览区详细设计 |
| 06 | [备份说明](docs/06%20备份说明.md) | 备份规范、目录结构、操作流程、环境恢复、完整性验证 |
| 07 | [开发日志](docs/07%20开发日志.md) | v3.0~v3.7 完整 CHANGELOG、40+ 项修复记录、审查历史 |

---

## 📁 项目结构

```
MD编辑器 for Win11/
│
├── App.xaml(.cs)                 # 应用程序入口（单实例管控、IPC、异常处理）
├── MainWindow.xaml(.cs)          # 主窗口（~2,900 行核心逻辑）
├── FindReplaceWindow.xaml(.cs)   # 查找/替换非模态窗口
├── MDEditor.csproj               # .NET 10 项目文件
│
├── Editor/                       # 编辑器子系统
│   └── MarkdownEditor.xaml(.cs)  #   可复用编辑器控件（TextBox + 行号栏）
│
├── Models/                       # 数据模型层
│   ├── Document.cs               #   文档模型
│   ├── SessionDocument.cs        #   会话文档模型
│   └── ViewLayout.cs             #   视图布局模型（7 种预设）
│
├── Services/                     # 服务层（静态工具类）
│   ├── FileService.cs            #   文件 I/O（BOM 编码检测）
│   ├── FileManager.cs            #   文件管理（大文件异步、会话、最近文件）
│   ├── MarkdownConverter.cs      #   Markdown → HTML/纯文本（Markdig 管线）
│   ├── SettingsService.cs        #   设置持久化（JSON 原子读写、线程安全）
│   └── ClipboardService.cs       #   剪贴板操作（三格式：MD/Text/HTML）
│
├── Views/                        # 对话框
│   ├── CustomViewDialog.cs       #   自定义布局比例对话框
│   └── GoToLineDialog.cs         #   跳转到行对话框
│
├── Resources/                    # 图标资源（140 个 ICO，4 色 × 35 功能）
├── Att/                          # 应用图标
├── docs/                         # 项目文档（01~07）
├── bak/                          # 备份归档（源码/发布/图标源文件）
│   ├── source/                   #   源码 ZIP 归档
│   ├── publish/                  #   发布版 exe
│   └── pack/                     #   图标源文件（SVG + 多尺寸 ICO）
│
└── .claude/                      # AI 辅助开发配置
```

---

## ⌨️ 快捷键

### 文件操作

| 快捷键 | 功能 |
|--------|------|
| `Ctrl+N` | 新建文档 |
| `Ctrl+O` | 打开文件 |
| `Ctrl+S` | 保存 |
| `Ctrl+Shift+S` | 另存为 .md |
| `Ctrl+P` | 打印 |
| `Ctrl+W` | 关闭当前标签页 |

### 编辑

| 快捷键 | 功能 |
|--------|------|
| `Ctrl+Z` / `Ctrl+Y` | 撤销 / 重做 |
| `Ctrl+X` / `Ctrl+C` / `Ctrl+V` | 剪切 / 复制 / 粘贴 |
| `Ctrl+Shift+C` | 复制为纯文本 |
| `Ctrl+Shift+V` | 粘贴纯文本 |
| `Ctrl+F` | 查找替换 |
| `F3` | 查找下一个 |
| `Ctrl+G` | 跳转到行 |

### 视图

| 快捷键 | 功能 |
|--------|------|
| `Ctrl+1` | 完整视图（三栏） |
| `Ctrl+2` | 仅预览 |
| `Ctrl+3` | 仅源码 |
| `Ctrl+4` | 双栏（左右） |
| `Ctrl+5` | 双栏（上下） |
| `Ctrl+6` | 标准视图 |
| `Ctrl+7` | 个性视图 |
| `Ctrl+Shift+B` | 显示/隐藏侧边栏 |
| `Ctrl+Shift+G` | 显示/隐藏行号 |
| `Ctrl+Shift+D` | 切换亮/暗主题 |
| `F11` | 全屏 |

### 格式

| 快捷键 | 功能 |
|--------|------|
| `Ctrl+B` | 粗体 |
| `Ctrl+I` | 斜体 |
| `Ctrl+Shift+X` | 删除线 |
| `` Ctrl+` `` | 行内代码 |
| `` Ctrl+Shift+` `` | 代码块 |
| `Ctrl+Shift+Q` | 引用块 |
| `Ctrl+Shift+U` | 无序列表 |
| `Ctrl+Shift+N` | 有序列表 |
| `Ctrl+Shift+T` | 任务列表 |
| `Ctrl+Shift+K` | 插入链接 |
| `Ctrl+Shift+I` | 插入图片 |
| `Ctrl+Shift+1~6` | 设置标题 H1~H6 |

### 移动

| 快捷键 | 功能 |
|--------|------|
| `Ctrl+←` | 标题升级（减少 `#`） |
| `Ctrl+→` | 标题降级（增加 `#`） |
| `Ctrl+↑` | 当前行上移 |
| `Ctrl+↓` | 当前行下移 |

### 缩放

| 快捷键 | 功能 |
|--------|------|
| `Ctrl+加号` | 放大字体 |
| `Ctrl+减号` | 缩小字体 |
| `Ctrl+0` | 重置缩放 |

---

## 🔧 开发

### 开发环境

| 工具 | 版本/规格 | 用途 |
|------|-----------|------|
| Visual Studio Code | 最新稳定版 | 代码编辑与调试 |
| .NET SDK | 10.0.300+ | 编译构建 |
| Git | 最新稳定版 | 版本控制 |
| Claude Code | CLI v2.4.x | AI 辅助开发 |
| PowerShell | 7.4+ | 脚本自动化 |

### 开发大模型

本项目在开发过程中使用以下大模型辅助：

| 模型 | 厂商 | 上下文 | 主要用途 |
|------|------|--------|----------|
| **Claude Opus 4.8** | Anthropic | 200K | 架构设计、代码审查、安全审计 |
| **DeepSeek V4 Pro** | DeepSeek | 1M | 代码生成、功能实现、大规模重构 |
| **Claude Sonnet 4.6** | Anthropic | 200K | 文档编写、需求分析 |
| **Claude Haiku 4.5** | Anthropic | 200K | 快速补全、简单修复 |

### 常用命令

```bash
# 编译
dotnet build -c Release

# 发布自包含 exe
dotnet publish -c Release -r win-x64 \
  --self-contained true \
  -p:PublishSingleFile=true \
  -p:PublishReadyToRun=true \
  -p:IncludeNativeLibrariesForSelfExtract=true \
  -o ./bak/publish

# 源码归档（PowerShell）
Compress-Archive -Path @(
    'App.xaml','App.xaml.cs','MainWindow.xaml','MainWindow.xaml.cs',
    'FindReplaceWindow.xaml','FindReplaceWindow.xaml.cs',
    'MDEditor.csproj','README.md','Editor','Models','Services','Views',
    'Resources','Att','docs'
) -DestinationPath "bak\source\MDEditor-src-$(Get-Date -f yyyyMMdd)-v3.zip" -Force
```

### 提交规范

遵循 [Conventional Commits](https://www.conventionalcommits.org/zh-hans/)：

| 前缀 | 说明 |
|------|------|
| `feat:` | 新功能 |
| `fix:` | Bug 修复 |
| `refactor:` | 代码重构 |
| `style:` | UI / 样式变更 |
| `docs:` | 文档更新 |
| `chore:` | 构建 / 工具变更 |
| `security:` | 安全修复 |

---

## 📊 项目统计

| 指标 | 值 |
|------|-----|
| 总代码行数 | ~4,500 行（含 XAML） |
| C# 源文件 | 12 个 |
| XAML 文件 | 4 个 |
| 服务类 | 5 个 |
| 数据模型 | 3 个 |
| 快捷键 | 40+ 组 |
| 工具栏按钮 | 32 个（6 组） |
| 菜单项 | ~60 个 |
| 图标资源 | 140 个 ICO |
| 已修复缺陷 | 36+ 项 |
| 代码审查轮次 | 5 轮 |
| 发布版本 | 7 个（v3.0 ~ v3.7） |

---

## 版本

**当前版本**：`v3.7`  
**发布日期**：2026-06-03  
**版本规则**：`v{主版本}.{修改次数}.{日期}`（如 `v3.7.20260603`）

完整版本历史和兼容性说明请参阅 [版本说明](docs/02%20版本说明.md)。

---

## 👤 作者

**帅气的锅巴**

---

## 📄 许可

本项目为专有软件（Proprietary）。保留所有权利。

---

<p align="center">
  <sub>Built with ❤️ using .NET 10 + WPF + WebView2</sub>
</p>

namespace MDEditor.Models
{
    public enum PanelState { Visible, Collapsed }

    public readonly record struct ViewLayout(
        PanelState Sidebar,
        PanelState Editor,
        PanelState Preview,
        double EditorRatio,
        double PreviewRatio,
        bool IsVerticalSplit,
        string Label,
        double SidebarRatio = 0
    )
    {
        public static readonly ViewLayout SourceOnly = new(
            PanelState.Collapsed, PanelState.Visible, PanelState.Collapsed,
            1, 0, false, "仅源码");

        public static readonly ViewLayout PreviewOnly = new(
            PanelState.Collapsed, PanelState.Collapsed, PanelState.Visible,
            0, 1, false, "仅预览");

        public static readonly ViewLayout SplitVertical = new(
            PanelState.Collapsed, PanelState.Visible, PanelState.Visible,
            1, 1, true, "双栏（左右）");

        public static readonly ViewLayout SplitHorizontal = new(
            PanelState.Collapsed, PanelState.Visible, PanelState.Visible,
            1, 1, false, "双栏（上下）");

        public static readonly ViewLayout FullView = new(
            PanelState.Visible, PanelState.Visible, PanelState.Visible,
            1, 1, true, "完整视图");

        public static readonly ViewLayout StandardView = new(
            PanelState.Collapsed, PanelState.Visible, PanelState.Visible,
            1, 2, true, "标准视图");

        public static ViewLayout CustomView(int sidebar, int editor, int preview)
        {
            if (sidebar < 0 || editor < 0 || preview < 0 || sidebar + editor + preview != 100)
                return FullView;

            return new ViewLayout(
                sidebar > 0 ? PanelState.Visible : PanelState.Collapsed,
                editor > 0 ? PanelState.Visible : PanelState.Collapsed,
                preview > 0 ? PanelState.Visible : PanelState.Collapsed,
                Math.Max(editor, 1), Math.Max(preview, 1), true,
                $"个性视图（侧边栏{sidebar}% / 编辑{editor}% / 预览{preview}%）",
                sidebar);
        }
    }
}

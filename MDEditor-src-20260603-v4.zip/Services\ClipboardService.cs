using Clipboard = System.Windows.Clipboard;
using DataFormats = System.Windows.DataFormats;
using DataObject = System.Windows.DataObject;
using System.Windows;
using TextDataFormat = System.Windows.TextDataFormat;

namespace MDEditor.Services
{
    public static class ClipboardService
    {
        /// <summary>复制 Markdown 到剪贴板，同时包含纯文本和 HTML 格式</summary>
        public static void CopyMarkdown(string markdown)
        {
            if (string.IsNullOrEmpty(markdown))
                return;

            try
            {
                var html = MarkdownConverter.ToHtml(markdown, false);
                var data = new DataObject();
                data.SetData(DataFormats.Text, markdown);       // 纯 Markdown 源文本
                data.SetData(DataFormats.Html, HtmlFragment(html)); // HTML 渲染结果
                Clipboard.SetDataObject(data, true);
            }
            catch (System.Runtime.InteropServices.ExternalException) { /* 剪贴板被占用 */ }
        }

        /// <summary>复制为纯文本（去除 Markdown 标记）</summary>
        public static void CopyPlainText(string markdown)
        {
            if (string.IsNullOrEmpty(markdown))
                return;

            try
            {
                var plain = MarkdownConverter.ToPlainText(markdown);
                Clipboard.SetText(plain, TextDataFormat.Text);
            }
            catch (System.Runtime.InteropServices.ExternalException) { /* 剪贴板被占用 */ }
        }

        /// <summary>复制为 HTML</summary>
        public static void CopyHtml(string markdown)
        {
            if (string.IsNullOrEmpty(markdown))
                return;

            try
            {
                var html = MarkdownConverter.ToHtml(markdown, false);
                var data = new DataObject();
                data.SetData(DataFormats.Html, HtmlFragment(html));
                Clipboard.SetDataObject(data, true);
            }
            catch (System.Runtime.InteropServices.ExternalException) { /* 剪贴板被占用 */ }
        }

        /// <summary>将完整 HTML 转换为剪贴板 HTML 片段格式</summary>
        private static string HtmlFragment(string html)
        {
            // Windows 剪贴板需要 HTML Format 格式的头部信息
            // 参考: https://docs.microsoft.com/en-us/windows/win32/dataxchg/html-clipboard-format
            const string header = @"Version:0.9
StartHTML:00000000
EndHTML:00000000
StartFragment:00000000
EndFragment:00000000
";
            // 提取 body 内容
            var bodyStart = html.IndexOf("<body>", StringComparison.OrdinalIgnoreCase);
            var bodyEnd = html.IndexOf("</body>", StringComparison.OrdinalIgnoreCase);
            string fragment;
            int bodyStartOffset, bodyEndOffset;

            if (bodyStart >= 0 && bodyEnd > bodyStart)
            {
                fragment = html[(bodyStart + 6)..bodyEnd];
                bodyStartOffset = header.Length + 6; // after <body> in the final output
                bodyEndOffset = bodyStartOffset + fragment.Length;
            }
            else
            {
                fragment = html;
                bodyStartOffset = header.Length;
                bodyEndOffset = bodyStartOffset + fragment.Length;
            }

            // 填充准确的偏移量
            var result = header
                .Replace("StartHTML:00000000", $"StartHTML:{header.Length:D8}")
                .Replace("EndHTML:00000000", $"EndHTML:{(header.Length + fragment.Length):D8}")
                .Replace("StartFragment:00000000", $"StartFragment:{bodyStartOffset:D8}")
                .Replace("EndFragment:00000000", $"EndFragment:{bodyEndOffset:D8}");

            return result + fragment;
        }
    }
}

using System.IO;
using System.IO.Pipes;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Windows;
using System.Windows.Threading;

namespace MDEditor
{
    public partial class App : System.Windows.Application
    {
        private const string AppMutexName = "MDEditor_SingleInstance_v2";
        private const string PipeName = "MDEditor_Pipe_v2";
        private static Mutex? _mutex;
        private static MainWindow? _mainWindow;
        private static CancellationTokenSource? _pipeCts;

        protected override void OnStartup(StartupEventArgs e)
        {
            // Global exception handlers — 便携版本：日志写入 exe 所在目录
            var crashLogPath = Path.Combine(
                Path.GetDirectoryName(Environment.ProcessPath) ?? ".", "MDEditor_crash.log");
            DispatcherUnhandledException += (_, args) =>
            {
                try { File.AppendAllText(crashLogPath, $"[{DateTime.Now}] UI: {args.Exception}\n"); }
                catch { }
                args.Handled = true;
            };
            AppDomain.CurrentDomain.UnhandledException += (_, args) =>
            {
                try { File.AppendAllText(crashLogPath, $"[{DateTime.Now}] BG: {args.ExceptionObject}\n"); }
                catch { }
            };
            TaskScheduler.UnobservedTaskException += (_, args) =>
            {
                try { File.AppendAllText(crashLogPath, $"[{DateTime.Now}] Task: {args.Exception}\n"); }
                catch { }
                args.SetObserved();
            };

            bool createdNew;
            // 使用 initiallyOwned:false，构造函数不会抛出 AbandonedMutexException
            _mutex = new Mutex(false, AppMutexName, out createdNew);

            if (createdNew)
            {
                // 获取所有权（处理之前实例崩溃遗留的 Abandoned 状态）
                try { _mutex.WaitOne(); } catch (AbandonedMutexException) { }
            }
            else
            {
                foreach (var arg in e.Args)
                {
                    if (File.Exists(arg))
                        SendToExistingInstance(Path.GetFullPath(arg));
                }
                _mutex!.Dispose();
                Environment.Exit(0);
                return;
            }

            base.OnStartup(e);

            _mainWindow = new MainWindow();
            _mainWindow.Closed += (_, _) =>
            {
                _pipeCts?.Cancel();
                _mutex?.ReleaseMutex();
                _mutex?.Dispose();
            };

            _pipeCts = new CancellationTokenSource();
            _ = StartPipeServer(_pipeCts.Token);
            _mainWindow.Show();
        }

        private static void SendToExistingInstance(string filePath)
        {
            try
            {
                using var client = new NamedPipeClientStream(".", PipeName, PipeDirection.Out);
                client.Connect(2000);
                using var writer = new StreamWriter(client);
                writer.WriteLine(filePath);
                writer.Flush();
            }
            catch
            {
                // Pipe not available — existing instance may still be starting
            }
        }

        private static async Task StartPipeServer(CancellationToken ct)
        {
            try
            {
                // 创建管道安全描述符：仅当前用户和 SYSTEM 可访问
                var pipeSecurity = new PipeSecurity();
                var currentUser = WindowsIdentity.GetCurrent().User;
                if (currentUser != null)
                {
                    pipeSecurity.AddAccessRule(new PipeAccessRule(
                        currentUser,
                        PipeAccessRights.ReadWrite,
                        AccessControlType.Allow));
                    pipeSecurity.AddAccessRule(new PipeAccessRule(
                        new SecurityIdentifier(WellKnownSidType.LocalSystemSid, null),
                        PipeAccessRights.ReadWrite,
                        AccessControlType.Allow));
                }

                while (!ct.IsCancellationRequested)
                {
                    try
                    {
                        using var server = NamedPipeServerStreamAcl.Create(
                            PipeName, PipeDirection.In, 1,
                            PipeTransmissionMode.Byte, PipeOptions.Asynchronous,
                            1024, 1024, pipeSecurity);
                        await server.WaitForConnectionAsync(ct);
                        using var reader = new StreamReader(server);
                        var filePath = await reader.ReadLineAsync(ct);
                        if (!string.IsNullOrEmpty(filePath) && _mainWindow != null)
                        {
                            _ = _mainWindow.Dispatcher.BeginInvoke(new Action(() =>
                            {
                                try
                                {
                                    _mainWindow.OpenDocumentFromExternal(filePath);
                                }
                                catch { }
                            }));
                        }
                    }
                    catch (OperationCanceledException)
                    {
                        break;
                    }
                    catch
                    {
                        // Pipe broken — restart listener
                    }
                }
            }
            catch
            {
                // Server stopped
            }
        }
    }
}

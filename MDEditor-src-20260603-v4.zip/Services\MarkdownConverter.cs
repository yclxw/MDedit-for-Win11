using System;
using System.Linq;
using System.Text;
using HtmlAgilityPack;
using HtmlDocument = HtmlAgilityPack.HtmlDocument;
using Markdig;

namespace MDEditor.Services
{
    public static class MarkdownConverter
    {
        private static readonly MarkdownPipeline Pipeline = new MarkdownPipelineBuilder()
            .UseAdvancedExtensions()
            .UsePipeTables()
            .UseTaskLists()
            .UseAutoLinks()
            .UseMathematics()
            .Build();

        // GitHub Primer 风格 CSS
        private static readonly string LightCss = @"body {
  font-family: -apple-system, BlinkMacSystemFont, ""Segoe UI"", Noto Sans, Helvetica, Arial, sans-serif;
  margin: 0; padding: 32px;
  color: #1F2328; background: #ffffff;
  line-height: 1.6; font-size: 14px; max-width: 1012px;
}
h1, h2 { border-bottom: 1px solid #d0d7de; font-weight: 600; }
h1 { padding-bottom: 8px; font-size: 2em; }
h2 { padding-bottom: 6px; font-size: 1.5em; }
h3 { font-weight: 600; font-size: 1.25em; }
h4 { font-weight: 600; font-size: 1em; }
h5 { font-weight: 600; font-size: 0.875em; }
h6 { font-weight: 600; font-size: 0.85em; color: #656d76; }
pre {
  font-family: ""Consolas"", ""Courier New"", monospace;
  background: #f6f8fa; border: 1px solid #d0d7de;
  border-radius: 6px; padding: 16px; overflow: auto; line-height: 1.45;
}
code {
  font-family: ""Consolas"", ""Courier New"", monospace;
  background: rgba(175,184,193,0.2); border-radius: 6px;
  padding: 2px 6px; font-size: 85%;
}
pre code { background: transparent; border: none; padding: 0; }
blockquote {
  border-left: 4px solid #d0d7de; margin: 0;
  padding: 0 16px; color: #656d76;
}
table { border-collapse: collapse; width: 100%; margin: 8px 0; }
th, td { border: 1px solid #d0d7de; padding: 6px 13px; }
th { font-weight: 600; background: #f6f8fa; }
img { max-width: 100%; }
a { color: #0969da; text-decoration: none; }
a:hover { text-decoration: underline; }
hr { height: 1px; background: #d0d7de; border: none; }
ul, ol { padding-left: 2em; }
li + li { margin-top: 4px; }
";

        private static readonly string DarkCss = @"body {
  font-family: -apple-system, BlinkMacSystemFont, ""Segoe UI"", Noto Sans, Helvetica, Arial, sans-serif;
  margin: 0; padding: 32px;
  color: #e6edf3; background: #0d1117;
  line-height: 1.6; font-size: 14px; max-width: 1012px;
}
h1, h2 { border-bottom: 1px solid #30363d; font-weight: 600; }
h1 { padding-bottom: 8px; font-size: 2em; }
h2 { padding-bottom: 6px; font-size: 1.5em; }
h3 { font-weight: 600; font-size: 1.25em; }
h4 { font-weight: 600; font-size: 1em; }
h5 { font-weight: 600; font-size: 0.875em; }
h6 { font-weight: 600; font-size: 0.85em; color: #7d8590; }
pre {
  font-family: ""Consolas"", ""Courier New"", monospace;
  background: #161b22; border: 1px solid #30363d;
  border-radius: 6px; padding: 16px; overflow: auto; line-height: 1.45;
}
code {
  font-family: ""Consolas"", ""Courier New"", monospace;
  background: rgba(240,246,252,0.15); border-radius: 6px;
  padding: 2px 6px; font-size: 85%;
}
pre code { background: transparent; border: none; padding: 0; }
blockquote {
  border-left: 4px solid #30363d; margin: 0;
  padding: 0 16px; color: #7d8590;
}
table { border-collapse: collapse; width: 100%; margin: 8px 0; }
th, td { border: 1px solid #30363d; padding: 6px 13px; }
th { font-weight: 600; background: #161b22; }
img { max-width: 100%; }
a { color: #2f81f7; text-decoration: none; }
a:hover { text-decoration: underline; }
hr { height: 1px; background: #30363d; border: none; }
ul, ol { padding-left: 2em; }
li + li { margin-top: 4px; }
";

        public static string ToHtml(string markdown, bool isDarkTheme)
        {
            var body = Markdown.ToHtml(markdown ?? string.Empty, Pipeline);
            return WrapHtml(body, isDarkTheme);
        }

        public static string ToPlainText(string markdown)
        {
            var html = Markdown.ToHtml(markdown ?? string.Empty, Pipeline);
            return HtmlToPlainText(html);
        }

        private static string WrapHtml(string body, bool isDarkTheme)
        {
            var css = isDarkTheme ? DarkCss : LightCss;
            return $"<!DOCTYPE html><html><head><meta charset=\"utf-8\"><style>{css}</style></head><body>{body}</body></html>";
        }

        private static string HtmlToPlainText(string html)
        {
            var document = new HtmlDocument();
            document.LoadHtml(html);
            var builder = new StringBuilder();
            ExtractText(document.DocumentNode, builder);
            return NormalizeWhitespace(builder.ToString());
        }

        private static void ExtractText(HtmlNode node, StringBuilder builder)
        {
            if (node.NodeType == HtmlNodeType.Text)
            {
                var text = HtmlEntity.DeEntitize(node.InnerText);
                if (!string.IsNullOrWhiteSpace(text))
                {
                    builder.Append(text);
                }
            }
            else if (node.Name == "li")
            {
                builder.Append("- ");
                foreach (var child in node.ChildNodes)
                {
                    ExtractText(child, builder);
                }
                builder.AppendLine();
            }
            else if (node.Name is "h1" or "h2" or "h3" or "h4" or "h5" or "h6"
                      or "br" or "p" or "div")
            {
                foreach (var child in node.ChildNodes)
                {
                    ExtractText(child, builder);
                }
                builder.AppendLine();
            }
            else
            {
                foreach (var child in node.ChildNodes)
                {
                    ExtractText(child, builder);
                }
            }
        }

        private static string NormalizeWhitespace(string text)
        {
            var lines = text.Split(new[] { '\r', '\n' }, StringSplitOptions.None)
                .Select(line => line.Trim());
            return string.Join(Environment.NewLine, lines);
        }
    }
}

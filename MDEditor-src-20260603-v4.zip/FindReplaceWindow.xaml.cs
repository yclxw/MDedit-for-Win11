using System;
using System.Windows;
using MessageBox = System.Windows.MessageBox;
using MDEditor.Editor;

namespace MDEditor
{
    public partial class FindReplaceWindow : Window
    {
        private readonly MarkdownEditor _editor;
        private readonly MainWindow? _mainWindow;

        public FindReplaceWindow(MarkdownEditor editor, MainWindow? mainWindow = null)
        {
            InitializeComponent();
            _editor = editor;
            _mainWindow = mainWindow;
            FindTextBox.Focus();
        }

        private void FindNextButton_Click(object sender, RoutedEventArgs e)
        {
            if (!TryFindNext())
            {
                MessageBox.Show("未找到匹配项。", "查找", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void ReplaceButton_Click(object sender, RoutedEventArgs e)
        {
            if (!TryFindNext())
            {
                MessageBox.Show("未找到匹配项。", "替换", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            _editor.ReplaceSelectedText(ReplaceTextBox.Text);
        }

        private void ReplaceAllButton_Click(object sender, RoutedEventArgs e)
        {
            var text = FindTextBox.Text;
            var matchCase = MatchCaseCheckBox.IsChecked == true;
            var useRegex = RegexCheckBox.IsChecked == true;
            _mainWindow?.RememberSearch(text, matchCase, useRegex);
            var count = _editor.ReplaceAll(text, ReplaceTextBox.Text, matchCase, useRegex);
            MessageBox.Show($"已替换 {count} 处内容。", "全部替换", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private bool TryFindNext()
        {
            var text = FindTextBox.Text;
            var matchCase = MatchCaseCheckBox.IsChecked == true;
            var useRegex = RegexCheckBox.IsChecked == true;
            _mainWindow?.RememberSearch(text, matchCase, useRegex);
            return _editor.FindNext(text, matchCase, useRegex);
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
